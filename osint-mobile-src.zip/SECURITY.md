# Authorisation and safety model

This app queries third-party indexes about an asset. It does not touch the asset. That is
the whole safety story, and it is the reason the app is shaped the way it is.

## The rule

Only look up assets you own or have written permission to test. Passive lookups against
public indexes are generally lawful and are how triage works, but the *purpose* is what a
reviewer will judge: checking whether your own domain expired is fine; assembling a
contact dossier on a named person is not.

## What the app enforces

* **Scope guard (`src/providers/scope.ts`).** Put your programme assets in
  Settings → Scope (domains, `*.wildcards`, CIDRs, single IPs). A target outside it gets
  an `OUT OF SCOPE` **critical** flag, a banner in the UI explaining the consequence, and
  a line in the Markdown export saying so. Enabling *Refuse to query providers for
  out-of-scope targets* makes the scan stop at the check instead.
  Scope matching is on the **registrable domain**, so `example.com.evil.test` does **not**
  satisfy a scope entry of `example.com` (there is a test for exactly that).
* **Nothing active.** No port scanning, no banner grabbing, no HTTP requests to the target,
  no DNS queries to the target's own nameservers, no SMTP verification. Queries go to
  public resolvers and vendor APIs only.
* **Bounded ranges.** A CIDR never expands: the app reports the size and samples a capped,
  settings-limited prefix (default 32 addresses), always including network and broadcast.
* **No person-search features.** Phone handling is local libphonenumber parsing. There is
  no reverse-lookup, no address/associate enrichment, and this is intentional.
* **No credential misuse.** No login attempts, no enumeration of accounts, no
  password/OTP flows. Breach-adjacent sources here only report *whether an address appears
  in a public abuse feed*.
* **Rate limiting by default.** Per-host spacing (VirusTotal ~4/min, AbuseIPDB ~30/min,
  Shodan 1/s) protects both your quota and their service.

## Secrets and data

* API keys live in `expo-secure-store` (Android keystore / iOS keychain). They are not
  bundled, not synced, not sent anywhere except to the provider that issued them.
* Debug logging runs keys through `redactHeaders()`: first 3 characters plus length.
* History, watch list and settings are device-local (`AsyncStorage`). The app has no
  backend; there is nothing to breach.
* `tools/proxy.mjs` exists only for browser development: loopback bind, no request
  logging, size cap, non-http(s) schemes refused, private/link-local targets refused,
  optional `--allow-hosts` allowlist.
* The Markdown/CSV export is designed to be pasted into a ticket, so tests assert the
  configured credential never appears in it.

## Photo metadata cuts both ways

The EXIF provider flags embedded GPS as **critical** for the same reason it is useful on a
target: your own submissions, your sources' photos, and geolocation verification all leak
coordinates. If you are handling material from a source, treat "this image has GPS" as an
incident to disclose to them, not a finding to publish.
