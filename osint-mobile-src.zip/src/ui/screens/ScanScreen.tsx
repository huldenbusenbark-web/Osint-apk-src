import React, { useMemo } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { providersFor, byId, GROUP_LABEL } from '../../core/registry';
import { toCsv, toMarkdown } from '../../core/history';
import { maxSeverity, rank } from '../../core/normalize';
import { preview, useApp } from '../store';
import { c, mono, SEV_ORDER, sevColor } from '../theme';
import { Btn, Card, Chip, FindingRow, Section } from '../components/kit';
import type { Finding, ProviderId, ProviderResult, ScanResult } from '../../core/types';

const PLACEHOLDERS = ['example.com', '203.0.113.24', '198.51.100.0/24', 'https://login-verify.example.com/acct', 'someone@corp.example', '+14255550123', 'd41d8cd98f00b204e9800998ecf8427e'];

export function ScanScreen({ pickImage }: { pickImage: () => void }) {
  const { input, setInput, run, cancel, running, live, result, settings, attachments, notice, setNotice, toggleTarget, targets, filter, setFilter, clearAttachments } = useApp();
  const entity = useMemo(() => preview(input, settings.cidrLimit), [input, settings.cidrLimit]);
  const applicable = entity ? providersFor(entity.kind).filter((p) => settings.enabled[p.id]) : [];
  const watched = !!entity && targets.some((t) => t.value === entity.normalized);

  const findings = useMemo(() => group(filterFindings(result, filter), settings.demo), [result, filter, settings.demo]);

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={{ padding: 12, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
        <Card style={{ padding: 10 }}>
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder={settings.demo ? 'Demo mode — try example.com' : 'domain, IP, CIDR, URL, email, phone, hash'}
            placeholderTextColor={c.faint}
            autoCapitalize="none"
            autoCorrect={false}
            submitBehavior="submit"
            onSubmitEditing={() => void run()}
            style={[styles.input, mono, { fontSize: 15 }]}
          />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 }}>
            {PLACEHOLDERS.slice(0, settings.demo ? 3 : 7).map((p) => (
              <Chip key={p} label={p} onPress={() => setInput(p)} />
            ))}
          </View>
          {entity ? (
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', marginTop: 6 }}>
              <Chip label={entity.kind} color={c.accent} />
              <Text style={{ color: c.dim, fontSize: 12, fontFamily: mono.fontFamily }}>
                {entity.normalized.length > 42 ? `${entity.normalized.slice(0, 42)}…` : entity.normalized}
              </Text>
              {entity.rootDomain && entity.rootDomain !== entity.normalized ? <Text style={{ color: c.faint, fontSize: 11, marginLeft: 6 }}>apex: {entity.rootDomain}</Text> : null}
              {entity.cidr ? <Text style={{ color: c.sev.medium, fontSize: 11, marginLeft: 6 }}>{Number(entity.cidr.size).toLocaleString()} addrs, sampling {entity.cidr.sample.length}</Text> : null}
            </View>
          ) : null}
          <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 10, gap: 8, flexWrap: 'wrap' }}>
            <Btn kind="primary" label={running ? 'Scanning…' : `Run ${applicable.length} source${applicable.length === 1 ? '' : 's'}`} onPress={() => void run()} busy={running} />
            {running ? <Btn label="Stop" onPress={cancel} /> : null}
            {result ? <Btn label={watched ? 'Unwatch' : 'Watch'} onPress={() => void toggleTarget()} /> : null}
            {attachments.length ? <Btn label={`Clear ${attachments.length} file${attachments.length === 1 ? '' : 's'}`} onPress={clearAttachments} /> : <Btn label="Attach image" onPress={pickImage} />}
          </View>
          {settings.demo ? <Text style={styles.notice}>Demo mode: recorded provider output, no network calls.</Text> : null}
        </Card>

        {notice ? (
          <Pressable onPress={() => setNotice(null)}>
            <View style={[styles.noticeBar, { borderColor: c.sev.medium }]}>
              <Text style={{ color: c.text, fontSize: 12.5, flex: 1 }}>{notice}</Text>
              <Text style={{ color: c.faint, fontSize: 11 }}>dismiss</Text>
            </View>
          </Pressable>
        ) : null}

        {applicable.length > 0 && !result && !running ? (
          <Text style={styles.subtle}>
            {applicable.map((p) => p.name).join(' · ')}
          </Text>
        ) : null}

        {running || live.length ? (
          <Section title="Sources">
            <Card style={{ padding: 6 }}>
              {applicable.map((p) => (
                <ProviderLine key={p.id} id={p.id} done={live.find((r) => r.provider === p.id)} running={running} />
              ))}
            </Card>
          </Section>
        ) : null}

        {result ? <Verdict result={result} /> : null}

        {result ? (
          <Section
            title={`Findings (${findings.reduce((n, g) => n + g.items.length, 0)})`}
            right={
              <View style={{ flexDirection: 'row', gap: 6 }}>
                <Btn label="Copy MD" onPress={() => void copy(toMarkdown(result))} />
                <Btn label="Copy CSV" onPress={() => void copy(toCsv(result))} />
              </View>
            }
          >
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 6 }}>
              {SEV_ORDER.filter((s) => result.results.some((r) => r.findings.some((f) => f.severity === s))).map((s) => (
                <Chip key={s} label={s} color={sevColor(s)} dim={filter.sev !== null && filter.sev !== s} onPress={() => setFilter({ sev: filter.sev === s ? null : s })} count={result.results.reduce((n, r) => n + r.findings.filter((f) => f.severity === s).length, 0)} />
              ))}
              <Chip label="all" dim={filter.sev === null} onPress={() => setFilter({ sev: null })} />
            </View>
            {findings.length === 0 ? <Text style={styles.subtle}>Nothing matches this filter.</Text> : null}
            {findings.map((g) => (
              <Card key={g.provider}>
                <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
                  <Text style={styles.groupTitle}>{g.name}</Text>
                  <Text style={{ color: c.faint, fontSize: 11, marginLeft: 'auto' }}>{g.items.length}</Text>
                </View>
                {g.items.map((f, i) => (
                  <FindingRow key={`${f.id}-${i}`} label={f.label} value={f.value} detail={f.detail} severity={f.severity} link={f.link} tag={f.kind === 'flag' ? 'flag' : undefined} />
                ))}
              </Card>
            ))}
            <Errors results={result.results} />
          </Section>
        ) : null}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function Verdict({ result }: { result: ScanResult }) {
  const worst = result.results.flatMap((r) => r.findings).filter((f) => f.kind === 'flag').reduce((acc, f) => maxSeverity(acc, f.severity), 'none' as Finding['severity']);
  const color = sevColor(worst);
  const outOfScope = result.results.some((r) => r.findings.some((f) => f.label === 'OUT OF SCOPE'));
  return (
    <Card style={{ borderColor: color, borderWidth: 1.5, backgroundColor: c.panel }}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: color, marginRight: 9 }} />
        <Text style={{ color, fontSize: 17, fontWeight: '900', textTransform: 'uppercase', letterSpacing: 0.8 }}>{worst}</Text>
        <Text style={{ color: c.faint, fontSize: 11, marginLeft: 'auto' }}>{((result.finishedAt - result.startedAt) / 1000).toFixed(1)}s</Text>
      </View>
      <Text style={{ color: c.dim, fontSize: 12.5, marginTop: 6 }}>{result.verdict.summary}</Text>
      {outOfScope ? (
        <Text style={{ color: c.sev.critical, fontSize: 12, marginTop: 8, lineHeight: 17 }}>
          This target is not in your saved scope. Passive registry/DNS reads are harmless, but do not send traffic to it, and do not add it to a report
          until you have written authorisation.
        </Text>
      ) : null}
    </Card>
  );
}

function Errors({ results }: { results: ProviderResult[] }) {
  const bad = results.filter((r) => r.error);
  if (!bad.length) return null;
  return (
    <Card style={{ borderColor: c.sev.low }}>
      <Text style={styles.groupTitle}>Needs attention</Text>
      {bad.map((r) => (
        <View key={r.provider} style={{ marginTop: 8 }}>
          <Text style={{ color: c.text, fontSize: 12.5 }}>{byId.get(r.provider)?.name ?? r.provider} — {r.status}</Text>
          <Text style={{ color: c.faint, fontSize: 11.5, marginTop: 2 }}>{r.error?.message}</Text>
          {r.error?.hint ? <Text style={{ color: c.sev.medium, fontSize: 11.5, marginTop: 2 }}>{r.error.hint}</Text> : null}
        </View>
      ))}
    </Card>
  );
}

function ProviderLine({ id, done, running }: { id: ProviderId; done?: ProviderResult; running: boolean }) {
  const p = byId.get(id)!;
  const status = done?.status ?? (running ? 'running' : 'pending');
  const color = done ? (c.status[done.status] ?? c.dim) : status === 'running' ? c.accent : c.faint;
  const refused = done?.skippedReason?.startsWith('refused:');
  const icon = done ? (refused ? '⊘' : { ok: '✓', error: '✕', nokey: '⚿', skipped: '–', timeout: '⏱', cors: '⛨' }[done.status]) : status === 'running' ? '…' : '·';
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 5, paddingHorizontal: 4 }}>
      <Text style={{ color, fontSize: 13, width: 18 }}>{icon}</Text>
      <View style={{ flex: 1 }}>
        <Text style={{ color: done ? c.text : c.faint, fontSize: 12.5 }} numberOfLines={1}>{p.name}</Text>
        {refused ? <Text style={{ color: c.sev.critical, fontSize: 10.5 }}>outside your saved scope</Text> : null}
      </View>
      {done && done.findings.length ? <Chip label={`${done.findings.length}`} color={c.dim} /> : null}
      <Text style={{ color: c.faint, fontSize: 10.5, fontFamily: mono.fontFamily, marginLeft: 6 }}>
        {done ? (refused ? 'refused' : done.status === 'ok' ? `${done.ms}ms` : done.status) : status === 'running' ? '…' : ''}
      </Text>
    </View>
  );
}

function filterFindings(result: ScanResult | null, filter: { sev: string | null; provider: ProviderId | null }): Finding[] {
  if (!result) return [];
  const seen = new Set<string>();
  return result.results
    .flatMap((r) => r.findings)
    .filter((f) => (!filter.sev || f.severity === filter.sev) && (!filter.provider || f.provider === filter.provider))
    .filter((f) => (seen.has(f.id) ? false : (seen.add(f.id), true)))
    .sort((a, b) => rank(b.severity) - rank(a.severity));
}

function group(findings: Finding[], demo: boolean): { provider: ProviderId; name: string; items: Finding[] }[] {
  const map = new Map<ProviderId, Finding[]>();
  for (const f of findings) map.set(f.provider, [...(map.get(f.provider) ?? []), f]);
  return [...map.entries()]
    .map(([provider, items]) => ({ provider, name: `${GROUP_LABEL[provider] ?? provider} · ${byId.get(provider)?.name ?? provider}${demo ? ' (demo)' : ''}`, items }))
    .sort((a, b) => {
      const ra = Math.max(...a.items.map((f) => rank(f.severity)));
      const rb = Math.max(...b.items.map((f) => rank(f.severity)));
      return rb - ra;
    });
}

async function copy(text: string): Promise<void> {
  const Clipboard = await import('expo-clipboard');
  await Clipboard.setStringAsync(text);
  useApp.getState().setNotice(`Copied ${text.split('\n').length} lines to the clipboard.`);
}

const styles = {
  input: { backgroundColor: c.panel2, borderWidth: 1, borderColor: c.line, borderRadius: 9, color: c.text, paddingHorizontal: 10, paddingVertical: 10, fontSize: 14 },
  notice: { color: c.faint, fontSize: 11, marginTop: 8 },
  noticeBar: { borderWidth: 1, borderColor: c.line, borderRadius: 10, padding: 10, marginBottom: 10, flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: c.panel },
  subtle: { color: c.faint, fontSize: 11.5, marginBottom: 12, lineHeight: 16 },
  groupTitle: { color: c.dim, fontSize: 11, fontWeight: '700', letterSpacing: 0.8, textTransform: 'uppercase' },
} as const;
