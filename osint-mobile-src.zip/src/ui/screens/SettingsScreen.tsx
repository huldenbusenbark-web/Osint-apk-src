import React, { useState } from 'react';
import { Linking, Pressable, ScrollView, Switch, Text, TextInput, View } from 'react-native';
import { catalog, PROVIDERS } from '../../core/registry';
import { SECRET_FIELDS, SECRET_LABELS } from '../../core/keys';
import { ALL_PROVIDERS } from '../../core/settings';
import { parseScope } from '../../core/entity/detect';
import { useApp } from '../store';
import { c, mono } from '../theme';
import { Btn, Card, Chip, Field, Section } from '../components/kit';

export function SettingsScreen() {
  const { settings, patch, toggleProvider, secretStatus, saveSecret, clearSecrets } = useApp();
  const scopeCounts = parseScope(settings.scope);
  const scopeTotal = scopeCounts.domains.length + scopeCounts.cidrs.length + scopeCounts.ips.length + scopeCounts.wildcards.length;

  return (
    <ScrollView contentContainerStyle={{ padding: 12, paddingBottom: 60 }}>
      <Section title="Guard rails">
        <Card>
          <Field
            label={`Authorised scope (${scopeTotal} entries)`}
            value={settings.scope}
            multiline
            onChange={(v) => void patch({ scope: v })}
            placeholder={'example.com\n*.staging.example.com\n203.0.113.0/24\n198.51.100.7'}
            hint="What you are permitted to look at. Anything outside it is flagged (and can be blocked from being sent traffic) rather than silently scanned."
          />
          <Toggle label="Refuse to query providers for out-of-scope targets" value={settings.enforceScope} onChange={(v) => void patch({ enforceScope: v })} />
          <Text style={styles.hint}>
            Off, out-of-scope targets still run the passive lookups and just get a banner. On, the scan stops at the scope check — useful when a target list
            is someone else's and you want the app to enforce the difference.
          </Text>
        </Card>
      </Section>

      <Section title="Runtime">
        <Card>
          <Toggle label="Demo mode (recorded output, zero network)" value={settings.demo} onChange={(v) => void patch({ demo: v })} />
          <Field label="HTTP proxy base (web build only)" value={settings.proxyBase} onChange={(v) => void patch({ proxyBase: v })} placeholder="http://127.0.0.1:8799" hint="The phone needs nothing here. Browsers enforce CORS and most of these APIs send no ACAO header, so the web preview needs tools/proxy.mjs. rdap.org, dns.google, crt.sh and ipwho.is work directly." />
          <NumField label="Per-provider timeout (ms)" value={settings.perProviderTimeoutMs} onChange={(v) => void patch({ perProviderTimeoutMs: v })} />
          <NumField label="Parallel providers" value={settings.concurrency} onChange={(v) => void patch({ concurrency: Math.max(1, Math.min(6, v)) })} />
          <NumField label="CIDR sample size" value={settings.cidrLimit} onChange={(v) => void patch({ cidrLimit: Math.max(1, Math.min(2048, v)) })} />
          <Toggle label="Log requests (redacted keys) to Metro console" value={settings.debugHttp} onChange={(v) => void patch({ debugHttp: v })} />
        </Card>
      </Section>

      <Section title="Free / keyless sources">
        <Text style={styles.hint}>{catalog().free.map((p) => p.name).join(', ')}</Text>
      </Section>

      <Section title={`API keys (${Object.values(secretStatus).filter(Boolean).length}/${ALL_PROVIDERS.length} sources configured)`}>
        {PROVIDERS.map((p) => {
          const spec = SECRET_FIELDS[p.id];
          const fields = spec ? [spec.key, ...(spec.extra ?? [])].filter(Boolean) as string[] : [];
          const missing = spec?.key && !secretStatus[spec.key];
          return (
            <Card key={p.id}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Pressable onPress={() => toggleProvider(p.id)} style={{ flex: 1 }}>
                  <Text style={{ color: c.text, fontSize: 14, fontWeight: '600' }}>{p.name}</Text>
                </Pressable>
                <Switch value={!!settings.enabled[p.id]} onValueChange={() => toggleProvider(p.id)} trackColor={{ true: c.accent, false: c.line }} thumbColor="#fff" />
              </View>
              <Text style={styles.hint}>{p.blurb}</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 6 }}>
                {p.requiresKey ? <Chip label={missing ? 'key needed' : 'key set'} color={missing ? c.sev.low : c.sev.info} /> : <Chip label="no key" color={c.sev.info} />}
                <Chip label={p.entities.join('/')} />
                {p.signupUrl ? <Chip label="get a key ↗" color={c.accent} onPress={() => void Linking.openURL(p.signupUrl!)} /> : null}
              </View>
              {fields.length ? (
                <View style={{ marginTop: 10 }}>
                  {fields.map((f) => (
                    <KeyField key={f} field={f} saved={!!secretStatus[f]} onSave={(v) => void saveSecret(f, v)} />
                  ))}
                </View>
              ) : null}
            </Card>
          );
        })}
      </Section>

      <Section title="Housekeeping">
        <Card>
          <Text style={styles.hint}>
            Keys live in the Android keystore-backed SecureStore, history and settings in AsyncStorage. Nothing is synced anywhere, and the debug log
            truncates every credential to its first three characters.
          </Text>
          <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
            <Btn kind="danger" label="Delete all keys" onPress={() => void clearSecrets()} />
          </View>
        </Card>
      </Section>
    </ScrollView>
  );
}

function KeyField({ field, saved, onSave }: { field: string; saved: boolean; onSave: (v: string) => void }) {
  const meta = SECRET_LABELS[field];
  const [value, setValue] = useState('');
  if (!meta) return null;
  if (meta.password) {
    return (
      <View style={{ marginBottom: 8 }}>
        <Text style={styles.label}>{meta.label} {saved ? <Text style={{ color: c.sev.none }}>· stored</Text> : <Text style={{ color: c.sev.low }}>· not set</Text>}</Text>
        {meta.help ? <Text style={styles.hint}>{meta.help}</Text> : null}
        <View style={{ flexDirection: 'row', gap: 8, marginTop: 5 }}>
          <View style={{ flex: 1 }}>
            <Field label="" value={value} onChange={setValue} placeholder={saved ? 'paste new key to replace' : meta.placeholder} secure hint={undefined} />
          </View>
          <Btn kind="primary" label="Save" disabled={!value.trim()} onPress={() => { onSave(value); setValue(''); }} />
          {saved ? <Btn label="Clear" onPress={() => onSave('')} /> : null}
        </View>
      </View>
    );
  }
  return <Field label={meta.label} value={value} onChange={(v) => { setValue(v); onSave(v); }} placeholder={meta.placeholder} hint={meta.help} />;
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 7 }}>
      <Text style={{ color: c.text, fontSize: 13, flex: 1, marginRight: 10 }}>{label}</Text>
      <Switch value={value} onValueChange={onChange} trackColor={{ true: c.accent, false: c.line }} thumbColor="#fff" />
    </View>
  );
}

function NumField({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  const [text, setText] = useState(String(value));
  const commit = (v: string) => {
    const n = Number(v.replace(/[^\d]/g, ''));
    if (!Number.isFinite(n) || n <= 0) {
      setText(String(value));
      return;
    }
    onChange(Math.round(n));
  };
  return (
    <View style={{ marginBottom: 8 }}>
      <Text style={styles.label}>{label}</Text>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <TextInput
          value={text}
          onChangeText={setText}
          onBlur={() => commit(text)}
          onSubmitEditing={() => commit(text)}
          keyboardType="numeric"
          style={{ backgroundColor: c.panel2, borderWidth: 1, borderColor: c.line, borderRadius: 9, color: c.text, paddingHorizontal: 10, paddingVertical: 8, fontSize: 13, width: 120, fontFamily: mono.fontFamily }}
        />
      </View>
    </View>
  );
}

const styles = {
  label: { color: c.dim, fontSize: 12, marginBottom: 3 },
  hint: { color: c.faint, fontSize: 11.5, lineHeight: 16, marginTop: 3 },
} as const;
