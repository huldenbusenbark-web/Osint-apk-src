import React from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { byId } from '../../core/registry';
import { useApp } from '../store';
import { c, mono, sevColor } from '../theme';
import { Btn, Card, Chip, Section } from '../components/kit';
import { PROVIDERS } from '../../core/registry';

export function HistoryScreen() {
  const { history, targets, openScan, wipeHistory, setInput, tab } = useApp();
  void tab;
  return (
    <ScrollView contentContainerStyle={{ padding: 12, paddingBottom: 60 }}>
      <Section
        title={`Watch list (${targets.length})`}
        right={<Btn label="Re-run all" onPress={() => void rerunAll()} />}
      >
        {targets.length === 0 ? <Text style={styles.hint}>Save a target from the Scan screen to keep it here. Re-running only queries sources, so the cost is your API quota, not traffic to the asset.</Text> : null}
        {targets.map((t) => (
          <Card key={t.value}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={{ color: c.text, fontSize: 13.5, flex: 1, fontFamily: mono.fontFamily }} numberOfLines={1}>{t.value}</Text>
              {t.worst ? <Chip label={t.worst} color={sevColor(t.worst)} /> : null}
            </View>
            <Text style={styles.hint}>{t.kind} · added {new Date(t.addedAt).toLocaleDateString()} · {t.note ?? 'no summary'}</Text>
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
              <Btn label="Scan now" onPress={() => { setInput(t.value); }} />
              <Chip label={t.lastScan ? `last ${new Date(t.lastScan).toLocaleString()}` : 'never scanned'} />
            </View>
          </Card>
        ))}
      </Section>

      <Section title={`Recent scans (${history.length})`} right={history.length ? <Btn kind="danger" label="Clear" onPress={() => void wipeHistory()} /> : undefined}>
        {history.length === 0 ? <Text style={styles.hint}>Scans stay on the device. Nothing is uploaded.</Text> : null}
        {history.map((r) => {
          const flags = r.results.reduce((n, x) => n + x.findings.filter((f) => f.kind === 'flag' && f.severity !== 'low').length, 0);
          const failed = r.results.filter((x) => x.error).map((x) => byId.get(x.provider)?.name).filter(Boolean);
          return (
            <Pressable key={r.id} onPress={() => openScan(r)}>
              <Card>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <Chip label={r.entity.kind} color={c.accent} />
                  <Text style={{ color: c.text, fontSize: 13, flex: 1, fontFamily: mono.fontFamily }} numberOfLines={1}>{r.entity.normalized}</Text>
                  <Chip label={r.verdict.severity} color={sevColor(r.verdict.severity)} />
                </View>
                <Text style={styles.hint}>
                  {new Date(r.startedAt).toLocaleString()} · {r.results.filter((x) => x.status === 'ok').length}/{PROVIDERS.length} sources · {flags} flag{flags === 1 ? '' : 's'}
                  {failed.length ? ` · failed: ${failed.slice(0, 3).join(', ')}` : ''}
                  {r.entity.cidr ? ` · ${Number(r.entity.cidr.size).toLocaleString()} addrs in range` : ''}
                </Text>
              </Card>
            </Pressable>
          );
        })}
      </Section>
    </ScrollView>
  );
}

async function rerunAll(): Promise<void> {
  const { targets, setInput, run, setNotice } = useApp.getState();
  if (!targets.length) {
    setNotice('Watch list is empty.');
    return;
  }
  // Sequential on purpose: the per-host spacing in the HTTP layer only protects
  // one scan at a time, and free tiers do not forgive a fan-out across 20 targets.
  for (const t of targets.slice(0, 5)) {
    setInput(t.value);
    await run();
    await new Promise((r) => setTimeout(r, 400));
  }
  setNotice(`Re-ran ${Math.min(targets.length, 5)} targets.`);
}

const styles = { hint: { color: c.faint, fontSize: 11.5, lineHeight: 16 } } as const;
