import { create } from 'zustand';
import { detect } from '../core/entity/detect';
import { keys } from '../core/keys';
import { loadHistory, pushScan, clearHistory, loadTargets, saveTargets, type SavedTarget } from '../core/history';
import { applyHttpSettings, DEFAULTS, loadSettings, saveSettings, type Settings } from '../core/settings';
import { PROVIDERS, providersFor } from '../core/registry';
import { scan } from '../core/scanner';
import type { Attachment, ProviderId, ProviderResult, ScanResult } from '../core/types';

export type Tab = 'scan' | 'history' | 'settings';

interface UIState {
  ready: boolean;
  tab: Tab;
  input: string;
  settings: Settings;
  secretStatus: Record<string, boolean>;
  running: boolean;
  live: ProviderResult[];
  result: ScanResult | null;
  history: ScanResult[];
  targets: SavedTarget[];
  attachments: Attachment[];
  notice: string | null;
  filter: { sev: string | null; provider: ProviderId | null };

  boot: () => Promise<void>;
  setInput: (v: string) => void;
  patch: (p: Partial<Settings>) => Promise<void>;
  toggleProvider: (id: ProviderId) => Promise<void>;
  saveSecret: (field: string, value: string) => Promise<void>;
  clearSecrets: () => Promise<void>;
  run: () => Promise<void>;
  cancel: () => void;
  openScan: (r: ScanResult) => void;
  refreshHistory: () => Promise<void>;
  wipeHistory: () => Promise<void>;
  toggleTarget: () => Promise<void>;
  addAttachments: (a: Attachment[]) => void;
  clearAttachments: () => void;
  setNotice: (s: string | null) => void;
  setFilter: (f: Partial<UIState['filter']>) => void;
}

let controller: AbortController | null = null;

export const useApp = create<UIState>((set, get) => ({
  ready: false,
  tab: 'scan',
  input: '',
  settings: DEFAULTS,
  secretStatus: {},
  running: false,
  live: [],
  result: null,
  history: [],
  targets: [],
  attachments: [],
  notice: null,
  filter: { sev: null, provider: null },

  async boot() {
    const [settings, secretStatus, history, targets] = await Promise.all([
      loadSettings(),
      keys.status(),
      loadHistory(),
      loadTargets(),
    ]);
    applyHttpSettings(settings);
    set({ ready: true, settings, secretStatus, history, targets });
  },

  setInput(v) {
    set({ input: v });
  },

  async patch(p) {
    const settings = { ...get().settings, ...p };
    set({ settings });
    await saveSettings(settings);
    applyHttpSettings(settings);
  },

  async toggleProvider(id) {
    const enabled = { ...get().settings.enabled, [id]: !get().settings.enabled[id] };
    await get().patch({ enabled });
  },

  async saveSecret(field, value) {
    await keys.set(field, value);
    set({ secretStatus: await keys.status() });
  },

  async clearSecrets() {
    await keys.clear();
    set({ secretStatus: await keys.status(), notice: 'All keys removed from the device keychain.' });
  },

  async run() {
    const { input, settings, attachments, result } = get();
    const entity = detect(input.trim() || (result ? '' : ''), settings.cidrLimit);
    if (!input.trim()) {
      set({ notice: 'Type or paste a domain, IP, CIDR, URL, email or phone number first.' });
      return;
    }
    const applicable = providersFor(entity.kind).filter((p) => settings.enabled[p.id]);
    if (!applicable.length) {
      set({ notice: `No enabled source handles a ${entity.kind}. Enable some in Settings.` });
      return;
    }
    controller?.abort();
    controller = new AbortController();
    set({ running: true, live: [], result: null, tab: 'scan' });

    const onProviderDone = (r: ProviderResult) => set({ live: [...get().live, r] });
    try {
      const finished = await scan({
        entity,
        config: {
          providers: PROVIDERS.filter((p) => settings.enabled[p.id]).map((p) => p.id),
          perProviderTimeoutMs: settings.perProviderTimeoutMs,
          concurrency: settings.concurrency,
          cidrLimit: settings.cidrLimit,
          enforceScope: settings.enforceScope,
          scope: settings.scope,
          demo: settings.demo,
        },
        attachments,
        onProviderDone,
        signal: controller.signal,
      });
      set({ result: finished, live: finished.results, running: false });
      const history = await pushScan(finished, settings.historyLimit);
      set({ history });
    } catch (err) {
      set({ running: false, notice: `Scan failed: ${(err as Error).message}` });
    } finally {
      controller = null;
    }
  },

  cancel() {
    controller?.abort();
    set({ running: false, notice: 'Stopped. Partial results kept.' });
  },

  openScan(r) {
    set({ result: r, live: r.results, tab: 'scan' });
  },

  async refreshHistory() {
    set({ history: await loadHistory(), targets: await loadTargets() });
  },

  async wipeHistory() {
    await clearHistory();
    set({ history: [], result: null });
  },

  async toggleTarget() {
    const { result, targets } = get();
    if (!result) return;
    const value = result.entity.normalized;
    const exists = targets.some((t) => t.value === value);
    const next = exists
      ? targets.filter((t) => t.value !== value)
      : [
          {
            value,
            kind: result.entity.kind,
            addedAt: Date.now(),
            worst: result.verdict.severity,
            lastScan: result.startedAt,
            note: result.verdict.summary,
          } as SavedTarget,
          ...targets,
        ];
    await saveTargets(next);
    set({ targets: next, notice: exists ? 'Removed from watch list.' : 'Saved to watch list.' });
  },

  addAttachments(a) {
    set({ attachments: [...get().attachments, ...a].slice(0, 4) });
  },
  clearAttachments() {
    set({ attachments: [] });
  },
  setNotice(s) {
    set({ notice: s });
  },
  setFilter(f) {
    set({ filter: { ...get().filter, ...f } });
  },
}));

export function preview(input: string, cidrLimit: number) {
  if (!input.trim()) return null;
  try {
    return detect(input.trim(), cidrLimit);
  } catch {
    return null;
  }
}
