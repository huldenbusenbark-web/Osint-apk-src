import React from 'react';
import { ActivityIndicator, Linking, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { c, mono, sevColor } from '../theme';

export function Card({ children, style }: { children: React.ReactNode; style?: object }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function Section({ title, right, children }: { title: string; right?: React.ReactNode; children: React.ReactNode }) {
  return (
    <View style={{ marginBottom: 14 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6, paddingHorizontal: 2 }}>
        <Text style={styles.sectionTitle}>{title}</Text>
        {right}
      </View>
      {children}
    </View>
  );
}

export function Chip({ label, color, dim, onPress, count }: { label: string; color?: string; dim?: boolean; onPress?: () => void; count?: number }) {
  const body = (
    <View style={[styles.chip, { borderColor: color ?? c.line }, dim && { opacity: 0.5 }]}>
      {color ? <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: color, marginRight: 6 }} /> : null}
      <Text style={[styles.chipText, color ? { color } : null]}>{label}</Text>
      {count !== undefined && <Text style={[styles.chipText, { color: c.faint }]}>{count}</Text>}
    </View>
  );
  return onPress ? <Pressable onPress={onPress} style={{ marginRight: 6, marginBottom: 6 }}>{body}</Pressable> : body;
}

export function Btn({ label, onPress, kind = 'ghost', disabled, busy }: { label: string; onPress?: () => void; kind?: 'primary' | 'ghost' | 'danger'; disabled?: boolean; busy?: boolean }) {
  return (
    <Pressable
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.btn,
        kind === 'primary' && { backgroundColor: c.accent, borderColor: c.accent },
        kind === 'danger' && { borderColor: c.sev.critical },
        (pressed || disabled) && { opacity: 0.6 },
      ]}
    >
      {busy ? <ActivityIndicator size="small" color={kind === 'primary' ? '#04121d' : c.text} /> : <Text style={[styles.btnText, kind === 'primary' && { color: '#04121d', fontWeight: '700' }, kind === 'danger' && { color: c.sev.critical }]}>{label}</Text>}
    </Pressable>
  );
}

export function Field({ label, value, onChange, placeholder, secure, multiline, hint }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string; secure?: boolean; multiline?: boolean; hint?: string }) {
  return (
    <View style={{ marginBottom: 10 }}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor={c.faint}
        secureTextEntry={secure}
        multiline={multiline}
        autoCapitalize="none"
        autoCorrect={false}
        style={[styles.input, multiline && { height: 92, textAlignVertical: 'top' }]}
      />
      {hint ? <Text style={styles.hint}>{hint}</Text> : null}
    </View>
  );
}

export function FindingRow({ label, value, detail, severity, link, tag }: { label: string; value: string; detail?: string; severity: string; link?: string; tag?: string }) {
  const color = sevColor(severity);
  return (
    <Pressable disabled={!link} onPress={link ? () => void Linking.openURL(link) : undefined} style={[styles.finding, { borderLeftColor: color }]}>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 3 }}>
        <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: color, marginRight: 7 }} />
        <Text style={styles.findingLabel}>{label}</Text>
        {tag ? <Text style={[styles.tag, { color, borderColor: color }]}>{tag}</Text> : null}
      </View>
      <Text selectable style={[styles.findingValue, mono]}>{value}</Text>
      {detail ? <Text style={styles.findingDetail}>{detail}</Text> : null}
      {link ? <Text style={[styles.link, mono]}>{link}</Text> : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: c.panel, borderRadius: 12, borderWidth: 1, borderColor: c.line, padding: 12, marginBottom: 10 },
  sectionTitle: { color: c.dim, fontSize: 11, letterSpacing: 1.1, textTransform: 'uppercase', fontWeight: '700' },
  chip: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderRadius: 999, paddingHorizontal: 9, paddingVertical: 4, backgroundColor: c.panel2 },
  chipText: { color: c.text, fontSize: 12 },
  btn: { borderWidth: 1, borderColor: c.line, borderRadius: 9, paddingHorizontal: 13, paddingVertical: 9, backgroundColor: c.panel2 },
  btnText: { color: c.text, fontSize: 13, fontWeight: '600' },
  fieldLabel: { color: c.dim, fontSize: 12, marginBottom: 4 },
  input: { backgroundColor: c.panel2, borderWidth: 1, borderColor: c.line, borderRadius: 9, color: c.text, paddingHorizontal: 10, paddingVertical: 9, fontSize: 14, minHeight: 42 },
  hint: { color: c.faint, fontSize: 11, marginTop: 4, lineHeight: 15 },
  finding: { borderLeftWidth: 3, paddingLeft: 10, paddingVertical: 8, marginBottom: 8, backgroundColor: c.panel2, borderRadius: 6 },
  findingLabel: { color: c.dim, fontSize: 12, fontWeight: '600', flexShrink: 1 },
  findingValue: { color: c.text, fontSize: 13.5, lineHeight: 19 },
  findingDetail: { color: c.faint, fontSize: 11.5, marginTop: 3, lineHeight: 16 },
  link: { color: c.accent, fontSize: 10.5, marginTop: 3 },
  tag: { fontSize: 9, fontWeight: '800', letterSpacing: 0.6, borderWidth: 1, borderRadius: 4, paddingHorizontal: 4, marginLeft: 7, textTransform: 'uppercase', overflow: 'hidden' },
});
