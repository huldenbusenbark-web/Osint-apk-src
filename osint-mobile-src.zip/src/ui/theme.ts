export const c = {
  bg: '#0b0f14',
  panel: '#121821',
  panel2: '#18202b',
  line: '#243040',
  text: '#e6edf5',
  dim: '#8b9bb0',
  faint: '#5b6b80',
  accent: '#4cc2ff',
  sev: {
    none: '#4a5a6b',
    info: '#5b8db8',
    low: '#8fb04a',
    medium: '#e0a83c',
    high: '#e2703a',
    critical: '#e5484d',
  } as Record<string, string>,
  status: {
    ok: '#4bbf7f',
    error: '#e5484d',
    timeout: '#e0a83c',
    nokey: '#8b9bb0',
    skipped: '#4a5a6b',
    cors: '#e0a83c',
  } as Record<string, string>,
};

export const mono = { fontFamily: 'monospace' } as const;

export const SEV_ORDER = ['critical', 'high', 'medium', 'low', 'info', 'none'] as const;

export function sevColor(s: string): string {
  return c.sev[s] ?? c.sev.info;
}
