import { finding } from './normalize';
import type { Finding, ProviderId } from './types';

/**
 * Recorded output for one scan of `example.com`, so the whole UI — verdict
 * maths, grouping, severity colours, provider error states — is reviewable on
 * a laptop with zero keys configured and nothing leaves the machine in demo
 * mode. Values are representative, not a snapshot of a live asset.
 */
export const DEMO_FINDINGS: Partial<Record<ProviderId, Finding[]>> = {
  scope: [
    finding('scope', 'OUT OF SCOPE', 'example.com', { kind: 'flag', severity: 'critical', detail: 'no entry in your saved scope matches this target.' }),
    finding('scope', 'Certificate names (CT)', '3', { severity: 'info', detail: 'example.com, www.example.com, api.example.com' }),
  ],
  rdap: [
    finding('rdap', 'Registrar', 'RESERVED-Internet Assigned Numbers Authority', { detail: 'whois.iana.org' }),
    finding('rdap', 'Registered', '1995-08-14 04:00 UTC', { detail: '11314 days ago' }),
    finding('rdap', 'Expires', '1999-08-13 04:00 UTC', { kind: 'flag', severity: 'high', detail: 'expired' }),
    finding('rdap', 'Status', 'clientDeleteProhibited', { severity: 'none' }),
    finding('rdap', 'Nameservers', 'a.iana-servers.net, b.iana-servers.net', { severity: 'info' }),
    finding('rdap', 'DNSSEC', 'signed', { severity: 'none' }),
  ],
  dns: [
    finding('dns', 'A', '93.184.215.14', { detail: 'TTL 300s' }),
    finding('dns', 'AAAA', '2606:2800:21f:cb07:6820:80da:af6b:8b2c', { detail: 'TTL 300s' }),
    finding('dns', 'MX', '0 . (no mail exchanger)', { severity: 'info' }),
    finding('dns', 'DMARC', 'missing', { kind: 'flag', severity: 'medium', detail: 'no _dmarc.example.com' }),
    finding('dns', 'SPF', 'v=spf1 -all', { kind: 'flag', severity: 'none', detail: 'hardfail: nothing else may send for it' }),
  ],
  virustotal: [
    finding('virustotal', 'Domain detection', '0 malicious / 1 suspicious / 80 clean', { severity: 'none', link: 'https://www.virustotal.com/gui/domain/example.com' }),
    finding('virustotal', 'Categories', 'Forcepoint ThreatSeeker=information technology', { severity: 'none' }),
  ],
  shodan: [
    finding('shodan', 'Ports seen open', '80, 443', { severity: 'info', detail: 'last crawl 2026-09-01 03:12 UTC' }),
    finding('shodan', 'Banner 443', 'nginx 1.27.4', { detail: 'TLS · CN=example.org' }),
  ],
  abuseipdb: [
    finding('abuseipdb', 'Confidence', '0%', { severity: 'none', detail: '0 reports in 90 days' }),
  ],
  otx: [
    finding('otx', 'Pulses referencing it', '2: Example Feed, Historic Honeypot Hits', { kind: 'flag', severity: 'medium' }),
    finding('otx', 'Passive DNS', '412 records', { severity: 'info', detail: '2009-01-01 → 2026-08-30' }),
  ],
  urlhaus: [finding('urlhaus', 'URLhaus listing', 'not listed', { severity: 'none' })],
  stalkphish: [finding('stalkphish', 'Kit corpus', 'no pages serving "example.com"', { severity: 'none', detail: 'last 120 days' })],
  emailrep: [finding('emailrep', 'Score', '0/10', { severity: 'none' })],
  ip2whois: [finding('ip2whois', 'Registrar', ' RESERVED-IANARI', { severity: 'info' })],
  dnsdumpster: [finding('dnsdumpster', 'Host records', '4', { severity: 'info' }), finding('dnsdumpster', 'Subdomains', 'www, api, m, staging', { severity: 'info' })],
  leakix: [finding('leakix', 'Indexed', 'nothing seen', { severity: 'none' })],
  phoneparse: [finding('phoneparse', 'Parse', 'not a valid international number', { kind: 'flag', severity: 'low' })],
  exif: [finding('exif', 'Metadata', 'nothing to read', { severity: 'none', detail: 'attach an image to populate this' })],
  fraudlabs: [finding('fraudlabs', 'Not configured', 'missing account id', { severity: 'low' })],
  phishreport: [finding('phishreport', 'Not configured', 'no base URL', { severity: 'low' })],
  custom: [finding('custom', 'Not configured', 'no definitions', { severity: 'none' })],
  ipgeo: [finding('ipgeo', 'Location', 'Los Angeles, California, US', { severity: 'info' })],
};
