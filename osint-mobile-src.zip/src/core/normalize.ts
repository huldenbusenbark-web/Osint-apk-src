import type { Finding, ProviderId, Severity } from './types';

const SEV_RANK: Record<Severity, number> = { none: 0, info: 1, low: 2, medium: 3, high: 4, critical: 5 };

export function rank(s: Severity): number {
  return SEV_RANK[s];
}

export function maxSeverity(a: Severity, b: Severity): Severity {
  return rank(a) >= rank(b) ? a : b;
}

export function finding(
  provider: ProviderId,
  label: string,
  value: string,
  extra: Partial<Omit<Finding, 'provider' | 'label' | 'value' | 'id'>> = {},
): Finding {
  const kind = extra.kind ?? 'fact';
  const severity = extra.severity ?? (kind === 'flag' ? 'medium' : 'info');
  return {
    id: `${provider}:${label}:${value}`.toLowerCase(),
    provider,
    label,
    value: String(value),
    kind,
    severity,
    ...extra,
  };
}

export function fmtDate(iso?: string | number): string {
  if (iso === undefined || iso === null || iso === '') return 'unknown';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return String(iso);
  return d.toISOString().replace('T', ' ').slice(0, 16) + ' UTC';
}

export function ageDays(iso?: string): number | undefined {
  if (!iso) return undefined;
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return undefined;
  return Math.floor((Date.now() - t) / 86_400_000);
}
