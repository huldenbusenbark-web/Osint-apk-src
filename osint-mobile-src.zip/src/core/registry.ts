import type { EntityKind, Provider, ProviderId } from './types';
import { rdap } from '../providers/rdap';
import { dns } from '../providers/dns';
import { ipgeo } from '../providers/ipgeo';
import { shodan } from '../providers/shodan';
import { abuseipdb } from '../providers/abuseipdb';
import { leakix } from '../providers/leakix';
import { ip2whois } from '../providers/ip2whois';
import { dnsdumpster } from '../providers/dnsdumpster';
import { virustotal } from '../providers/virustotal';
import { otx } from '../providers/otx';
import { urlhaus } from '../providers/urlhaus';
import { stalkphish } from '../providers/stalkphish';
import { phishreport } from '../providers/phishreport';
import { emailrep } from '../providers/emailrep';
import { fraudlabs } from '../providers/fraudlabs';
import { phoneparse } from '../providers/phoneparse';
import { metadata } from '../providers/metadata';
import { scope } from '../providers/scope';
import { custom } from '../providers/custom';

export const PROVIDERS: Provider[] = [
  scope, rdap, dns, ipgeo, phoneparse, metadata,
  virustotal, otx, abuseipdb, urlhaus, stalkphish, phishreport, emailrep,
  shodan, leakix, ip2whois, dnsdumpster, fraudlabs, custom,
];

export const byId = new Map<ProviderId, Provider>(PROVIDERS.map((p) => [p.id, p]));

export function providersFor(kind: EntityKind): Provider[] {
  return PROVIDERS.filter((p) => p.entities.includes(kind));
}

/** What the Settings screen renders: free sources first, then keyed ones. */
export function catalog(): { free: Provider[]; keyed: Provider[] } {
  return {
    free: PROVIDERS.filter((p) => !p.requiresKey),
    keyed: PROVIDERS.filter((p) => p.requiresKey),
  };
}

export const GROUP_LABEL: Record<string, string> = {
  scope: 'Guard rail',
  rdap: 'Registration',
  dns: 'Resolution',
  ipgeo: 'Address',
  phoneparse: 'Address',
  metadata: 'Artefacts',
  virustotal: 'Blocklists & reputation',
  otx: 'Blocklists & reputation',
  abuseipdb: 'Blocklists & reputation',
  urlhaus: 'Blocklists & reputation',
  stalkphish: 'Phishing',
  phishreport: 'Phishing',
  emailrep: 'Fraud',
  fraudlabs: 'Fraud',
  shodan: 'Exposure',
  leakix: 'Exposure',
  ip2whois: 'Registration',
  dnsdumpster: 'Exposure',
  custom: 'Your own sources',
};
