/** Types we ask dns.google for. Ordered by "how much this explains about a host". */
export type RecordType = string;
export interface DnsAnswer {
  name: string;
  type: number;
  TTL: number;
  data: string;
}

export interface DnsSet {
  type: RecordType;
  answers: DnsAnswer[];
  /** NXDOMAIN / NOERROR-with-empty-answer are different signals. */
  status: number;
  statusName: string;
}
