import { configureHttp } from './net/http';
import { readJson, plainStore } from './store';
import type { ProviderId } from './types';

export const ALL_PROVIDERS: ProviderId[] = [
  'rdap','dns','ipgeo','phoneparse','exif','scope','shodan','abuseipdb','leakix',
  'ip2whois','dnsdumpster','virustotal','otx','urlhaus','stalkphish','phishreport','emailrep','fraudlabs','custom',
];

export interface Settings {
  enabled: Record<string, boolean>;
  proxyBase: string;
  demo: boolean;
  perProviderTimeoutMs: number;
  concurrency: number;
  cidrLimit: number;
  enforceScope: boolean;
  /** Free text: domains, CIDRs, *.wildcards. Gates which assets get touched. */
  scope: string;
  debugHttp: boolean;
  historyLimit: number;
}

export const DEFAULTS: Settings = {
  enabled: Object.fromEntries(ALL_PROVIDERS.map((p) => [p, true])),
  proxyBase: '',
  demo: false,
  perProviderTimeoutMs: 12_000,
  concurrency: 3,
  cidrLimit: 32,
  enforceScope: false,
  scope: '',
  debugHttp: false,
  historyLimit: 100,
};

const KEY = 'osint.settings.v1';

export async function loadSettings(): Promise<Settings> {
  const s = await readJson<Settings>(plainStore(), KEY, DEFAULTS);
  return { ...DEFAULTS, ...s, enabled: { ...DEFAULTS.enabled, ...(s.enabled ?? {}) } };
}

export async function saveSettings(s: Settings): Promise<void> {
  await plainStore().set(KEY, JSON.stringify(s));
  applyHttpSettings(s);
}

export function applyHttpSettings(s: Settings): void {
  configureHttp({
    proxyBase: s.proxyBase.trim(),
    defaultTimeoutMs: s.perProviderTimeoutMs,
    debug: s.debugHttp,
  });
}
