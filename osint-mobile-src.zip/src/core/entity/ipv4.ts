import type { EntityDescriptor } from '../types';

export function isIpv4(s: string): boolean {
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(s);
  if (!m) return false;
  return m.slice(1).every((o) => Number(o) <= 255);
}

export function isCidr(s: string): boolean {
  const [addr, prefix, extra] = s.split('/');
  if (extra !== undefined) return false;
  if (!isIpv4(addr)) return false;
  const p = Number(prefix);
  return Number.isInteger(p) && p >= 0 && p <= 32;
}

export function isIpv6(s: string): boolean {
  if (!s.includes(':')) return false;
  const parts = s.split('::');
  if (parts.length > 2) return false;
  const validHextet = (h: string) => /^[0-9a-f]{1,4}$/i.test(h);
  const flat = (str: string) => (str === '' ? [] : str.split(':').filter((x) => x !== '' || true));
  const left = flat(parts[0]);
  const right = parts.length === 2 ? flat(parts[1] ?? '') : [];
  if (parts.length === 1 && left.length !== 8) return false;
  const total = left.length + right.length;
  if (parts.length === 2 && total > 7) return false;
  // Allow a trailing embedded IPv4 (e.g. ::ffff:1.2.3.4)
  const check = [...left, ...right].map((h, i, arr) =>
    i === arr.length - 1 && h.includes('.') ? (isIpv4(h) ? '1' : 'x') : h,
  );
  return check.every(validHextet);
}

function toU32(dotted: string): number {
  return dotted.split('.').reduce((acc, o) => acc * 256 + Number(o), 0) >>> 0;
}

function toDotted(n: number): string {
  return [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.');
}

/**
 * Parse a CIDR into its bounds and a capped sample of host addresses.
 * We never materialise the whole range: a /8 is 16.7M addresses and scanning
 * that from a phone would be both abusive and pointless. The sample is biased
 * to the first addresses, which is where live hosts cluster.
 */
export function parseCidr(cidr: string, limit: number): NonNullable<EntityDescriptor['cidr']> {
  const [addr, prefixStr] = cidr.split('/');
  const prefix = Number(prefixStr);
  const ipU32 = toU32(addr);
  const mask = prefix === 0 ? 0 : (0xffffffff << (32 - prefix)) >>> 0;
  const networkU = (ipU32 & mask) >>> 0;
  const size = 2 ** (32 - prefix);
  const broadcastU = (networkU + size - 1) >>> 0;
  const cap = Math.max(1, Math.min(limit, size));
  const sample: string[] = [];
  for (let i = 0; i < cap; i++) sample.push(toDotted((networkU + i) >>> 0));
  if (size > 1 && !sample.includes(toDotted(broadcastU))) {
    sample[sample.length - 1] = toDotted(broadcastU);
  }
  return {
    network: toDotted(networkU),
    prefix,
    size: String(size),
    first: toDotted(networkU),
    last: toDotted(broadcastU),
    sample,
    truncated: size > cap,
  };
}

export function ipInCidr(ip: string, cidr: string): boolean {
  if (!isIpv4(ip) || !isCidr(cidr)) return false;
  const [addr, prefixStr] = cidr.split('/');
  const prefix = Number(prefixStr);
  const mask = prefix === 0 ? 0 : (0xffffffff << (32 - prefix)) >>> 0;
  return (toU32(ip) & mask) >>> 0 === (toU32(addr) & mask) >>> 0;
}

