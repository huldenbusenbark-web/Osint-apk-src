import type { EntityDescriptor, EntityKind } from '../types';
import { ipInCidr, isCidr, isIpv4, isIpv6, parseCidr } from './ipv4';

/**
 * Two-level suffixes where the registrable domain is 3 labels, not 2.
 * Deliberately a small list, not the full PSL: the root domain is used for
 * "same owner" hints and scope matching, and an approximate answer with a
 * documented limit beats a 200KB table in a phone app.
 */
const TWO_LEVEL = new Set([
  'co.uk','org.uk','ac.uk','gov.uk','me.uk','net.uk','sch.uk',
  'com.au','net.au','org.au','edu.au','gov.au','id.au',
  'co.nz','net.nz','org.nz','govt.nz',
  'co.za','org.za','web.za','net.za',
  'com.br','net.br','org.br','gov.br','app.br',
  'co.jp','ne.jp','or.jp','ac.jp','go.jp',
  'com.cn','net.cn','org.cn','gov.cn','edu.cn',
  'com.mx','com.co','net.co','com.ar','com.pe','com.cl',
  'co.in','net.in','org.in','res.in','gov.in',
  'com.sg','edu.sg','gov.sg','com.my','com.hk','com.tw','com.tr','com.ua','com.pl','com.ru','co.kr','com.vn','com.ph',
]);

export function rootDomain(host: string): string {
  const labels = host.toLowerCase().replace(/\.$/, '').split('.');
  if (labels.length <= 2) return labels.join('.');
  const lastTwo = labels.slice(-2).join('.');
  const take = TWO_LEVEL.has(lastTwo) ? 3 : 2;
  return labels.slice(-take).join('.');
}

const HEX = /^[0-9a-f]+$/i;

export function hashAlgorithm(hex: string): 'md5' | 'sha1' | 'sha256' | undefined {
  if (!HEX.test(hex)) return undefined;
  if (hex.length === 32) return 'md5';
  if (hex.length === 40) return 'sha1';
  if (hex.length === 64) return 'sha256';
  return undefined;
}

/** Bare "example.com/path" with no scheme still parses in `new URL` only with a base. */
function looksLikeHostPath(s: string): boolean {
  return /^[a-z0-9._-]+(\.[a-z]{2,})(\/[^\s]*)?$/i.test(s) && s.includes('/');
}

export function classify(input: string): EntityKind {
  const s = input.trim();
  if (s === '') return 'domain';
  if (/^https?:\/\//i.test(s) || looksLikeHostPath(s)) return 'url';
  if (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s)) return 'email';
  if (isCidr(s)) return 'cidr';
  if (isIpv4(s)) return 'ip';
  if (isIpv6(s)) return 'ip';
  if (/^(?:AS)?\d{1,7}$/i.test(s)) return 'asn';
  if (hashAlgorithm(s) !== undefined) return 'hash';
  // Strip the separators people actually type, then require E.164-shaped
  // digits. Order matters: ip/cidr/hash are tested above, so "203.0.113.7"
  // never reaches here and cannot be mistaken for a number.
  const dial = s.replace(/[\s().-]/g, '');
  if (/^\+?\d{7,15}$/.test(dial)) return 'phone';
  return 'domain';
}

/**
 * Turn free text into a typed entity. Also used to clean clipboard/share-sheet
 * payloads, which arrive as "Check https://x.y/… sent by user #123".
 */
export function detect(input: string, cidrLimit = 32): EntityDescriptor {
  const raw = input.trim();
  const kind = classify(raw);
  const base: EntityDescriptor = { raw, normalized: raw, kind };

  switch (kind) {
    case 'url': {
      let url: URL | undefined;
      try {
        url = new URL(/^https?:\/\//i.test(raw) ? raw : `http://${raw}`);
      } catch {
        url = undefined;
      }
      if (!url) return { ...base, kind: 'domain', normalized: raw.toLowerCase() };
      const host = url.hostname.toLowerCase().replace(/\.$/, '');
      return {
        ...base,
        normalized: url.toString(),
        rootDomain: rootDomain(host),
        url: { scheme: url.protocol.replace(':', ''), host, path: url.pathname + url.search },
      };
    }
    case 'email': {
      const [local, domain] = raw.toLowerCase().split('@');
      return { ...base, normalized: `${local}@${domain}`, email: { local, domain }, rootDomain: rootDomain(domain) };
    }
    case 'cidr': {
      const cidr = parseCidr(raw.toLowerCase(), cidrLimit);
      return { ...base, normalized: `${cidr.network}/${cidr.prefix}`, cidr };
    }
    case 'ip': {
      const lower = raw.toLowerCase();
      const v4 = isIpv4(lower);
      return { ...base, normalized: lower, ipVersion: v4 ? 4 : 6 };
    }
    case 'asn': {
      const num = Number(raw.toUpperCase().replace(/^AS/, ''));
      return { ...base, normalized: `AS${num}`, asn: num };
    }
    case 'hash': {
      const hex = raw.toLowerCase();
      return { ...base, normalized: hex, hash: { algorithm: hashAlgorithm(hex)!, hex } };
    }
    case 'phone': {
      const digits = raw.startsWith('+') ? '+' + raw.replace(/[^\d]/g, '') : raw;
      return { ...base, normalized: digits };
    }
    default: {
      const host = raw.toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/\.$/, '');
      return { ...base, normalized: host, rootDomain: rootDomain(host) };
    }
  }
}

/** Scope guard: is this entity inside the ranges/domains you are allowed to touch? */
export interface Scope {
  domains: string[];
  cidrs: string[];
  ips: string[];
  wildcards: string[];
}

export function parseScope(text: string): Scope {
  const scope: Scope = { domains: [], cidrs: [], ips: [], wildcards: [] };
  for (const tokenRaw of text.split(/[\n,;]+/)) {
    let t = tokenRaw.trim().toLowerCase().replace(/^https?:\/\//, '');
    // Only treat a "/" as a path boundary when it is not a prefix length:
    // stripping blindly here would silently turn 203.0.113.0/28 into a single
    // host and quietly widen the scope.
    if (!isCidr(t)) t = t.replace(/\/.*$/, '');
    t = t.replace(/\.$/, '');
    if (!t) continue;
    if (isCidr(t)) scope.cidrs.push(t);
    else if (isIpv4(t) || isIpv6(t)) scope.ips.push(t);
    else if (t.startsWith('*.')) scope.wildcards.push(t.slice(2));
    else scope.domains.push(t);
  }
  return scope;
}

export function inScope(entity: EntityDescriptor, scope: Scope): boolean {
  const empty = !scope.domains.length && !scope.cidrs.length && !scope.ips.length && !scope.wildcards.length;
  if (empty) return true; // no scope configured -> app is in "just a lookup tool" mode
  switch (entity.kind) {
    case 'cidr': {
      if (!entity.cidr) return false;
      return scope.cidrs.some(
        (s) => ipInCidrSafe(entity.cidr!.first, s) && ipInCidrSafe(entity.cidr!.last, s),
      );
    }
    case 'ip':
      return scope.ips.includes(entity.normalized) || scope.cidrs.some((c) => ipInCidrSafe(entity.normalized, c));
    case 'domain':
    case 'url':
    case 'email':
    case 'asn':
    case 'hash': {
      const host = entity.kind === 'email' ? entity.email?.domain : entity.kind === 'url' ? entity.rootDomain : entity.normalized;
      if (!host) return false;
      const root = entity.rootDomain ?? rootDomain(host);
      const hit =
        scope.domains.includes(host) ||
        scope.domains.includes(root) ||
        scope.domains.some((d) => host === d || host.endsWith(`.${d}`)) ||
        scope.wildcards.some((d) => host === d || host.endsWith(`.${d}`));
      return hit;
    }
    default:
      return true;
  }
}

function ipInCidrSafe(ip: string, cidr: string): boolean {
  try {
    return isCidr(cidr) && isIpv4(ip) && ipInCidr(ip, cidr);
  } catch {
    return false;
  }
}
