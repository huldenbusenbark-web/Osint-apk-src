/**
 * Tiny persistence seam. The app injects AsyncStorage (device) or
 * localStorage (web); core stays importable from Node, which is what makes the
 * provider code unit-testable without a device.
 */
export interface StateStore {
  get(key: string): Promise<string | null>;
  set(key: string, value: string): Promise<void>;
  del(key: string): Promise<void>;
}

export class MemoryStore implements StateStore {
  private m = new Map<string, string>();
  constructor(seed?: Record<string, string>) {
    if (seed) for (const [k, v] of Object.entries(seed)) this.m.set(k, v);
  }
  async get(key: string) {
    return this.m.get(key) ?? null;
  }
  async set(key: string, value: string) {
    this.m.set(key, value);
  }
  async del(key: string) {
    this.m.delete(key);
  }
}

let injected: StateStore = new MemoryStore();
let secretInjected: StateStore = new MemoryStore();

export function configureStores(opts: { plain?: StateStore; secret?: StateStore }): void {
  if (opts.plain) injected = opts.plain;
  if (opts.secret) secretInjected = opts.secret;
}

export function plainStore(): StateStore {
  return injected;
}
/** Only for values that must not sit in a plain SQLite/AsyncStorage blob. */
export function secretStore(): StateStore {
  return secretInjected;
}

export async function readJson<T>(store: StateStore, key: string, fallback: T): Promise<T> {
  try {
    const raw = await store.get(key);
    if (raw === null) return fallback;
    return { ...fallback, ...(JSON.parse(raw) as object) } as T;
  } catch {
    return fallback;
  }
}
