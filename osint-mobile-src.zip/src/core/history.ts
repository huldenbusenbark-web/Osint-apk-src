import { readJson, plainStore } from './store';
import type { ScanResult, EntityKind } from './types';

const SCANS = 'osint.history.scans.v1';
const TARGETS = 'osint.history.targets.v1';

export interface SavedTarget {
  value: string;
  kind: EntityKind;
  note?: string;
  addedAt: number;
  /** Highest severity this target ever produced, for the watch-list badge. */
  worst?: string;
  lastScan?: number;
}

export interface HistoryState {
  scans: ScanResult[];
}

export async function loadHistory(): Promise<ScanResult[]> {
  const s = await readJson<HistoryState>(plainStore(), SCANS, { scans: [] });
  return s.scans ?? [];
}

export async function pushScan(result: ScanResult, limit = 100): Promise<ScanResult[]> {
  const scans = [result, ...(await loadHistory())].slice(0, limit);
  await plainStore().set(SCANS, JSON.stringify({ scans }));
  return scans;
}

export async function clearHistory(): Promise<void> {
  await plainStore().set(SCANS, JSON.stringify({ scans: [] }));
}

export async function loadTargets(): Promise<SavedTarget[]> {
  const raw = await plainStore().get(TARGETS);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as SavedTarget[]) : [];
  } catch {
    return [];
  }
}

export async function saveTargets(targets: SavedTarget[]): Promise<void> {
  await plainStore().set(TARGETS, JSON.stringify(targets));
}

/**
 * Markdown report: what people actually attach to a triage note. Includes the
 * provider failure list on purpose — an absent result must be visible in the
 * export, not silently missing.
 */
export function toMarkdown(result: ScanResult): string {
  const lines: string[] = [];
  lines.push(`# OSINT lookups — ${result.entity.normalized}`);
  lines.push('');
  lines.push(`- Type: \`${result.entity.kind}\`${result.entity.rootDomain ? ` (registrable: \`${result.entity.rootDomain}\`)` : ''}`);
  lines.push(`- Scanned: ${new Date(result.startedAt).toISOString()}`);
  lines.push(`- Verdict: **${result.verdict.severity.toUpperCase()}** — ${result.verdict.summary}`);
  lines.push('');
  for (const r of result.results) {
    if (r.status === 'skipped' || r.status === 'nokey') continue;
    lines.push(`## ${r.provider} (${r.status}, ${r.ms} ms)`);
    if (r.error) lines.push(`> ${r.error.message}${r.error.hint ? ` — ${r.error.hint}` : ''}`);
    for (const f of r.findings) {
      lines.push(`- **${f.label}**: \`${f.value}\`${f.severity !== 'none' ? ` _(${f.severity})_` : ''}${f.detail ? ` — ${f.detail}` : ''}${f.link ? ` [link](${f.link})` : ''}`);
    }
    lines.push('');
  }
  const notRun = result.results.filter((r) => r.status === 'nokey' || r.status === 'skipped');
  if (notRun.length) {
    lines.push('## Not run');
    for (const r of notRun) lines.push(`- ${r.provider}: ${r.skippedReason ?? r.status}`);
    lines.push('');
  }
  lines.push('_Passive lookups only. Nothing in this report was sent to the target itself._');
  return lines.join('\n');
}

export function toCsv(result: ScanResult): string {
  const rows = [['provider', 'label', 'value', 'severity', 'detail', 'link']];
  for (const r of result.results) {
    for (const f of r.findings) {
      rows.push([r.provider, f.label, f.value, f.severity, f.detail ?? '', f.link ?? ''].map(csvCell));
    }
  }
  return rows.map((r) => r.join(',')).join('\n');
}

function csvCell(v: string): string {
  return /[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v;
}
