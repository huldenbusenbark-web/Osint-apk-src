/**
 * Shared types. Nothing in this file may import from react-native:
 * src/core/** and src/providers/** must stay runnable in Node so the
 * provider code we ship is the same code the tests exercise.
 */

export type EntityKind =
  | 'domain'
  | 'ip'
  | 'url'
  | 'email'
  | 'cidr'
  | 'phone'
  | 'hash'
  | 'asn';

export type Severity = 'none' | 'info' | 'low' | 'medium' | 'high' | 'critical';

export type ProviderId =
  | 'rdap'
  | 'dns'
  | 'ipgeo'
  | 'shodan'
  | 'abuseipdb'
  | 'leakix'
  | 'ip2whois'
  | 'dnsdumpster'
  | 'virustotal'
  | 'otx'
  | 'urlhaus'
  | 'stalkphish'
  | 'phishreport'
  | 'emailrep'
  | 'fraudlabs'
  | 'phoneparse'
  | 'exif'
  | 'scope'
  | 'custom';

/** How a finding should be weighted when the app renders a verdict. */
export type FindingKind = 'fact' | 'flag' | 'record';

export interface Finding {
  /** Stable id: provider + label + value, so repeated scans dedupe cleanly. */
  id: string;
  provider: ProviderId;
  kind: FindingKind;
  label: string;
  value: string;
  detail?: string;
  severity: Severity;
  tags?: string[];
  /** Click-through for a human (report page, whois, etc). */
  link?: string;
}

export interface EntityDescriptor {
  raw: string;
  /** Normalised: lowercased host, punycode not attempted, no trailing dot. */
  normalized: string;
  kind: EntityKind;
  /** Registrable domain for domain/url inputs, best effort. */
  rootDomain?: string;
  /** For cidr inputs. */
  cidr?: {
    network: string;
    prefix: number;
    /** Address count as string: /8 overflows Number for IPv6-ish inputs. */
    size: string;
    first: string;
    last: string;
    /** Host addresses capped by cidrLimit, always includes network+broadcast. */
    sample: string[];
    truncated: boolean;
  };
  /** For ip inputs. */
  ipVersion?: 4 | 6;
  /** For url inputs. */
  url?: { scheme: string; host: string; path: string };
  /** For email inputs. */
  email?: { local: string; domain: string };
  /** For phone inputs, filled by the phone provider. */
  phone?: { e164: string; countryCode: string; valid: boolean };
  /** For hash inputs. */
  hash?: { algorithm: 'md5' | 'sha1' | 'sha256'; hex: string };
  /** For asn inputs. */
  asn?: number;
}

export interface ScanTarget {
  value: string;
  kind: EntityKind;
}

export type ProviderStatus = 'ok' | 'skipped' | 'nokey' | 'error' | 'timeout' | 'cors';

export interface ProviderResult {
  provider: ProviderId;
  status: ProviderStatus;
  ms: number;
  findings: Finding[];
  /** Populated for error/timeout/cors so the UI can explain itself. */
  error?: { message: string; hint?: string };
  /** Set when the provider was filtered out because the entity kind is unsupported. */
  skippedReason?: string;
}

export interface ScanConfig {
  providers: ProviderId[];
  /** Hard ceiling per provider call; the scanner enforces it with a timeout. */
  perProviderTimeoutMs: number;
  /** Parallel provider calls. Keep low: free tiers rate-limit aggressively. */
  concurrency: number;
  /** Max host addresses enumerated for a CIDR input. */
  cidrLimit: number;
  /** When true, every provider except the scope check is refused for an out-of-scope target. */
  enforceScope: boolean;
  /** Raw scope text from Settings; parsed by the scanner when enforceScope is on. */
  scope: string;
  /** Returns recorded provider output instead of hitting the network. */
  demo: boolean;
}

export interface ScanResult {
  id: string;
  startedAt: number;
  finishedAt: number;
  entity: EntityDescriptor;
  results: ProviderResult[];
  verdict: {
    severity: Severity;
    flags: number;
    /** Human-readable one-liner explaining the severity. */
    summary: string;
  };
}

/** What a provider gets handed. Deliberately narrow so providers stay testable. */
export interface Attachment {
  kind: 'image' | 'file';
  uri: string;
  name?: string;
  bytes: ArrayBuffer;
  /** Only set for images the user picked from their own device. */
  fromDevice?: boolean;
}

export interface ScanContext {
  entity: EntityDescriptor;
  attachments?: Attachment[];
  config: ScanConfig;
  signal: AbortSignal;
  /** Provider key, or undefined when the user has not configured one. */
  key: string | undefined;
  secret: (name: string) => string | undefined;
  log: (msg: string) => void;
}

export interface Provider {
  id: ProviderId;
  name: string;
  /** Which entity kinds this provider can answer for. */
  entities: EntityKind[];
  requiresKey: boolean;
  /** Free-form: what the source actually is, shown in Settings. */
  blurb: string;
  docsUrl?: string;
  /** Where to sign up, so the app is self-documenting. */
  signupUrl?: string;
  /** Extra config beyond the single key (e.g. custom endpoints). */
  extraConfig?: { name: string; label: string; placeholder?: string; required?: boolean }[];
  run: (ctx: ScanContext) => Promise<Finding[]>;
}
