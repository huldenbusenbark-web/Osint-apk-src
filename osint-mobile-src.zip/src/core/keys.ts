import type { ProviderId } from './types';
import { readJson, secretStore } from './store';

const KEY = 'osint.secrets.v1';

export type SecretMap = Record<string, string>;

export const SECRET_FIELDS: Record<ProviderId, { key?: string; extra?: string[] } | undefined> = {
  rdap: undefined,
  dns: undefined,
  ipgeo: undefined,
  phoneparse: undefined,
  exif: undefined,
  scope: undefined,
  shodan: { key: 'shodanKey' },
  abuseipdb: { key: 'abuseipdbKey', extra: ['abuseipdbVersion'] },
  leakix: { key: 'leakixKey' },
  ip2whois: { key: 'ip2whoisKey' },
  dnsdumpster: { key: 'dnsdumpsterKey' },
  virustotal: { key: 'virustotalKey' },
  otx: { key: 'otxKey' },
  urlhaus: { key: 'urlhausKey', extra: ['urlhausUser'] },
  stalkphish: { key: 'stalkphishKey' },
  phishreport: { key: 'phishreportKey', extra: ['phishreportBase'] },
  emailrep: { key: 'emailrepKey' },
  fraudlabs: { key: 'fraudlabsKey', extra: ['fraudlabsId'] },
  custom: { extra: ['customProviders'] },
};

export const SECRET_LABELS: Record<string, { label: string; placeholder: string; help?: string; password: boolean }> = {
  shodanKey: { label: 'Shodan API key', placeholder: '••••••••', help: 'shodan.io → Account → API key (free tier works)', password: true },
  abuseipdbKey: { label: 'AbuseIPDB API key', placeholder: '••••••••', help: 'abuseipdb.com → Settings → API', password: true },
  abuseipdbVersion: { label: 'AbuseIPDB data version (optional)', placeholder: '2', password: false },
  leakixKey: { label: 'LeakIX API key', placeholder: '••••••••', help: 'leakix.net → Dashboard → API', password: true },
  ip2whoisKey: { label: 'IP2WHOIS key', placeholder: '••••••••', help: 'ip2whois.com → API access', password: true },
  dnsdumpsterKey: { label: 'DNSDumpster API key', placeholder: '••••••••', help: 'dnsdumpster.com → API access request', password: true },
  virustotalKey: { label: 'VirusTotal API key', placeholder: '••••••••', help: 'virustotal.com → GraphQL v2β → API key (v3 endpoints, 4 req/min)', password: true },
  otxKey: { label: 'AlienVault OTX key', placeholder: '••••••••', help: 'otx.alienvault.com → Settings → OTX API key', password: true },
  urlhausUser: { label: 'abuse.ch username', placeholder: 'you@example.com', password: false },
  urlhausKey: { label: 'abuse.ch API key', placeholder: '••••••••', help: 'Free: register at bazaar.abuse.ch → API access. Sent as `Auth: api=KEY`.', password: true },
  stalkphishKey: { label: 'StalkPhish token', placeholder: '••••••••', password: true },
  phishreportKey: { label: 'PhishReport token', placeholder: '••••••••', password: true },
  emailrepKey: { label: 'EmailRep key', placeholder: '••••••••', help: 'emailrep.io — the anonymous API is disabled now, a key is mandatory', password: true },
  fraudlabsKey: { label: 'FraudLabs Pro key', placeholder: '••••••••', help: 'fraudlabspro.com → My account → API key (free 200/month)', password: true },
  fraudlabsId: { label: 'FraudLabs account id', placeholder: '12345', password: false },
  phishreportBase: { label: 'PhishReport base URL', placeholder: 'https://…', help: 'Base host documented for your plan; the app calls {base}/check?url={entity}', password: false },
  customProviders: { label: 'Custom sources (JSON)', placeholder: '[{"name":"…","urlTemplate":"https://…/{entity}","headers":{"X-Api-Key":"{secret}"},"entities":["domain"]}]', help: 'Any REST source that answers JSON; {entity}/{key}/{value} are substituted. Add your remaining vendors here without a code change.', password: false },
};

export class KeyStore {
  private cache?: SecretMap;

  async all(): Promise<SecretMap> {
    if (!this.cache) this.cache = await readJson<SecretMap>(secretStore(), KEY, {});
    return this.cache;
  }
  async get(name: string): Promise<string | undefined> {
    const v = (await this.all())[name];
    return v && v.trim() ? v.trim() : undefined;
  }
  async set(name: string, value: string): Promise<void> {
    const map = await this.all();
    if (value.trim()) map[name] = value.trim();
    else delete map[name];
    this.cache = map;
    await secretStore().set(KEY, JSON.stringify(map));
  }
  async clear(): Promise<void> {
    this.cache = {};
    await secretStore().del(KEY);
  }
  forget(): void {
    this.cache = undefined;
  }
  /** Which declared secrets are present, for the Settings screen. */
  async status(): Promise<Record<string, boolean>> {
    const map = await this.all();
    const out: Record<string, boolean> = {};
    for (const field of Object.keys(SECRET_LABELS)) out[field] = Boolean(map[field]?.trim());
    return out;
  }
}

export const keys = new KeyStore();
