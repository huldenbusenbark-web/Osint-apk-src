export type ErrorShape = { message: string; hint?: string; kind: 'http' | 'network' | 'cors' | 'parse' | 'aborted' | 'config' };

export class OsintError extends Error {
  shape: ErrorShape;
  status?: number;
  constructor(shape: ErrorShape, status?: number) {
    super(shape.message);
    this.name = 'OsintError';
    this.shape = shape;
    this.status = status;
  }
  /** Provider status the UI should show for this failure. */
  get statusKind(): 'error' | 'timeout' | 'cors' {
    if (this.shape.kind === 'cors') return 'cors';
    if (this.shape.kind === 'aborted' && this.message !== 'Cancelled') return 'timeout';
    return 'error';
  }
}

export const CORS_HINT =
  'The browser blocked this cross-origin call. React Native on device has no CORS, so this ' +
  'only affects the web preview: run in Expo Go, or point Settings → HTTP proxy at tools/proxy.mjs.';
