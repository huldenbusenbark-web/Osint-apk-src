import { CORS_HINT, OsintError } from '../errors';

export interface HttpConfig {
  /**
   * Same-origin-less relay used only by the web build, because the browser
   * enforces CORS and rdap.org aside, none of these APIs send
   * Access-Control-Allow-Origin. On device this stays empty and every call is
   * a direct request: React Native has no CORS layer at all.
   * Set to e.g. http://127.0.0.1:8799 while `node tools/proxy.mjs` runs.
   */
  proxyBase: string;
  defaultTimeoutMs: number;
  userAgent: string;
  debug: boolean;
}

const config: HttpConfig = {
  proxyBase: '',
  defaultTimeoutMs: 12_000,
  userAgent: 'osint-mobile/1.0 (+lookup tool)',
  debug: false,
};

export function configureHttp(patch: Partial<HttpConfig>): void {
  Object.assign(config, patch);
}
export function httpConfig(): Readonly<HttpConfig> {
  return config;
}

const SENSITIVE = /^(api[-_]?key|key|authorization|token|x-api-key|auth)$/i;

export function redactHeaders(h: Record<string, string>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(h)) out[k] = SENSITIVE.test(k) ? `${v.slice(0, 3)}***len${v.length}` : v;
  return out;
}

export interface RequestOpts {
  method?: 'GET' | 'POST';
  headers?: Record<string, string>;
  body?: string;
  /** x-www-form-urlencoded shortcut; abuse.ch and VT v2 file upload use it. */
  form?: Record<string, string>;
  timeoutMs?: number;
  /** Retries for 429/5xx only. 1 means "up to 2 attempts". */
  retries?: number;
  signal?: AbortSignal;
}

export interface HttpResponse {
  status: number;
  ok: boolean;
  text: string;
  json: unknown;
  headers: Record<string, string>;
  ms: number;
}

const sleep = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    const t = setTimeout(() => resolve(), ms);
    signal?.addEventListener(
      'abort',
      () => {
        clearTimeout(t);
        reject(new OsintError({ kind: 'aborted', message: 'Cancelled' }));
      },
      { once: true },
    );
  });

function hostOf(url: string): string {
  try {
    return new URL(url).host;
  } catch {
    return url.slice(0, 24);
  }
}

function retryDelayMs(headers: Record<string, string>, attempt: number): number {
  const ra = headers['retry-after'];
  const n = ra === undefined ? NaN : Number(ra);
  if (Number.isFinite(n) && n > 0) {
    const delta = n > 1e9 ? n - Math.floor(Date.now() / 1000) : n;
    return Math.min(Math.max(delta, 1) * 1000, 25_000);
  }
  return 1_200 * 2 ** attempt;
}

/**
 * Per-host spacing. Every free tier here punishes bursts harder than volume
 * (VirusTotal 4/min, AbuseIPDB 30/min, Shodan 1/s), so a serialising queue
 * keyed on hostname is the correct primitive rather than a global semaphore.
 */
const MIN_INTERVAL = new Map<string, number>([
  ['www.virustotal.com', 15_000],
  ['api.abuseipdb.com', 2_100],
  ['api.shodan.io', 1_100],
  ['otx.alienvault.com', 1_100],
  ['urlhaus-api.abuse.ch', 1_100],
  ['emailrep.io', 1_000],
  ['leakix.net', 1_000],
  ['api.ipapi.is', 400],
]);
const lastCall = new Map<string, number>();
const chains = new Map<string, Promise<unknown>>();

export function setMinInterval(host: string, ms: number): void {
  MIN_INTERVAL.set(host, ms);
}

async function serialised<T>(host: string, fn: () => Promise<T>): Promise<T> {
  const prev = chains.get(host) ?? Promise.resolve();
  let settle!: () => void;
  chains.set(host, prev.then(() => new Promise<void>((r) => (settle = r))));
  await prev.catch(() => undefined);
  try {
    const min = MIN_INTERVAL.get(host) ?? 0;
    const wait = (lastCall.get(host) ?? 0) + min - Date.now();
    if (wait > 0) await sleep(wait);
    lastCall.set(host, Date.now());
    return await fn();
  } finally {
    settle();
  }
}

interface Raw {
  status: number;
  text: string;
  headers: Record<string, string>;
}

/** Either a direct fetch (native / CORS-open hosts) or a relayed one (web). */
async function send(url: string, init: { method: string; headers: Record<string, string>; body?: string }, signal: AbortSignal): Promise<Raw> {
  if (config.proxyBase) {
    const res = await fetch(`${config.proxyBase.replace(/\/$/, '')}/fetch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, method: init.method, headers: init.headers, body: init.body }),
      signal,
    });
    const envelope = (await res.json()) as { status?: number; headers?: Record<string, string>; body?: string; error?: string };
    if (envelope.error) throw new OsintError({ kind: 'network', message: `proxy: ${envelope.error}` });
    return { status: envelope.status ?? 0, text: envelope.body ?? '', headers: lowerKeys(envelope.headers ?? {}) };
  }
  const res = await fetch(url, { method: init.method, headers: init.headers, body: init.body, signal });
  const headers: Record<string, string> = {};
  res.headers.forEach((v, k) => (headers[k.toLowerCase()] = v));
  return { status: res.status, text: await res.text(), headers };
}

function lowerKeys(h: Record<string, string>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(h)) out[k.toLowerCase()] = v;
  return out;
}

export async function request(url: string, opts: RequestOpts = {}): Promise<HttpResponse> {
  const host = hostOf(url);
  return serialised(host, () => attempt(url, host, opts));
}

async function attempt(url: string, host: string, opts: RequestOpts): Promise<HttpResponse> {
  const headers: Record<string, string> = { Accept: 'application/json', 'User-Agent': config.userAgent, ...opts.headers };
  let body = opts.body;
  if (opts.form) {
    headers['Content-Type'] = 'application/x-www-form-urlencoded';
    body = new URLSearchParams(opts.form).toString();
  }
  const attempts = (opts.retries ?? 1) + 1;
  let lastFail: OsintError | undefined;

  for (let attemptNo = 0; attemptNo < attempts; attemptNo++) {
    const ctrl = new AbortController();
    const abortNow = () => ctrl.abort();
    const timer = setTimeout(abortNow, opts.timeoutMs ?? config.defaultTimeoutMs);
    opts.signal?.addEventListener('abort', abortNow);
    const t0 = Date.now();
    if (config.debug) console.log('[http]', opts.method ?? 'GET', url, redactHeaders(headers));

    try {
      const raw = await send(url, { method: opts.method ?? 'GET', headers, body }, ctrl.signal);
      const ms = Date.now() - t0;
      if (raw.status === 429 || raw.status >= 500) {
        lastFail = new OsintError({ kind: 'http', message: `HTTP ${raw.status} from ${host}` }, raw.status);
        if (attemptNo < attempts - 1) {
          await sleep(retryDelayMs(raw.headers, attemptNo), opts.signal);
          continue;
        }
        throw lastFail;
      }
      let json: unknown;
      if (raw.text) {
        try {
          json = JSON.parse(raw.text);
        } catch {
          json = undefined;
        }
      }
      if (raw.status >= 400 && json === undefined) {
        throw new OsintError({ kind: 'http', message: `HTTP ${raw.status} from ${host}: ${raw.text.slice(0, 160)}` }, raw.status);
      }
      return { status: raw.status, ok: raw.status >= 200 && raw.status < 300, text: raw.text, json, headers: raw.headers, ms };
    } catch (err) {
      if (err instanceof OsintError) throw err;
      const e = err as Error;
      if (e.name === 'AbortError') {
        const byUser = opts.signal?.aborted === true;
        throw new OsintError({ kind: 'aborted', message: byUser ? 'Cancelled' : `Timed out after ${opts.timeoutMs ?? config.defaultTimeoutMs} ms` });
      }
      const inBrowser = typeof globalThis === 'object' && typeof (globalThis as { document?: unknown }).document !== 'undefined';
      const corsish = inBrowser && !config.proxyBase && /failed to fetch|load failed|cors|origin/i.test(e.message || '');
      throw new OsintError({
        kind: corsish ? 'cors' : 'network',
        message: e.message || 'Network request failed',
        hint: corsish ? CORS_HINT : undefined,
      });
    } finally {
      clearTimeout(timer);
      opts.signal?.removeEventListener('abort', abortNow);
    }
  }
  throw lastFail ?? new OsintError({ kind: 'network', message: 'unreachable' });
}

export async function getJson<T = unknown>(url: string, opts: RequestOpts = {}): Promise<T> {
  return (await request(url, opts)).json as T;
}

export async function postForm<T = unknown>(url: string, form: Record<string, string>, opts: RequestOpts = {}): Promise<T> {
  return (await request(url, { ...opts, method: 'POST', form })).json as T;
}
