import { OsintError } from './errors';
import { keys, SECRET_FIELDS } from './keys';
import { inScope, parseScope } from './entity/detect';
import { maxSeverity, rank, finding } from './normalize';
import { byId, providersFor } from './registry';
import type {
  Attachment, EntityDescriptor, Finding, ProviderId, ProviderResult, ScanConfig, ScanResult, Severity,
} from './types';
import { DEMO_FINDINGS } from './demo';

export interface ScanOptions {
  entity: EntityDescriptor;
  config: ScanConfig;
  attachments?: Attachment[];
  onProviderDone?: (r: ProviderResult) => void;
  signal?: AbortSignal;
}

const SECRET_FIELD = Object.fromEntries(
  Object.entries(SECRET_FIELDS).flatMap(([id, spec]) => (spec?.key ? [[id as ProviderId, spec.key]] : [])),
) as Record<ProviderId, string | undefined>;

let seq = 0;
const nextId = () => `scan-${Date.now().toString(36)}-${(seq++).toString(36)}`;

function skipped(p: ProviderId, reason: string): ProviderResult {
  return { provider: p, status: 'skipped', ms: 0, findings: [], skippedReason: reason };
}

/**
 * Runs every applicable provider for the entity kind, bounded by
 * config.concurrency, and never lets one source take the whole scan down.
 */
export async function scan(opts: ScanOptions): Promise<ScanResult> {
  const { entity, config, attachments, onProviderDone, signal } = opts;
  const startedAt = Date.now();
  const selected = providersFor(entity.kind).filter((p) => config.providers.includes(p.id));

  // The guard rail, enforced here rather than inside a provider so that a
  // refused lookup never leaves the process at all. `scope` itself always runs:
  // the whole point is that you get told *why* nothing was queried.
  const scopeConfigured = parseScope(config.scope);
  const hasScope = scopeConfigured.domains.length + scopeConfigured.cidrs.length + scopeConfigured.ips.length + scopeConfigured.wildcards.length > 0;
  const refused = config.enforceScope && hasScope && !inScope(entity, scopeConfigured);
  const eligible = refused ? selected.filter((p) => p.id === 'scope') : selected;
  const results: ProviderResult[] = providersFor(entity.kind)
    .filter((p) => !config.providers.includes(p.id))
    .map((p) => skipped(p.id, 'disabled'));
  if (refused) {
    for (const p of selected.filter((x) => x.id !== 'scope')) {
      const r: ProviderResult = skipped(p.id, `refused: ${entity.normalized} is outside your saved scope`);
      results.push(r);
      onProviderDone?.(r);
    }
  }

  const queue = [...eligible];
  const workers: Promise<void>[] = [];

  async function worker(): Promise<void> {
    while (queue.length) {
      if (signal?.aborted) break;
      const provider = queue.shift()!;
      const t0 = Date.now();
      try {
        const needsKey = provider.requiresKey;
        const secrets = await keys.all();
        const key = needsKey ? secrets[SECRET_FIELD[provider.id] ?? '']?.trim() : undefined;
        if (needsKey && !key) {
          results.push({ provider: provider.id, status: 'nokey', ms: 0, findings: [], skippedReason: `${provider.name} needs an API key (Settings)` });
          onProviderDone?.(results[results.length - 1]!);
          continue;
        }
        if (config.demo) {
          const demo = DEMO_FINDINGS[provider.id] ?? [];
          const r: ProviderResult = { provider: provider.id, status: 'ok', ms: Date.now() - t0, findings: demo.map((f) => ({ ...f, id: `${f.id}:demo` })) };
          results.push(r);
          onProviderDone?.(r);
          continue;
        }
        const findings = await withTimeout(provider.run({
          entity,
          config,
          attachments,
          signal: signal ?? new AbortController().signal,
          key,
          secret: (name) => secrets[name]?.trim() || undefined,
          log: () => undefined,
        }), config.perProviderTimeoutMs, provider.name, signal);
        const r: ProviderResult = { provider: provider.id, status: 'ok', ms: Date.now() - t0, findings };
        results.push(r);
        onProviderDone?.(r);
      } catch (err) {
        const e = err as OsintError | Error;
        const shape = e instanceof OsintError ? e.shape : { kind: 'network' as const, message: e.message };
        const status = e instanceof OsintError ? e.statusKind : 'error';
        const r: ProviderResult = {
          provider: provider.id,
          status,
          ms: Date.now() - t0,
          findings: [],
          error: {
            message: shape.message,
            hint: shape.hint ?? hintFor(provider.id, shape.kind, e),
          },
        };
        results.push(r);
        onProviderDone?.(r);
      }
    }
  }

  for (let i = 0; i < Math.max(1, Math.min(config.concurrency, 6)); i++) workers.push(worker());
  await Promise.allSettled(workers);

  const all = results.flatMap((r) => r.findings);
  const verdict = summarise(all, results);
  return { id: nextId(), startedAt, finishedAt: Date.now(), entity, results, verdict };
}



function withTimeout<T>(p: Promise<T>, ms: number, label: string, outer?: AbortSignal): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new OsintError({ kind: 'aborted', message: `${label} exceeded ${ms} ms` })), ms);
    const onAbort = () => reject(new OsintError({ kind: 'aborted', message: 'Cancelled' }));
    outer?.addEventListener('abort', onAbort, { once: true });
    p.then(
      (v) => { clearTimeout(timer); outer?.removeEventListener('abort', onAbort); resolve(v); },
      (e) => { clearTimeout(timer); outer?.removeEventListener('abort', onAbort); reject(e); },
    );
  });
}

function hintFor(id: ProviderId, kind: string, e: unknown): string | undefined {
  const status = (e as { status?: number }).status;
  if (status === 401 || status === 403) return 'The provider rejected your key — check it in Settings, and whether your plan includes this endpoint.';
  if (status === 402) return 'This endpoint needs a paid tier on that provider.';
  if (status === 429) return 'Rate limited. The client already backed off once; space out your scans or upgrade the tier.';
  if (status === 404) return 'No record — for a registry API this can genuinely mean "unregistered".';
  if (kind === 'cors') return undefined; // OsintError already carries the CORS hint
  if (kind === 'aborted') return 'Free tiers are slow under load. Raise the per-provider timeout in Settings if this repeats.';
  return 'Endpoint unreachable from here: check connectivity, VPN, or whether the host blocks datacenter IPs.';
}

export function summarise(all: Finding[], results: ProviderResult[]): ScanResult['verdict'] {
  let severity: Severity = 'none';
  for (const f of all) if (f.kind === 'flag') severity = maxSeverity(severity, f.severity);
  const flags = all.filter((f) => f.kind === 'flag' && rank(f.severity) >= 3).length;
  const errored = results.filter((r) => r.status === 'error' || r.status === 'timeout' || r.status === 'cors').length;
  const nokey = results.filter((r) => r.status === 'nokey').length;
  const parts = [flags ? `${flags} high-signal flag${flags === 1 ? '' : 's'}` : 'no flags worth escalating'];
  if (nokey) parts.push(`${nokey} source${nokey === 1 ? '' : 's'} skipped for want of a key`);
  if (errored) parts.push(`${errored} failed`);
  return { severity, flags, summary: parts.join(' · ') };
}

/** Dedupe on id so re-scanning the same target does not double-print findings. */
export function dedupe(findings: Finding[]): Finding[] {
  const m = new Map<string, Finding>();
  for (const f of findings) if (!m.has(f.id)) m.set(f.id, f);
  return [...m.values()];
}
