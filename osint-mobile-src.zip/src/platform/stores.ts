import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';
import { configureStores, type StateStore } from '../core/store';

const PREFIX = 'osint.';

const asyncAdapter: StateStore = {
  async get(k) { return await AsyncStorage.getItem(k); },
  async set(k, v) { await AsyncStorage.setItem(k, v); },
  async del(k) { await AsyncStorage.removeItem(k); },
};

const webPlain: StateStore = {
  async get(k) { return typeof localStorage === 'undefined' ? null : localStorage.getItem(k); },
  async set(k, v) { if (typeof localStorage !== 'undefined') localStorage.setItem(k, v); },
  async del(k) { if (typeof localStorage !== 'undefined') localStorage.removeItem(k); },
};

/** Android keystore-backed; iOS keychain. Keys never land in AsyncStorage. */
const secure: StateStore = {
  async get(k) {
    try { return await SecureStore.getItemAsync(PREFIX + k.replace(/\./g, '_')); } catch { return null; }
  },
  async set(k, v) {
    try { await SecureStore.setItemAsync(PREFIX + k.replace(/\./g, '_'), v); } catch { /* locked/expired keychain */ }
  },
  async del(k) {
    try { await SecureStore.deleteItemAsync(PREFIX + k.replace(/\./g, '_')); } catch { /* ignore */ }
  },
};

export function installStores(): void {
  const onDevice = Platform.OS === 'android' || Platform.OS === 'ios';
  configureStores({
    plain: onDevice ? asyncAdapter : webPlain,
    // Web has no SecureStore equivalent: keys typed into the browser would sit
    // in localStorage, so demo mode is the recommended path for the web build.
    secret: onDevice ? secure : webPlain,
  });
}
