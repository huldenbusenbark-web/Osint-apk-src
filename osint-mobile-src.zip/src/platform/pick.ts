import * as ImagePicker from 'expo-image-picker';
import type { Attachment } from '../core/types';

/**
 * Reads picked images into ArrayBuffers for the metadata provider.
 * XHR with responseType 'arraybuffer' works for file:// URIs on React Native
 * and for blob/data URIs on web, so no expo-file-system dependency is needed.
 */
async function uriToArrayBuffer(uri: string): Promise<ArrayBuffer> {
  return await new Promise<ArrayBuffer>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', uri, true);
    xhr.responseType = 'arraybuffer';
    xhr.onload = () => (xhr.status === 200 || xhr.status === 0 ? resolve(xhr.response as ArrayBuffer) : reject(new Error(`read failed ${xhr.status}`)));
    xhr.onerror = () => reject(new Error('could not read the picked file'));
    xhr.send();
  });
}

export async function pickImages(): Promise<Attachment[]> {
  const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!perm.granted) throw new Error('Photo library permission denied — needed to read the file you pick.');
  const picked = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['images'],
    quality: 100,
    allowsMultipleSelection: true,
    selectionLimit: 4,
    // `quality: 100` plus no editing keeps the original bytes; any re-encode
    // would strip exactly the EXIF we are here to read.
    exif: true,
  });
  if (picked.canceled) return [];
  const out: Attachment[] = [];
  for (const a of picked.assets) {
    try {
      out.push({ kind: 'image', uri: a.uri, name: a.fileName ?? a.uri.split('/').pop(), bytes: await uriToArrayBuffer(a.uri), fromDevice: true });
    } catch {
      /* unreadable asset: skip rather than fail the scan */
    }
  }
  return out;
}
