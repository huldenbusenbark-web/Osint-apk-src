import { finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import type { Finding, Provider } from '../core/types';

interface IpWho {
  success: boolean;
  ip?: string;
  city?: string;
  region?: string;
  country?: string;
  country_code?: string;
  lat?: number;
  longitude?: number;
  timezone?: { id?: string; utc?: string };
  /** ipwho.is puts the ASN under `connection`; `asn` is kept for other shapes. */
  asn?: { asn?: number; org?: string; domain?: string; route?: string; type?: string };
  connection?: { asn?: number; org?: string; isp?: string; domain?: string; proxy?: boolean; tor?: boolean; hosting?: boolean; service?: string };
  message?: string;
}

interface IpApiIs {
  ip?: string;
  valid?: boolean;
  country?: string;
  country_code?: string;
  city?: string;
  latitude?: number;
  longitude?: number;
  time_zone?: { name?: string };
  asn?: { network?: string; asn?: number; organization?: string; category?: string };
  security?: {
    vpn?: boolean; proxy?: boolean; tor?: boolean; datacenter?: boolean;
    consumer_privacy_proxy?: boolean; chatgpt?: boolean; source?: string;
  };
  is_abuser?: boolean;
  blacklist?: { total_checks?: number; listed_on?: string[] };
}

export const ipgeo: Provider = {
  id: 'ipgeo',
  name: 'Geo / ASN / risk',
  entities: ['ip'],
  requiresKey: false,
  blurb: 'ipwho.is needs no key. Add an ipapi.is key for the VPN/datacenter/abuser blocklist layer.',
  signupUrl: 'https://ipapi.is/credentials.html',
  async run({ entity, key, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    const w = await getJson<IpWho>(`https://ipwho.is/${encodeURIComponent(entity.normalized)}`, { signal, timeoutMs: 9000 });
    if (w?.success) {
      const geo = [w.city, w.region, w.country].filter(Boolean).join(', ') || 'unknown';
      out.push(finding('ipgeo', 'Location', geo, { detail: [w.lat?.toFixed(3), w.longitude?.toFixed(3)].filter(Boolean).join(', ') || undefined }));
      const conn = w.connection ?? {};
      const asnNum = w.asn?.asn ?? conn.asn;
      const asnOrg = w.asn?.org ?? conn.org ?? conn.isp;
      out.push(
        finding('ipgeo', 'ASN', asnNum ? `AS${asnNum} ${asnOrg ?? ''}`.trim() : 'none', {
          severity: asnNum ? 'info' : 'none',
          detail: [w.asn?.route, w.asn?.type, conn.domain].filter(Boolean).join(' · '),
        }),
      );
      if (w.timezone?.id) out.push(finding('ipgeo', 'Timezone', w.timezone.id, { detail: w.timezone.utc }));
      const c = w.connection ?? {};
      if (c.tor) out.push(finding('ipgeo', 'Tor exit', 'yes', { kind: 'flag', severity: 'high' }));
      if (c.proxy) out.push(finding('ipgeo', 'Known proxy', 'yes', { kind: 'flag', severity: 'medium' }));
      if (c.hosting) out.push(finding('ipgeo', 'Hosting/VPS range', c.service ?? 'yes', { kind: 'flag', severity: 'low', detail: 'cloud box, not a user line — matters for both triage and fraud signals' }));
    } else if (w?.message) {
      out.push(finding('ipgeo', 'ipwho.is', w.message, { severity: 'info', detail: 'often means the address is reserved or not geolocatable' }));
    }

    if (key) {
      try {
        const a = await getJson<IpApiIs>(`https://api.ipapi.is/?q=${encodeURIComponent(entity.normalized)}&isdatacenter=1&debug=0`, { signal, headers: { Authorization: `Bearer ${key}` } });
        if (a?.valid) {
          if (a.asn?.organization) out.push(finding('ipgeo', 'ipapi.is org', `${a.asn.organization} (${a.asn.network ?? a.asn.category ?? ''})`, { detail: a.asn.category }));
          const sec = a.security ?? {};
          const on = ['vpn', 'proxy', 'tor', 'datacenter', 'consumer_privacy_proxy', 'chatgpt'].filter((k) => sec[k as keyof typeof sec] === true);
          if (on.length) out.push(finding('ipgeo', 'ipapi.is risk', on.join(', '), { kind: 'flag', severity: sec.tor ? 'high' : 'medium', detail: sec.source }));
          if (a.is_abuser) out.push(finding('ipgeo', 'Abuser', 'listed', { kind: 'flag', severity: 'high' }));
          if (a.blacklist?.listed_on?.length) {
            out.push(finding('ipgeo', 'Blocklists', `${a.blacklist.total_checks ?? a.blacklist.listed_on.length} checks; ${a.blacklist.listed_on.slice(0, 8).join(', ')}`, { kind: 'flag', severity: 'medium' }));
          }
        }
      } catch (err) {
        const e = err as { status?: number };
        if (e.status === 401 || e.status === 403) {
          out.push(finding('ipgeo', 'ipapi.is', 'key rejected', { severity: 'low', detail: '401/403 — check the token in Settings' }));
        } else throw err;
      }
    } else {
      out.push(finding('ipgeo', 'ipapi.is', 'not queried', { severity: 'none', detail: 'free key at ipapi.is unlocks proxy/VPN/datacenter/blocklist fields' }));
    }
    return out;
  },
};
