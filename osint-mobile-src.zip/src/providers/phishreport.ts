import { finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import type { Finding, Provider } from '../core/types';

/**
 * Vendor endpoints that are behind your account tier and not publicly
 * documented get the same generic treatment as a Custom source, but keep their
 * own row in Settings: base URL + bearer token, {entity} substituted.
 * Point Base URL at whatever host PhishReport documents for your plan.
 */
export const phishreport: Provider = {
  id: 'phishreport',
  name: 'PhishReport',
  entities: ['url', 'domain', 'ip', 'email'],
  requiresKey: true,
  blurb: 'Generic JSON check: {base}/check?url={entity} with a bearer token. Set the base URL for your plan.',
  extraConfig: [{ name: 'phishreportBase', label: 'Base URL', placeholder: 'https://…', required: true }],
  async run({ entity, key, secret, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    const base = (secret('phishreportBase') ?? '').replace(/\/$/, '');
    if (!base) return [finding('phishreport', 'Not configured', 'no base URL', { severity: 'low', detail: 'Settings → PhishReport → Base URL' })];
    const value = entity.kind === 'url' ? entity.normalized : entity.normalized;
    const r = await getJson<Record<string, unknown>>(`${base}/check?url=${encodeURIComponent(value)}`, { signal, headers: { Authorization: `Bearer ${key ?? ''}` } });
    const bools = Object.entries(r).filter(([, v]) => typeof v === 'boolean');
    const listed = bools.filter(([, v]) => v === true).map(([k]) => k);
    out.push(
      finding('phishreport', 'Verdict', listed.length ? listed.join(', ') : 'clean', {
        kind: listed.length ? 'flag' : 'fact',
        severity: listed.length ? 'high' : 'none',
        detail: JSON.stringify(r).slice(0, 240),
      }),
    );
    for (const [k, v] of Object.entries(r).slice(0, 20)) {
      if (typeof v === 'boolean') continue;
      out.push(finding('phishreport', k, Array.isArray(v) ? v.slice(0, 6).join(', ') : String(v), { severity: 'info' }));
    }
    return out;
  },
};
