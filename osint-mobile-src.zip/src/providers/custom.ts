import { keys } from '../core/keys';
import { finding } from '../core/normalize';
import { request } from '../core/net/http';
import type { EntityKind, Finding, Provider } from '../core/types';

interface CustomDef {
  name: string;
  urlTemplate: string;
  method?: 'GET' | 'POST';
  headers?: Record<string, string>;
  entities?: EntityKind[];
  keySecret?: string;
  /** dot path into the response where the interesting object lives */
  resultPath?: string;
}

function flatten(prefix: string, value: unknown, out: Finding[], cap = 40): void {
  if (out.length >= cap || value === null || value === undefined) return;
  if (typeof value !== 'object') {
    const str = String(value);
    if (str === '' || str === '0' || typeof value === 'boolean' && !value) return;
    out.push(finding('custom', prefix || 'value', str.slice(0, 200), { severity: 'info' }));
    return;
  }
  if (Array.isArray(value)) {
    if (value.length) out.push(finding('custom', `${prefix} count`, String(value.length), { severity: 'info' }));
    value.slice(0, 6).forEach((v, i) => flatten(`${prefix}[${i}]`, v, out, cap));
    return;
  }
  for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
    flatten(prefix ? `${prefix}.${k}` : k, v, out, cap);
  }
}

/**
 * The escape hatch: any REST source that answers JSON, configured from
 * Settings, no rebuild. Placeholders: {entity} {normalized} {value}
 * {rootDomain} {ip} {domain} {secret}.
 */
export const custom: Provider = {
  id: 'custom',
  name: 'Custom sources',
  entities: ['domain', 'ip', 'url', 'email', 'cidr', 'phone', 'hash', 'asn'],
  requiresKey: false,
  blurb: 'Add any other vendor (Pentest-Tools, Phish.surf, internal lookups) from Settings as JSON.',
  extraConfig: [{ name: 'customProviders', label: 'Definitions (JSON array)', required: true }],
  async run({ entity, secret, signal }): Promise<Finding[]> {
    const raw = secret('customProviders');
    if (!raw) return [finding('custom', 'Not configured', 'no definitions', { severity: 'none', detail: 'Settings → Custom sources' })];
    let defs: CustomDef[];
    try {
      defs = JSON.parse(raw) as CustomDef[];
      if (!Array.isArray(defs)) throw new Error('expected an array');
    } catch (err) {
      return [finding('custom', 'Config error', (err as Error).message, { kind: 'flag', severity: 'high', detail: 'customProviders must be a JSON array' })];
    }
    const out: Finding[] = [];
    for (const def of defs) {
      if (def.entities?.length && !def.entities.includes(entity.kind)) continue;
      const secretValue = def.keySecret ? await keys.get(def.keySecret) ?? '' : '';
      const vars: Record<string, string> = {
        entity: entity.normalized,
        normalized: entity.normalized,
        value: entity.normalized,
        rootDomain: entity.rootDomain ?? entity.normalized,
        ip: entity.kind === 'ip' ? entity.normalized : '',
        domain: entity.kind === 'domain' || entity.kind === 'url' ? entity.rootDomain ?? entity.normalized : entity.normalized,
        secret: secretValue,
      };
      const fill = (tpl: string, encode: boolean): string =>
        tpl.replace(/\{(\w+)\}/g, (whole, name: string) => {
          if (!(name in vars)) return whole;
          const v = vars[name] ?? '';
          return encode && name !== 'secret' ? encodeURIComponent(v) : v;
        });

      const url = fill(def.urlTemplate, true);
      const headers: Record<string, string> = {};
      for (const [k, v] of Object.entries(def.headers ?? {})) headers[k] = fill(v, false);

      try {
        const res = await request(url, { method: def.method ?? 'GET', headers, signal });
        let node: unknown = res.json;
        for (const seg of (def.resultPath ?? '').split('.').filter(Boolean)) {
          node = (node as Record<string, unknown>)?.[seg];
        }
        const found: Finding[] = [];
        flatten(def.name, node, found, 40);
        if (!found.length) {
          out.push(finding('custom', def.name, 'empty response', { severity: 'none', detail: `${res.status} ${url.slice(0, 120)}` }));
        } else {
          out.push(...found.map((f) => ({ ...f, label: f.label === 'value' ? def.name : f.label })));
        }
      } catch (err) {
        out.push(finding('custom', def.name, `failed: ${(err as Error).message}`, { kind: 'flag', severity: 'low', detail: url.slice(0, 160) }));
      }
    }
    return out;
  },
};
