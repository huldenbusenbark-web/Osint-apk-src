import { finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import type { Finding, Provider } from '../core/types';

const BASE = 'https://api.fraudlabspro.com/v1';

type Resp = Record<string, string | number | boolean | undefined>;

function flatten(r: Resp): Finding[] {
  const out: Finding[] = [];
  for (const [k, v] of Object.entries(r)) {
    if (v === undefined || v === null || k === 'Status' && v === 'OK') continue;
    if (/^(ApiVersion|QueryTime|CreditsRemaining|Id)$/i.test(k)) continue;
    out.push(finding('fraudlabs', k, String(v), { severity: 'info' }));
  }
  return out;
}

/**
 * Fraud scoring per entity type. One provider because it is one account, one
 * quota and one shape of answer, and because cross-checking the IP and the
 * email on the same transaction is the actual workflow.
 */
export const fraudlabs: Provider = {
  id: 'fraudlabs',
  name: 'FraudLabs Pro',
  entities: ['ip', 'email', 'domain', 'phone'],
  requiresKey: true,
  blurb: 'Transaction risk scoring: IP scheme/blocklists, email toxicity, domain age, phone line type.',
  signupUrl: 'https://www.fraudlabspro.com/member/api-key',
  extraConfig: [{ name: 'fraudlabsId', label: 'FraudLabs account id', placeholder: '12345' }],
  async run({ entity, key, secret, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    const id = secret('fraudlabsId');
    if (!id) return [finding('fraudlabs', 'Not configured', 'missing account id', { severity: 'low', detail: 'FraudLabs needs both key and id — Settings → FraudLabs Pro' })];
    const route = entity.kind === 'ip' ? 'ip-lookup' : entity.kind === 'email' ? 'email-intelligence' : entity.kind === 'domain' ? 'domain-intelligence' : 'phone-intelligence';
    const param = entity.kind === 'ip' ? 'ip' : entity.kind === 'email' ? 'email' : entity.kind === 'domain' ? 'domain' : 'phone_number';
    const value = entity.kind === 'domain' ? entity.rootDomain ?? entity.normalized : entity.normalized;
    const r = await getJson<Resp>(`${BASE}/${route}?key=${encodeURIComponent(key ?? '')}&id=${encodeURIComponent(id)}&${param}=${encodeURIComponent(value)}&format=json`, { signal });
    const status = String(r.Status ?? '');
    if (status && status !== 'OK') return [finding('fraudlabs', 'API error', status, { severity: 'low', detail: String(r.Message ?? '') })];

    const risk = Number(r.RiskScore ?? 0);
    if (r.RiskScore !== undefined) {
      out.push(finding('fraudlabs', 'Risk score', `${risk}/100 (${r.Risk ?? '?'}), recommend ${r.Recommendation ?? '?'}`, {
        kind: 'flag',
        severity: risk >= 80 ? 'critical' : risk >= 60 ? 'high' : risk >= 40 ? 'medium' : risk >= 20 ? 'low' : 'none',
      }));
    }
    const blocks = Object.entries(r).filter(([k]) => /^(Country|State|City)/i.test(k) || /Block$/i.test(k));
    for (const [k, v] of blocks) {
      if (/Block$/i.test(k)) out.push(finding('fraudlabs', k.replace(/Block$/i, '') + ' blocked', String(v), { kind: 'flag', severity: v === 'True' || v === 'Yes' ? 'high' : 'none' }));
    }
    if (r.Scheme) out.push(finding('fraudlabs', 'IP scheme', String(r.Scheme), { kind: r.Scheme === 'Public Access Point' ? 'flag' : 'fact', severity: r.Scheme === 'Data Center' ? 'medium' : 'info' }));
    if (entity.kind === 'email') {
      if (r.Toxicity) out.push(finding('fraudlabs', 'Toxicity', String(r.Toxicity), { kind: 'flag', severity: Number(r.Toxicity) > 50 ? 'high' : 'low' }));
      if (r.EmailFirstSeen) out.push(finding('fraudlabs', 'First seen', String(r.EmailFirstSeen), { severity: 'info', detail: 'a never-seen address plus a fresh domain is the classic throwaway pattern' }));
    }
    if (entity.kind === 'domain') {
      if (r.DomainAgeDays !== undefined) {
        const days = Number(r.DomainAgeDays);
        out.push(finding('fraudlabs', 'Domain age', `${days} days`, { kind: 'flag', severity: days < 30 ? 'high' : days < 90 ? 'medium' : 'none', detail: days < 30 ? 'registered inside a month — treat lookalike/phishing claims accordingly' : undefined }));
      }
      if (r.FreeDomain === 'True') out.push(finding('fraudlabs', 'Free domain', String(r.SLD ?? ''), { kind: 'flag', severity: 'medium' }));
      if (r.RecentWhoisUpdate === 'True') out.push(finding('fraudlabs', 'WHOIS recently updated', 'yes', { kind: 'flag', severity: 'low' }));
    }
    const rest = flatten(r).filter((f) => !out.some((o) => o.label === f.label));
    out.push(...rest.slice(0, 12));
    return out;
  },
};
