import { finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import type { Finding, Provider } from '../core/types';

interface Dumpster {
  domain?: string;
  dns_a?: { ip?: string; ptr?: string; country?: string; location?: string }[];
  dns_aaaa?: { ipv6?: string; ptr?: string }[];
  dns_mx?: { name?: string; priority?: string }[];
  dns_ns?: { name?: string; country?: string }[];
  dns_txt?: { txt?: string }[];
  hosts?: { host?: string; type?: string; ip?: string; country?: string; ptr?: string }[];
}

const INTERESTING = /(api|admin|internal|staging|stage|dev|test|vpn|git|jenkins|jira|console|dashboard|ssh|db|mysql|mongo|redis|backup|auth|sso|kibana|grafana|nacos|config)/i;

/**
 * Passive only: DNSDumpster answers from its own cached scans, so unlike an
 * active subdomain brute-force this puts no load on the target.
 */
export const dnsdumpster: Provider = {
  id: 'dnsdumpster',
  name: 'DNSDumpster',
  entities: ['domain'],
  requiresKey: true,
  blurb: 'Official API (X-API-Key): cached host records, so you get a subdomain list without touching the target.',
  signupUrl: 'https://dnsdumpster.com/developer/',
  async run({ entity, key, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    const root = entity.rootDomain ?? entity.normalized;
    const r = await getJson<Dumpster>(`https://api.dnsdumpster.com/domain/${encodeURIComponent(root)}`, { signal, headers: { 'X-API-Key': key ?? '' } });
    const hosts = r.hosts ?? [];
    out.push(finding('dnsdumpster', 'Host records', String(hosts.length), { severity: 'info', detail: `${new Set(hosts.map((h) => h.ip)).size} distinct IPs` }));
    const subs = [...new Set(hosts.map((h) => h.host).filter((h): h is string => !!h))];
    if (subs.length) out.push(finding('dnsdumpster', 'Subdomains', subs.slice(0, 40).join(', '), { detail: subs.length > 40 ? `+${subs.length - 40} more` : undefined }));
    const juicy = subs.filter((s) => INTERESTING.test(s));
    if (juicy.length) out.push(finding('dnsdumpster', 'Interesting names', juicy.join(', '), { kind: 'flag', severity: 'low', detail: 'names that are commonly forgotten, over-permissioned, or out of scope of the main config' }));
    for (const a of (r.dns_a ?? []).slice(0, 10)) {
      const extra = [a.country, a.location].filter(Boolean).join(' ');
      out.push(finding('dnsdumpster', `A ${a.ip ?? '?'}`, a.ptr ?? extra ?? 'no PTR', { severity: 'none' }));
    }
    if (r.dns_mx?.length) out.push(finding('dnsdumpster', 'MX', r.dns_mx.map((m) => `${m.priority ?? '?'} ${m.name}`).join(', ')));
    if (r.dns_txt?.length) out.push(finding('dnsdumpster', 'TXT', r.dns_txt.map((t) => t.txt).filter(Boolean).join(' | ').slice(0, 200)));
    return out;
  },
};
