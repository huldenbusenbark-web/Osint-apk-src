import { fmtDate, finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import type { Finding, Provider } from '../core/types';

const BASE = 'https://otx.alienvault.com/api/v1/indicators';

function indicatorType(kind: string): string {
  return kind === 'ip' ? 'IPv4' : kind === 'domain' ? 'domain' : 'url';
}

/** Each OTX section 404s independently, so a missing section must not sink the provider. */
async function section<T>(type: string, value: string, name: string, key: string, signal: AbortSignal): Promise<T | undefined> {
  try {
    return await getJson<T>(`${BASE}/${type}/${encodeURIComponent(value)}/${name}`, { signal, headers: { 'X-OTX-API-KEY': key } });
  } catch (err) {
    const e = err as { status?: number };
    if (e.status === 404 || e.status === 403 || e.status === 400) return undefined;
    throw err;
  }
}

export const otx: Provider = {
  id: 'otx',
  name: 'AlienVault OTX',
  entities: ['domain', 'ip', 'url'],
  requiresKey: true,
  blurb: 'Pulses, passive DNS and the URL list. Best single source for "is this asset in a shared threat feed".',
  signupUrl: 'https://otx.alienvault.com/api',
  async run({ entity, key, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    const type = indicatorType(entity.kind);
    const value = entity.kind === 'url' ? entity.normalized : entity.kind === 'domain' ? entity.rootDomain ?? entity.normalized : entity.normalized;

    const general = await section<{
      id?: string; base_domain?: string;alexa_ranking?: number; country?: string;
      notifiable?: boolean; whois?: string; pulse_info?: { count?: number; name?: string[] };
      ports?: string[]; subdomain_count?: number; malware_count?: number;
    }>(type, value, 'general', key ?? '', signal);

    if (general?.notifiable) out.push(finding('otx', 'OTX notifiable', 'yes', { kind: 'flag', severity: 'high', detail: 'AlienVault marks this indicator as actively malicious' }));
    if (general?.alexa_ranking !== undefined) out.push(finding('otx', 'Alexa rank', general.alexa_ranking ? String(general.alexa_ranking) : 'unranked', { severity: general.alexa_ranking ? 'none' : 'low', detail: general.alexa_ranking ? undefined : 'throwaway-looking: never ranked' }));
    if (general?.country) out.push(finding('otx', 'Country (OTX)', general.country));
    if (general?.subdomain_count) out.push(finding('otx', 'Known subdomains', String(general.subdomain_count), { severity: 'info' }));
    if (general?.malware_count) out.push(finding('otx', 'Malware samples tied to it', String(general.malware_count), { kind: 'flag', severity: 'critical' }));
    if (general?.pulse_info?.count) {
      out.push(finding('otx', 'Pulses referencing it', `${general.pulse_info.count}: ${(general.pulse_info.name ?? []).slice(0, 4).join(' | ')}`.slice(0, 220), { kind: 'flag', severity: 'medium', link: `https://otx.alienvault.com/indicator/${type === 'IPv4' ? 'ip' : 'domain'}/${encodeURIComponent(value)}` }));
    }

    const pdns = await section<{ count?: number; url?: { first_detected?: string; last_detected?: string; rrtype?: string; rdata?: string }[] }>(
      type,
      value,
      'passive_dns',
      key ?? '',
      signal,
    );
    const rows = pdns?.url ?? [];
    if (rows.length) {
      const first = rows[rows.length - 1]?.first_detected;
      const last = rows[0]?.last_detected;
      const rrtypes = [...new Set(rows.map((r) => r.rrtype).filter((x): x is string => !!x))];
      out.push(finding('otx', 'Passive DNS', `${pdns?.count ?? rows.length} records`, { severity: 'info', detail: `${first ?? '?'} → ${last ?? '?'}` }));
      const ips = [...new Set(rows.filter((r) => r.rrtype === 'A').map((r) => r.rdata).filter((x): x is string => !!x))];
      if (ips.length) out.push(finding('otx', 'Historical IPs', ips.slice(0, 12).join(', '), { detail: rrtypes.length ? `types: ${rrtypes.join('/')}` : undefined }));
      const old = rows.filter((r) => { const t = r.last_detected ? new Date(r.last_detected).getTime() : NaN; return Number.isFinite(t) && Date.now() - t > 365 * 864e5; });
      if (old.length) out.push(finding('otx', 'Stale DNS', `${old.length} records last seen over a year ago`, { kind: 'flag', severity: 'low', detail: 'historical resolutions often point at forgotten hosting' }));
    }

    if (type !== 'IPv4') {
      const urls = await section<{ count?: number; url?: { url?: string; host?: string; status?: number }[] }>(type, value, 'url_list', key ?? '', signal);
      const list = urls?.url ?? [];
      out.push(finding('otx', 'Indexed URLs', String(urls?.count ?? list.length), { kind: list.some((u) => (u.status ?? 200) >= 500 || (u.status ?? 0) === 404) ? 'flag' : 'fact', severity: 'info' }));
      for (const u of list.slice(0, 6)) out.push(finding('otx', 'URL', `${u.url ?? u.host ?? '?'} → ${u.status ?? '?'}`, { severity: 'none' }));
    }
    if (!out.length) out.push(finding('otx', 'OTX result', 'no data', { severity: 'none', detail: 'the indicator is clean or unknown to OTX — not the same as "verified safe"' }));
    return out;
  },
};
