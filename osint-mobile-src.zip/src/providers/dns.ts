import { finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import type { DnsSet } from '../core/dns-records';
import { rootDomain } from '../core/entity/detect';
import type { Finding, Provider } from '../core/types';

const GOOGLE = (name: string, type: string) => `https://dns.google/resolve?name=${encodeURIComponent(name)}&type=${type}`;
const CLOUDFLARE = (name: string, type: string) => `https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(name)}&type=${type}`;

async function look(name: string, type: string, signal: AbortSignal): Promise<DnsSet> {
  const parse = (j: { Status?: number; Answer?: DnsSet['answers'] }, statusName: string): DnsSet => ({
    type,
    status: j.Status ?? 0,
    statusName,
    answers: (j.Answer ?? []).map((a) => ({ name: a.name, type: a.type, TTL: a.TTL, data: a.data })),
  });
  try {
    const j = await getJson<{ Status: number; Answer?: DnsSet['answers'] }>(GOOGLE(name, type), { signal, timeoutMs: 8000 });
    return parse(j, ['NOERROR', 'FORMERR', 'SERVFAIL', 'NXDOMAIN', 'NOTIMP'][j.Status] ?? String(j.Status));
  } catch {
    const j = await getJson<{ Status: number; Answer?: DnsSet['answers'] }>(CLOUDFLARE(name, type), {
      signal,
      headers: { Accept: 'application/dns-json' },
      timeoutMs: 8000,
    });
    return parse(j, String(j.Status ?? 0));
  }
}

/**
 * All queries run against public resolvers, never against the target's own
 * NS: that keeps the app a passive client and avoids sending the asset owner
 * a signal that they are being looked at.
 */
export const dns: Provider = {
  id: 'dns',
  name: 'DNS records',
  entities: ['domain', 'ip'],
  requiresKey: false,
  blurb: 'Google DoH (Cloudflare fallback): A/AAAA/MX/TXT/NS/CAA/SOA + DMARC, SPF and wildcard checks.',
  async run({ entity, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    if (entity.kind === 'ip') {
      const ptr = await look(entity.normalized.split('.').reverse().join('.') + '.in-addr.arpa', 'PTR', signal);
      if (ptr.answers.length) out.push(finding('dns', 'PTR', ptr.answers.map((a) => a.data).join(', ')));
      else out.push(finding('dns', 'PTR', 'no reverse record', { severity: 'info', detail: 'common for cloud ranges, notable on mail infrastructure' }));
      return out;
    }

    const host = entity.normalized;
    const root = entity.rootDomain ?? rootDomain(host);
    const types = host === root ? ['A', 'AAAA', 'MX', 'TXT', 'NS', 'SOA', 'CAA'] : ['A', 'AAAA', 'CNAME', 'TXT'];
    const sets = await Promise.all(types.map((t) => look(host, t, signal).catch(() => undefined)));

    for (const s of sets) {
      if (!s) continue;
      if (s.statusName === 'NXDOMAIN') {
        out.push(finding('dns', 'Resolution', `${host} is NXDOMAIN`, { kind: 'flag', severity: 'high', detail: 'nothing is authoritative for this name — a CNAME pointing here is a takeover candidate' }));
        continue;
      }
      if (!s.answers.length) continue;
      if (s.type === 'MX') {
        out.push(finding('dns', 'MX', s.answers.map((a) => a.data).join(' | '), { detail: 'priority exchange target' }));
      } else if (s.type === 'SOA') {
        out.push(finding('dns', 'SOA', s.answers[0]!.data.split(' ')[0] ?? s.answers[0]!.data, { detail: 'primary NS' }));
      } else if (s.type === 'CAA') {
        out.push(finding('dns', 'CAA', s.answers.map((a) => a.data).join(' | ')));
      } else {
        const vals = s.answers.map((a) => (s.type === 'TXT' ? a.data.replace(/^"|"$/g, '') : a.data));
        out.push(finding('dns', s.type, [...new Set(vals)].join(', '), { detail: `TTL ${s.answers[0]!.TTL}s` }));
      }
    }

    const dmarc = await look(`_dmarc.${root}`, 'TXT', signal).catch(() => undefined);
    if (!dmarc?.answers.length) {
      out.push(finding('dns', 'DMARC', 'missing', { kind: 'flag', severity: 'medium', detail: `no _dmarc.${root} — the brand can be spoofed from any sender` }));
    } else {
      const rec = dmarc.answers[0]!.data.replace(/^"|"$/g, '');
      const p = /p=(none|quarantine|reject)/i.exec(rec)?.[1]?.toLowerCase();
      out.push(
        finding('dns', 'DMARC', rec, {
          kind: 'flag',
          severity: p === 'reject' ? 'none' : p === 'quarantine' ? 'low' : p === 'none' ? 'low' : 'medium',
          detail: p === 'reject' ? 'enforced' : p === 'none' ? 'monitoring only — reports exist, nothing blocks' : `policy ${p ?? 'unknown'}`,
        }),
      );
    }

    const txt = await look(root, 'TXT', signal).catch(() => undefined);
    const hasSpf = (txt?.answers ?? []).some((a) => /v=spf1/i.test(a.data));
    out.push(
      finding('dns', 'SPF', hasSpf ? (txt!.answers.find((a) => /v=spf1/i.test(a.data))!.data.replace(/^"|"$/g, '')).slice(0, 180) : 'missing', {
        kind: 'flag',
        severity: hasSpf ? (/(\+all|~all)/i.test(txt!.answers[0]!.data) ? 'medium' : 'none') : 'medium',
        detail: hasSpf ? ('+all/~all pass ~everything through; -hardfail is the safe form' ) : 'no TXT record containing v=spf1',
      }),
    );

    const rnd = `_osint${Math.floor(Math.random() * 1e6)}.${host}`;
    const wild = await look(rnd, 'A', signal).catch(() => undefined);
    if (wild && wild.statusName !== 'NXDOMAIN' && wild.answers.length) {
      out.push(finding('dns', 'Wildcard DNS', `* resolves to ${wild.answers[0]!.data}`, { kind: 'flag', severity: 'low', detail: 'every nonexistent name answers, so dangling-subdomain checks are unreliable here' }));
    }
    return out;
  },
};
