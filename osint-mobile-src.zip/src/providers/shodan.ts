import { fmtDate, finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import type { Finding, Provider, Severity } from '../core/types';

interface Host {
  error?: string;
  ip?: number;
  ports?: number[];
  hostnames?: string[];
  domains?: string[];
  org?: string;
  isp?: string;
  os?: string;
  last_update?: string;
  vulns?: Record<string, { cvss?: number; verified?: boolean }>;
  strings?: Record<string, { proto?: string; product?: string; version?: string; port?: number; ssl?: boolean; banner?: string }>;
}

const RISKY = new Map<number, { label: string; sev: Severity }>([
  [23, { label: 'Telnet', sev: 'high' }], [21, { label: 'FTP', sev: 'medium' }], [3389, { label: 'RDP', sev: 'high' }],
  [22, { label: 'SSH', sev: 'none' }], [445, { label: 'SMB', sev: 'high' }], [1433, { label: 'MSSQL', sev: 'high' }],
  [3306, { label: 'MySQL', sev: 'high' }], [5432, { label: 'Postgres', sev: 'high' }], [6379, { label: 'Redis', sev: 'high' }],
  [27017, { label: 'MongoDB', sev: 'high' }], [9200, { label: 'Elasticsearch', sev: 'high' }], [5984, { label: 'CouchDB', sev: 'high' }],
  [11211, { label: 'Memcached', sev: 'high' }], [5900, { label: 'VNC', sev: 'high' }], [25, { label: 'SMTP', sev: 'none' }],
]);

export const shodan: Provider = {
  id: 'shodan',
  name: 'Shodan',
  entities: ['ip', 'domain'],
  requiresKey: true,
  blurb: 'Observed-open ports and banners from Shodan crawler data — passive, so no packets reach the asset.',
  signupUrl: 'https://www.shodan.io/account/profile',
  async run({ entity, key, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    const hdr = { Authorization: `key ${key ?? ''}` };

    if (entity.kind === 'ip') {
      const h = await getJson<Host>(`https://api.shodan.io/hosts/${entity.normalized}?minify=true`, { signal, headers: hdr });
      if (h?.error) throw new Error(String(h.error));
      const ports = h.ports ?? [];
      out.push(finding('shodan', 'Ports seen open', ports.length ? ports.join(', ') : 'none', { severity: ports.length ? 'info' : 'none', detail: `last crawl ${fmtDate(h.last_update)}` }));
      for (const p of ports) {
        const risk = RISKY.get(p);
        if (risk && risk.sev !== 'none') out.push(finding('shodan', `Exposed ${risk.label}`, `:${p}`, { kind: 'flag', severity: risk.sev }));
      }
      for (const [port, s] of Object.entries(h.strings ?? {})) {
        const banner = [s.product, s.version].filter(Boolean).join(' ') || s.proto || 'unknown';
        out.push(finding('shodan', `Banner ${port}`, banner, { detail: [s.ssl ? 'TLS' : 'plaintext', s.banner?.replace(/\s+/g, ' ').slice(0, 140)].filter(Boolean).join(' · ') }));
      }
      const vulns = Object.entries(h.vulns ?? {});
      if (vulns.length) {
        const worst = Math.max(...vulns.map(([, v]) => v.cvss ?? 0));
        out.push(finding('shodan', 'Known CVEs', `${vulns.length} — ${vulns.slice(0, 6).map(([cve, v]) => `${cve}${v.cvss ? `(${v.cvss})` : ''}`).join(', ')}`, {
          kind: 'flag',
          severity: worst >= 9 ? 'critical' : worst >= 7 ? 'high' : 'medium',
          detail: `${vulns.filter(([, v]) => v.verified).length} Shodan-verified`,
        }));
      }
      if (h.org || h.isp) out.push(finding('shodan', 'Owner', [h.org, h.isp].filter(Boolean).join(' · ')));
      if (h.os && h.os !== 'Not available (reason unspecified)') out.push(finding('shodan', 'OS', h.os));
      return out;
    }

    // domain -> everything Shodan has indexed for the registered domain
    const root = entity.rootDomain ?? entity.normalized;
    const r = await getJson<{ matches?: Host[]; total?: number; error?: string }>(
      `https://api.shodan.io/shodan/host/search?query=hostname:${root}&facets=country,org&minify=true`,
      { signal, headers: hdr },
    );
    if (r?.error) throw new Error(String(r.error));
    const matches = r.matches ?? [];
    out.push(finding('shodan', 'Indexed hosts', String(r.total ?? matches.length), { detail: `first ${matches.length} returned` }));
    for (const m of matches.slice(0, 12)) {
      const ip = typeof m.ip === 'number' ? dotted(m.ip >>> 0) : '?';
      const ports = (m.ports ?? []).join('/');
      out.push(finding('shodan', `Host ${ip}`, `${ports}${m.org ? ` · ${m.org}` : ''}`, { severity: m.vulns ? 'high' : 'info', kind: m.vulns ? 'flag' : 'fact' }));
    }
    return out;
  },
};

function dotted(n: number): string {
  return [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.');
}
