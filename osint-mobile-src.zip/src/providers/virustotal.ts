import { fmtDate, finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import { sha256Base64Url } from '../core/crypto';
import type { Finding, Provider } from '../core/types';

interface Attrs {
  last_analysis_stats?: { harmless?: number; malicious?: number; suspicious?: number; undetected?: number; timeout?: number };
  total_votes?: { harmless?: number; malicious?: number };
  reputation?: number;
  categories?: Record<string, string>;
  creation_date?: number;
  last_modification_date?: number;
  admin_comments?: string;
  tags?: string[];
  jarm?: string;
  country?: string;
  asn?: number;
  asn_owner?: string;
  last_dns_records?: { type: string; value: string }[];
  size?: number;
  sha256?: string;
  md5?: string;
  type_description?: string;
  times_submitted?: number;
  popularity?: number;
  trid?: { type_desc?: string }[];
  name?: string;
  names?: string[];
  sandbox_verdicts?: Record<string, { verdict?: string; malware_category?: string }>;
}

function verdictFindings(id: Provider['id'], label: string, a: Attrs, permalink: string): Finding[] {
  const s = a.last_analysis_stats ?? {};
  const mal = s.malicious ?? 0;
  const sus = s.suspicious ?? 0;
  const out: Finding[] = [
    finding(id, label, `${mal} malicious / ${sus} suspicious / ${s.harmless ?? 0} clean`, {
      kind: mal || sus ? 'flag' : 'fact',
      severity: mal >= 10 ? 'critical' : mal > 0 ? 'high' : sus > 0 ? 'medium' : 'none',
      detail: a.last_modification_date ? `last analysed ${fmtDate(new Date(a.last_modification_date * 1000).toISOString())}` : undefined,
      link: permalink,
    }),
  ];
  if (a.reputation !== undefined) out.push(finding(id, 'Reputation', String(a.reputation), { severity: a.reputation < 0 ? 'low' : 'none' }));
  const cats = Object.entries(a.categories ?? {});
  if (cats.length) out.push(finding(id, 'Categories', cats.map(([k, v]) => `${k}=${v}`).join(', ').slice(0, 200), { kind: cats.some(([, v]) => /mal|phish|spam/i.test(v)) ? 'flag' : 'fact', severity: cats.some(([, v]) => /phish|malware/i.test(v)) ? 'high' : 'info' }));
  if (a.tags?.length) out.push(finding(id, 'Tags', a.tags.join(', '), { kind: a.tags.some((t) => /phishing|malicious|c2/i.test(t)) ? 'flag' : 'fact', severity: a.tags.some((t) => /phishing/i.test(t)) ? 'high' : 'info' }));
  if (a.admin_comments) out.push(finding(id, 'Analyst notes', a.admin_comments.slice(0, 300)));
  return out;
}

export const virustotal: Provider = {
  id: 'virustotal',
  name: 'VirusTotal v3',
  entities: ['domain', 'ip', 'url', 'hash'],
  requiresKey: true,
  blurb: 'Engine verdicts, categories and tags. Free key is 4 req/min — the client spaces calls automatically.',
  signupUrl: 'https://www.virustotal.com/gui/my-apikey',
  async run({ entity, key, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    const headers = { 'X-Apikey': key ?? '' };
    const opts = { signal, headers };
    const H = 'https://www.virustotal.com/api/v3';

    if (entity.kind === 'hash' && entity.hash) {
      const r = await getJson<{ data?: { attributes?: Attrs; id?: string } }>(`${H}/files/${entity.hash.hex}`, opts);
      const a = r.data?.attributes;
      if (!a) return [finding('virustotal', 'File', 'no report', { severity: 'low', detail: 'never seen by VT — worth /files/scan for a live submission' })];
      out.push(...verdictFindings('virustotal', 'Engines', a, `https://www.virustotal.com/gui/file/${entity.hash.hex}`));
      out.push(finding('virustotal', 'Type', a.type_description ?? a.trid?.[0]?.type_desc ?? 'unknown', { detail: a.size !== undefined ? `${a.size} bytes` : undefined }));
      if (a.names?.length) out.push(finding('virustotal', 'Observed names', a.names.slice(0, 6).join(', '), { severity: 'info' }));
      const sv = Object.entries(a.sandbox_verdicts ?? {});
      for (const [engine, v] of sv.slice(0, 4)) out.push(finding('virustotal', `Sandbox ${engine}`, `${v.verdict}${v.malware_category ? ` · ${v.malware_category}` : ''}`, { kind: /malicious/i.test(v.verdict ?? '') ? 'flag' : 'fact', severity: /malicious/i.test(v.verdict ?? '') ? 'critical' : 'info' }));
      return out;
    }

    let path: string, link: string, label: string;
    if (entity.kind === 'url' && entity.url) {
      const id = await sha256Base64Url(entity.normalized);
      path = `urls/${id}`;
      link = `https://www.virustotal.com/gui/url/${id}`;
      label = 'URL detection';
    } else if (entity.kind === 'ip') {
      path = `ip_addresses/${entity.normalized}`;
      link = `https://www.virustotal.com/gui/ip-address/${entity.normalized}`;
      label = 'Address detection';
    } else {
      const target = entity.rootDomain ?? entity.normalized;
      path = `domains/${target}`;
      link = `https://www.virustotal.com/gui/domain/${target}`;
      label = 'Domain detection';
    }
    try {
      const r = await getJson<{ data?: { attributes?: Attrs } }>(`${H}/${path}`, opts);
      const a = r.data?.attributes;
      if (!a) return [finding('virustotal', label, 'no report', { severity: 'none', link })];
      out.push(...verdictFindings('virustotal', label, a, link));
      if (a.country) out.push(finding('virustotal', 'Country (VT)', a.country, { detail: a.asn ? `AS${a.asn} ${a.asn_owner ?? ''}` : undefined }));
      if (a.creation_date) out.push(finding('virustotal', 'First seen', fmtDate(new Date(a.creation_date * 1000).toISOString())));
      if (a.jarm && a.jarm !== '000000000000000000000000000000') out.push(finding('virustotal', 'JARM', a.jarm, { severity: 'none', detail: 'same fingerprint across assets usually means the same kit or CDN config' }));
      const dns = a.last_dns_records ?? [];
      for (const rec of dns.slice(0, 6)) out.push(finding('virustotal', `VT DNS ${rec.type}`, rec.value, { severity: 'none' }));
      return out;
    } catch (err) {
      const e = err as { status?: number };
      if (e.status === 404) return [finding('virustotal', label, 'not in VT', { severity: 'none', link, detail: 'VT has no cached report; a rescan would cost quota so the app does not submit automatically' })];
      if (e.status === 429) return [finding('virustotal', label, 'rate limited (429)', { severity: 'low', detail: 'free tier is 4/min — wait a minute and re-run' })];
      throw err;
    }
  },
};
