import { fmtDate, finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import type { Finding, Provider } from '../core/types';

interface Rep {
  email?: string;
  score?: number;
  source?: string;
  profile?: { source?: string };
  blocked?: boolean;
  suspicious?: boolean;
  freemail?: boolean;
  disposable?: boolean;
  greylisted?: boolean;
  blacklisted?: boolean;
  valid?: boolean;
  last_seen?: string;
  created_at?: string;
  activity?: { web?: number; spam?: number; breaches?: number };
  ip_info?: { country_name?: string; country_code?: string; asn?: string; asn_organization?: string; proxy?: boolean; web_client?: boolean; smtp_check?: boolean };
  details?: string;
}
interface Meta { doc_url?: string }

/**
 * EmailRep's anonymous endpoint is switched off server-side now, so this is
 * key-or-nothing; the provider reports that instead of pretending to degrade.
 */
export const emailrep: Provider = {
  id: 'emailrep',
  name: 'EmailRep',
  entities: ['email', 'ip'],
  requiresKey: true,
  blurb: 'Reputation for addresses and IPs: breaches, disposable domains, fraud signals.',
  signupUrl: 'https://emailrep.io/key',
  async run({ entity, key, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    const hdr: Record<string, string> = key ? { Key: key } : {};
    const r = await getJson<Rep & { meta?: Meta; message?: string }>(`https://emailrep.io/${encodeURIComponent(entity.normalized)}`, { signal, headers: hdr });
    if (r.message && !('score' in r)) {
      out.push(finding('emailrep', 'Query refused', r.message, { severity: 'low', detail: 'EmailRep: 429/401 usually means the key is missing or the free rate limit is spent' }));
      return out;
    }
    const score = r.score ?? 0;
    out.push(finding('emailrep', 'Score', `${score}/10`, { kind: 'flag', severity: score >= 8 ? 'high' : score >= 5 ? 'medium' : score >= 2 ? 'low' : 'none', detail: [r.profile?.source, r.last_seen ? `last seen ${fmtDate(r.last_seen)}` : undefined].filter(Boolean).join(' · ') }));
    const flags: { on: boolean; label: string; sev: Finding['severity'] }[] = [
      { on: !!r.blacklisted, label: 'Blacklisted', sev: 'critical' },
      { on: !!r.suspicious, label: 'Suspicious', sev: 'high' },
      { on: !!r.blocked, label: 'Blocked', sev: 'medium' },
      { on: !!r.disposable, label: 'Disposable address', sev: 'high' },
      { on: !!r.greylisted, label: 'Greylisted', sev: 'low' },
      { on: r.valid === false, label: 'Not deliverable (syntax/MX)', sev: 'medium' },
      { on: !!r.freemail, label: 'Freemail provider', sev: 'none' },
    ];
    for (const f of flags) {
      if (f.on) out.push(finding('emailrep', f.label, 'yes', { kind: 'flag', severity: f.sev }));
    }
    const act = r.activity ?? {};
    if (act.breaches || act.spam) out.push(finding('emailrep', 'Activity', `${act.breaches ?? 0} breaches · ${act.spam ?? 0} spam · ${act.web ?? 0} web`, { kind: 'flag', severity: (act.breaches ?? 0) > 0 ? 'medium' : 'low', detail: 'a breached address is a credential-stuffing candidate' }));
    if (r.ip_info) {
      const i = r.ip_info;
      out.push(finding('emailrep', 'IP context', [i.country_name, i.asn ? `AS${i.asn}` : undefined, i.asn_organization].filter(Boolean).join(' · '), { detail: i.proxy ? 'proxy' : undefined, kind: i.proxy ? 'flag' : 'fact', severity: i.proxy ? 'medium' : 'none' }));
    }
    if (r.details?.length) out.push(finding('emailrep', 'Details', r.details, { severity: 'none' }));
    return out;
  },
};
