import { fmtDate, ageDays, finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import type { Finding, Provider } from '../core/types';

/** RFC 9083 says an array, but Verisign and many TLDs send a bare string. */
interface RdapEvent { eventAction?: string[] | string; eventDate?: string }
interface RdapEntity { roles?: string[]; vcardArray?: [string, [string, string, string, string][]]; handle?: string }
interface RdapDomain {
  objectClassName?: string;
  handle?: string;
  ldhName?: string;
  status?: string[];
  events?: RdapEvent[];
  entities?: RdapEntity[];
  nameservers?: { ldhName?: string }[];
  secureDNS?: { delegationSigned?: boolean; maxSignatureLife?: number };
  port43?: string;
}

function vcardField(v: RdapEntity['vcardArray'], name: string): string | undefined {
  if (!v?.[1]) return undefined;
  const row = v[1].find((r) => r[0] === name);
  if (!row) return undefined;
  const val = row[3];
  return Array.isArray(val) ? val.filter(Boolean).join(' ') : String(val ?? '');
}

const STATUS_SEV: Record<string, { sev: Finding['severity']; note: string }> = {
  redemptionperiod: { sev: 'high', note: 'in redemption — registrable again within days' },
  pendingdelete: { sev: 'high', note: 'about to drop — takeover-relevant' },
  clienthold: { sev: 'medium', note: 'resolution disabled by registrar' },
  serverhold: { sev: 'medium', note: 'resolution disabled by registry' },
  inactive: { sev: 'medium', note: 'not delegated' },
  'clienttransferprohibited': { sev: 'none', note: 'transfer lock on (normal)' },
  'clientdeleteprohibited': { sev: 'none', note: 'delete lock on (normal)' },
  'clientupdateprohibited': { sev: 'none', note: 'update lock on (normal)' },
  'serverupdateprohibited': { sev: 'none', note: 'registry lock on (normal)' },
  'linked': { sev: 'none', note: 'associated with another object' },
  'validated': { sev: 'none', note: 'registrant contact validated' },
  'add grace period': { sev: 'low', note: 'registered in the last 5 days' },
  'renew grace period': { sev: 'low', note: 'expired but recoverable by owner' },
  'auto renew period': { sev: 'low', note: 'in auto-renew window' },
};

export const rdap: Provider = {
  id: 'rdap',
  name: 'RDAP / registration',
  entities: ['domain', 'ip', 'asn'],
  requiresKey: false,
  blurb: 'Registration data from the registry (rdap.org bootstrap, keyless, CORS-open). Replaces raw WHOIS.',
  docsUrl: 'https://rdap.org',
  async run({ entity, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    const path = entity.kind === 'ip' ? `ip/${entity.normalized}` : entity.kind === 'asn' ? `autnum/${entity.asn}` : `domain/${entity.normalized}`;
    let data: RdapDomain;
    try {
      data = await getJson<RdapDomain>(`https://rdap.org/${path}`, { signal, timeoutMs: 10_000 });
    } catch (err) {
      const e = err as { status?: number };
      if (e.status === 404 && entity.kind === 'domain') {
        return [
          finding('rdap', 'RDAP status', 'no object', {
            kind: 'flag',
            severity: 'high',
            detail: `${entity.normalized} has no RDAP record. For a apex domain this usually means it is unregistered or in redemption — check before you assume a dangling delegation.`,
          }),
        ];
      }
      throw err;
    }
    if (!data || typeof data !== 'object') return out;

    if (data.ldhName) out.push(finding('rdap', 'RDAP handle', data.handle ?? data.ldhName, { detail: data.port43 }));

    for (const ev of data.events ?? []) {
      const action = [ev.eventAction ?? ''].flat().join('/');
      if (!action) continue;
      const days = ageDays(ev.eventDate ?? '');
      const label =
        action.includes('registration') ? 'Registered'
        : action.includes('expiration') ? 'Expires'
        : action.includes('last changed') ? 'Last changed'
        : action.includes('transfer') ? 'Last transfer'
        : action.includes('deletion') ? 'Deleted'
        : action;
      let sev: Finding['severity'] = 'info';
      if (label === 'Expires' && days !== undefined) sev = days < 0 ? 'high' : days < 30 ? 'medium' : days < 90 ? 'low' : 'info';
      out.push(
        finding('rdap', label, fmtDate(ev.eventDate), {
          kind: label === 'Expires' ? 'flag' : 'fact',
          severity: sev,
          detail: days !== undefined ? (days < 0 ? `${-days} days ago` : days === 0 ? 'today' : label === 'Expires' ? `in ${days} days` : `${days} days ago`) : undefined,
        }),
      );
    }

    const registrar = (data.entities ?? []).find((e) => (e.roles ?? []).includes('registrar'));
    if (registrar) out.push(finding('rdap', 'Registrar', vcardField(registrar.vcardArray, 'fn') ?? registrar.handle ?? 'unknown'));
    const abuse = (data.entities ?? []).find((e) => (e.roles ?? []).includes('abuse'));
    if (abuse) {
      const email = vcardField(abuse.vcardArray, 'email');
      const tel = vcardField(abuse.vcardArray, 'tel');
      if (email || tel) out.push(finding('rdap', 'Abuse contact', `${email ?? ''} ${tel ?? ''}`.trim(), { detail: 'where to report, not where to phone' }));
    }

    for (const st of data.status ?? []) {
      // Registry text arrives both as 'clientTransferProhibited' and
      // 'client delete prohibited', so compare on a space-free lowercase key.
      const key = st.toLowerCase().replace(/\s+/g, '');
      const meta = STATUS_SEV[key];
      out.push(
        finding('rdap', 'Status', st, {
          kind: meta && meta.sev !== 'none' ? 'flag' : 'fact',
          severity: meta?.sev ?? 'info',
          detail: meta?.note,
        }),
      );
    }

    const ns = (data.nameservers ?? []).map((n) => n.ldhName).filter(Boolean) as string[];
    if (ns.length) out.push(finding('rdap', 'Nameservers', ns.join(', ')));
    if (data.secureDNS) {
      const signed = data.secureDNS.delegationSigned === true;
      out.push(
        finding('rdap', 'DNSSEC', signed ? 'signed' : 'unsigned', {
          kind: 'fact',
          severity: signed ? 'none' : 'info',
          detail: signed ? `max signature life ${data.secureDNS.maxSignatureLife ?? 'n/a'}` : 'no DNSSEC delegation — answers are spoofable on a broken resolver',
        }),
      );
    }
    return out;
  },
};
