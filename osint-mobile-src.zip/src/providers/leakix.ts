import { finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import type { Finding, Provider } from '../core/types';

interface LeakService { service?: string; port?: number; transport?: string; cve?: string[]; started_at?: string }
interface LeakHost { ip?: string; services?: LeakService[]; os?: string; updated_at?: string; country_code?: string; method?: string }

function hostFindings(h: LeakHost): Finding[] {
  const out: Finding[] = [];
  for (const s of h.services ?? []) {
    const cves = s.cve ?? [];
    out.push(
      finding('leakix', `Service ${s.port ?? '?'}`, [s.service, s.transport].filter(Boolean).join(' ') || 'unknown', {
        kind: cves.length ? 'flag' : 'fact',
        severity: cves.length ? (cves.length > 3 ? 'high' : 'medium') : 'info',
        detail: cves.length ? `${cves.length} known CVEs: ${cves.slice(0, 5).join(', ')}` : undefined,
      }),
    );
  }
  if (h.os) out.push(finding('leakix', 'Fingerprinted OS', h.os, { detail: h.method }));
  return out;
}

export const leakix: Provider = {
  id: 'leakix',
  name: 'LeakIX',
  entities: ['ip', 'domain', 'cidr'],
  requiresKey: true,
  blurb: 'Internet-wide banner index, free for non-commercial use. Good for finding the forgotten asset.',
  signupUrl: 'https://leakix.net/dashboard/api',
  async run({ entity, key, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    if (entity.kind === 'ip') {
      const r = await getJson<{ summary?: LeakHost[] }>(`https://leakix.net/api-search?q=ip%3A${encodeURIComponent(entity.normalized)}&key=${encodeURIComponent(key ?? '')}`, { signal });
      out.push(...(r.summary ?? []).flatMap(hostFindings));
      if (!out.length) out.push(finding('leakix', 'Indexed', 'nothing seen', { severity: 'none', detail: 'no open services in the LeakIX index' }));
      return out;
    }
    if (entity.kind === 'cidr') {
      // Deliberately only the sample the scanner produced, not the whole range.
      const sample = entity.cidr?.sample ?? [];
      out.push(finding('leakix', 'CIDR sweep', `${sample.length} of ${entity.cidr?.size ?? '?'} addresses`, { severity: 'info', detail: 'capped by Settings → CIDR sample size; LeakIX has no range endpoint' }));
      const results = await Promise.all(sample.slice(0, 8).map((ip) => getJson<{ summary?: LeakHost[] }>(`https://leakix.net/api-search?q=ip%3A${ip}&key=${encodeURIComponent(key ?? '')}`, { signal }).catch(() => undefined)));
      results.forEach((r, i) => {
        for (const h of r?.summary ?? []) out.push(...hostFindings(h).map((f) => ({ ...f, label: `${sample[i]} ${f.label}` })));
      });
      return out;
    }
    const root = entity.rootDomain ?? entity.normalized;
    const r = await getJson<{ subdomain?: string[]; services?: { subdomain?: string; port?: number; service?: string; cve?: string[]; ip?: string }[] }>(
      `https://leakix.net/api-subdomain/${encodeURIComponent(root)}?key=${encodeURIComponent(key ?? '')}`,
      { signal },
    );
    out.push(finding('leakix', 'Known subdomains', `${(r.subdomain ?? []).length}`, { detail: (r.subdomain ?? []).slice(0, 15).join(', ') || undefined, severity: 'info' }));
    for (const s of (r.services ?? []).slice(0, 20)) {
      const cves = s.cve ?? [];
      out.push(finding('leakix', `${s.subdomain ?? root}:${s.port ?? '?'}`, [s.service, s.ip].filter(Boolean).join(' → ') || 'unknown', {
        kind: cves.length ? 'flag' : 'fact',
        severity: cves.length ? 'high' : 'info',
        detail: cves.slice(0, 5).join(', ') || undefined,
      }));
    }
    return out;
  },
};
