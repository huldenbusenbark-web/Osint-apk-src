import { fmtDate, finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import type { Finding, Provider } from '../core/types';

interface Hit {
  siteurl?: string;
  webtitle?: string;
  ip?: string;
  ipv4?: string;
  country_code?: string;
  created_at?: string;
  brand_name?: string;
  status?: string;
  user?: string;
}

/**
 * Search corpus of phishing kits rather than a hash allowlist, so it catches a
 * fresh page that no blocklist has seen yet. Plan tier changes which /search/*
 * routes are open; 402/403 is surfaced as a hint rather than an error.
 */
export const stalkphish: Provider = {
  id: 'stalkphish',
  name: 'StalkPhish',
  entities: ['url', 'domain', 'ip', 'email'],
  requiresKey: true,
  blurb: 'Phishing-kit corpus search by URL string, IPv4 or brand.',
  signupUrl: 'https://stalkphish.io/documentation/fullapi/',
  async run({ entity, key, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    const headers = { Authorization: `Token ${key ?? ''}` };
    const term = entity.kind === 'url' ? (entity.url?.host ?? entity.normalized) : entity.kind === 'email' ? entity.normalized.split('@')[1] ?? entity.normalized : entity.normalized;
    const route = entity.kind === 'ip' ? `search/ipv4/${encodeURIComponent(term)}` : `search/url/${encodeURIComponent(term)}`;
    let rows: Hit[];
    try {
      const r = await getJson<Hit[] | { results?: Hit[]; detail?: string }>(`https://api.stalkphish.io/api/v1/${route}?last_days=120&page=1`, { signal, headers });
      if (!Array.isArray(r) && 'detail' in r && r.detail) {
        out.push(finding('stalkphish', 'Query refused', String(r.detail), { severity: 'low', detail: 'your StalkPhish plan may not include this search route — the free tier covers /me, /last and /search/url' }));
        return out;
      }
      rows = Array.isArray(r) ? r : r.results ?? [];
    } catch (err) {
      const e = err as { status?: number };
      if (e.status === 402 || e.status === 403) return [finding('stalkphish', 'Plan limit', `HTTP ${e.status}`, { severity: 'low', detail: 'this search needs a higher StalkPhish subscription' })];
      if (e.status === 404) return [finding('stalkphish', 'Result', 'no match', { severity: 'none' })];
      throw err;
    }

    if (!rows.length) {
      out.push(finding('stalkphish', 'Kit corpus', `no pages serving "${term}"`, { severity: 'none', detail: 'last 120 days' }));
      return out;
    }
    const brands = [...new Set(rows.map((h) => h.brand_name).filter((b): b is string => !!b))];
    out.push(finding('stalkphish', 'Corpus hits', String(rows.length), { kind: 'flag', severity: rows.length > 20 ? 'high' : 'medium', detail: brands.length ? `impersonating: ${brands.slice(0, 6).join(', ')}` : undefined }));
    for (const h of rows.slice(0, 10)) {
      out.push(
        finding('stalkphish', h.status === 'offline' ? 'Offline kit page' : 'Phishing page', (h.siteurl ?? '?').slice(0, 160), {
          kind: 'flag',
          severity: h.status === 'online' || !h.status ? 'high' : 'low',
          detail: [h.webtitle, h.ip ?? h.ipv4, h.country_code, h.created_at ? fmtDate(h.created_at) : undefined].filter(Boolean).join(' · '),
        }),
      );
    }
    return out;
  },
};
