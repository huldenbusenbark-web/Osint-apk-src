// The full exifr build embeds a Node-only `await import('fs')` branch that Metro
// lowers to a raw `import()` expression, which the Hermes byte compiler rejects
// ("Invalid expression encountered") — and that compiler runs inside every release
// APK build via `expo export:embed`. The lite parser resolves the same way under
// Metro and Node and returns GPS plus the IFD0 identifying tags, which is what this
// provider is for. The gap (XMP/IPTC, sub-IFD DateTimeOriginal) is reported as a
// finding below rather than left to look like "no metadata".
import * as exifrNamespace from 'exifr/dist/lite.umd.js';
import { finding } from '../core/normalize';
import { sha256Hex } from '../core/crypto';
import { getJson } from '../core/net/http';
import type { Attachment, Finding, Provider } from '../core/types';

const GPS_KEYS = ['latitude', 'longitude', 'altitude', 'imgDirection', 'gpsDate'] as const;

export interface ExifrLike {
  parse(input: ArrayBuffer | Uint8Array, options?: Record<string, unknown>): Promise<Record<string, unknown> | undefined>;
}

/**
 * exifr ships a UMD build, so depending on whether Metro or Node's ESM shim got
 * there first, the parser lands on the namespace, on `default`, or on
 * `default.default`. Pick whichever actually has `parse` instead of betting on
 * one interop shape — a silently-missing parser would read as "this photo has no
 * metadata", which is the one wrong answer this provider could give.
 */
export function resolveExifr(ns: unknown): ExifrLike | undefined {
  const chain = [ns, (ns as { default?: unknown })?.default, (ns as { default?: { default?: unknown } })?.default?.default];
  for (const candidate of chain) {
    if (candidate && typeof (candidate as ExifrLike).parse === 'function') return candidate as ExifrLike;
  }
  return undefined;
}

/**
 * Metadata + digests for anything the user supplies locally (photo from the
 * gallery, a shared file) or by URL. This is the "am I about to leak my own
 * location" check as much as it is a victim-asset check: EXIF GPS, author
 * strings and software tags routinely identify the person who took the shot.
 */
export const metadata: Provider = {
  id: 'exif',
  name: 'File metadata & digests',
  entities: ['url', 'domain', 'ip', 'email', 'phone', 'hash', 'cidr', 'asn'],
  requiresKey: false,
  blurb: 'EXIF/XMP/IPTC reader plus md5/sha256 for picked images. Runs entirely on-device.',
  async run({ entity, attachments, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    const items: Attachment[] = attachments ?? [];
    const exifrLite = resolveExifr(exifrNamespace);

    if (!items.length && entity.kind === 'url' && /\.(jpe?g|tiff?|png|webp|heic|dng)$/i.test(entity.url?.path ?? '')) {
      try {
        const res = await fetch(entity.normalized, { signal });
        const bytes = await res.arrayBuffer();
        items.push({ kind: 'image', uri: entity.normalized, name: entity.url?.path.split('/').pop(), bytes });
      } catch {
        out.push(finding('exif', 'Remote fetch', 'blocked or offline', { severity: 'low', detail: 'on the web build this is CORS; on device it is a network or TLS problem' }));
      }
    }
    if (!exifrLite) {
      return [
        finding('exif', 'Parser unavailable', 'exifr did not load', {
          kind: 'flag',
          severity: 'high',
          detail: 'The bundled EXIF parser could not be resolved, so nothing here has been checked for GPS or authorship tags. Do not read "no metadata" below as a clean result.',
        }),
      ];
    }
    if (!items.length) {
      return [finding('exif', 'Metadata', 'nothing to read', { severity: 'none', detail: 'attach an image with the picker below the search box, or paste a URL ending in .jpg/.png/.tiff' })];
    }

    for (const att of items.slice(0, 4)) {
      const tag = att.name ?? att.uri.split('/').pop() ?? 'attachment';
      const bytes = new Uint8Array(att.bytes);
      const hex = await sha256Hex(bytes);
      out.push(finding('exif', 'SHA-256', hex, { detail: tag }));
      try {
        const { md5, sha1 } = await digests(bytes);
        out.push(finding('exif', 'MD5', md5, { severity: 'none', detail: `${tag} — the hash blocklists and VT file lookups use` }));
        if (sha1) out.push(finding('exif', 'SHA-1', sha1, { severity: 'none', detail: tag }));
      } catch {
        /* md5/sha1 come from the same digest helper; absence is not interesting */
      }

      // File size + magic bytes is enough to catch "renamed .exe", which is a
      // daily occurrence in phishing kits.
      const magic = [...bytes.slice(0, 8)].map((b) => b.toString(16).padStart(2, '0')).join('');
      out.push(finding('exif', 'Type', sniff(magic, att.name ?? ''), { detail: `${bytes.length.toLocaleString()} bytes · magic ${magic}` }));

      let meta: Record<string, unknown> | undefined;
      try {
        meta = (await exifrLite.parse(att.bytes)) as Record<string, unknown> | undefined;
      } catch {
        meta = undefined;
      }
      if (!meta || !Object.keys(meta).length) {
        out.push(finding('exif', 'EXIF', 'none present', { severity: 'none', detail: 'no EXIF/XMP/IPTC — either stripped, a screenshot, or a PNG/WebP without metadata' }));
        continue;
      }
      const lat = meta.latitude as number | undefined;
      const lon = meta.longitude as number | undefined;
      if (typeof lat === 'number' && typeof lon === 'number') {
        out.push(
          finding('exif', 'GPS', `${lat.toFixed(6)}, ${lon.toFixed(6)}`, {
            kind: 'flag',
            severity: 'critical',
            detail: `https://www.openstreetmap.org/?mlat=${lat}&mlon=${lon}#map=17/${lat}/${lon} — this is where the photo was taken. If this is you or your source, strip it before sharing.`,
          }),
        );
      }
      const interesting: [string, string][] = [
        ['Make', 'camera make'], ['Model', 'camera model'], ['Software', 'creating application'],
        ['Artist', 'author (often a person\'s name)'], ['Creator', 'creator (XMP)'], ['Copyright', 'rights string'],
        ['Description', 'image description'], ['ImageDescription', 'image description'], ['LensModel', 'lens'],
        ['GPSDateStamp', 'fix timestamp'], ['DateTimeOriginal', 'taken at'], ['CreateDate', 'created'],
        ['XMP:Author', 'XMP author'], ['Author', 'author'], ['ProfileName', 'ICC profile'], ['pixelsXDimension', 'width'],
      ];
      for (const [k, why] of interesting) {
        const v = meta[k];
        if (v === undefined || v === null || v === '') continue;
        const str = String(v);
        const identifying = /Artist|Author|Creator|Copyright|Description|ProfileName/i.test(k);
        out.push(finding('exif', `Tag: ${k}`, str.slice(0, 180), { kind: identifying ? 'flag' : 'fact', severity: identifying ? 'high' : 'none', detail: why }));
      }
      const gpsExtra = GPS_KEYS.filter((k) => meta[k] !== undefined && k !== 'latitude' && k !== 'longitude');
      if (gpsExtra.length) out.push(finding('exif', 'GPS extras', gpsExtra.map((k) => `${k}=${String(meta[k])}`).join(' · '), { severity: 'medium', kind: 'flag' }));
      const allKeys = Object.keys(meta);
      out.push(finding('exif', 'Tags read', `${allKeys.length}`, { severity: 'none', detail: allKeys.slice(0, 30).join(', ') }));
      out.push(
        finding('exif', 'Parser coverage', 'EXIF + GPS only', {
          severity: 'low',
          detail: 'XMP and IPTC blocks are not read by the bundled parser, so "no XMP author" below is not evidence that none exists. Re-verify with exiftool before you assert absence.',
        }),
      );
      void signal;
    }
    return out;
  },
};

async function digests(bytes: Uint8Array): Promise<{ md5: string; sha1?: string }> {
  const subtle = (globalThis as { crypto?: Crypto }).crypto?.subtle;
  const md5 = await md5Hex(bytes);
  let sha1: string | undefined;
  if (subtle) {
    const buf = new Uint8Array(await subtle.digest('SHA-1', bytes as unknown as ArrayBuffer));
    sha1 = [...buf].map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  return { md5, sha1 };
}

function sniff(magic: string, name = ''): string {
  if (magic.startsWith('ffd8')) return 'JPEG';
  if (magic.startsWith('89504e47')) return 'PNG';
  if (magic.startsWith('49492a00') || magic.startsWith('4d4d002a')) return 'TIFF/EXIF';
  if (magic.startsWith('52494646')) return 'RIFF container (webp/avi/wav)';
  if (magic.startsWith('4d5a')) return 'Windows PE executable';
  if (magic.startsWith('25504446')) return 'PDF';
  if (magic.startsWith('504b0304')) return 'ZIP/OOXML container';
  return name ? `unrecognised (name says ${name.split('.').pop()})` : 'unrecognised';
}

/* Compact MD5 so the app does not need a native crypto module for blocklist hashes. */
function md5Hex(input: Uint8Array): string {
  const S = [7, 12, 17, 22, 5, 9, 14, 20, 4, 11, 16, 23, 6, 10, 15, 21];
  const T = Array.from({ length: 64 }, (_, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 2 ** 32));
  const len = input.length;
  const total = (((len + 8) >> 6) + 1) * 64;
  const m = new Uint8Array(total);
  m.set(input);
  m[len] = 0x80;
  new DataView(m.buffer).setUint32(total - 8, len * 8, true);
  new DataView(m.buffer).setUint32(total - 4, Math.floor((len * 8) / 2 ** 32), true);
  let a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;
  for (let off = 0; off < total; off += 64) {
    const M: number[] = [];
    for (let i = 0; i < 16; i++) M[i] = new DataView(m.buffer).getUint32(off + i * 4, true);
    let [A, B, C, D] = [a0, b0, c0, d0];
    for (let i = 0; i < 64; i++) {
      let F = 0, g = 0;
      if (i < 16) { F = (B & C) | (~B & D); g = i; }
      else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; }
      else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; }
      else { F = C ^ (B | ~D); g = (7 * i) % 16; }
      F = (F + A + T[i]! + M[g]!) | 0;
      A = D; D = C; C = B;
      B = (B + ((F << S[i % 16]!) | (F >>> (32 - S[i % 16]!)))) | 0;
    }
    a0 = (a0 + A) | 0; b0 = (b0 + B) | 0; c0 = (c0 + C) | 0; d0 = (d0 + D) | 0;
  }
  return [a0, b0, c0, d0].map((x) => [...Array(4)].map((_, i) => ((x >>> (i * 8)) & 255).toString(16).padStart(2, '0')).reverse().join('')).join('');
}
