import { ageDays, fmtDate, finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import type { Provider } from '../core/types';

interface Whois {
  status_code?: number | string;
  domain?: string;
  registrar?: string;
  whois_server?: string;
  created_date?: string;
  updated_date?: string;
  expire_date?: string;
  nameservers?: string[] | string;
  ics?: string[];
  status?: string[] | string;
  registry_domain_id?: string;
}

/** Fallback when RDAP has nothing for the TLD, and a cheap availability check. */
export const ip2whois: Provider = {
  id: 'ip2whois',
  name: 'IP2WHOIS',
  entities: ['domain'],
  requiresKey: true,
  blurb: 'Secondary WHOIS source — fills gaps where the TLD has no RDAP and confirms registration state.',
  signupUrl: 'https://www.ip2location.com/webservices/ip2whois',
  async run({ entity, key, signal }): Promise<import('../core/types').Finding[]> {
    const out: import('../core/types').Finding[] = [];
    const r = await getJson<Whois>(`https://api.ip2whois.com/v2?key=${encodeURIComponent(key ?? '')}&domain=${encodeURIComponent(entity.normalized)}`, { signal });
    const status = String(r.status_code ?? '');
    if (status === '404' || status === 'no-results') {
      out.push(finding('ip2whois', 'Registration', 'no WHOIS record', { kind: 'flag', severity: 'high', detail: 'corroborates RDAP: verify via your registrar before assuming anything' }));
      return out;
    }
    if (status && status !== '200') out.push(finding('ip2whois', 'Query', `status ${status}`, { severity: 'low', detail: r.domain ? undefined : 'check the key and the plan’s TLD coverage' }));
    if (r.registrar) out.push(finding('ip2whois', 'Registrar', r.registrar, { detail: r.whois_server }));
    const asArr = (v: string[] | string | undefined) => (Array.isArray(v) ? v : v ? [v] : []);
    if (r.created_date) out.push(finding('ip2whois', 'Created', fmtDate(r.created_date), { detail: (() => { const d = ageDays(r.created_date); return d === undefined ? undefined : `${d} days old`; })() }));
    if (r.expire_date) {
      const left = -1 * (ageDays(r.expire_date) ?? 0);
      out.push(finding('ip2whois', 'Expires', fmtDate(r.expire_date), { kind: 'flag', severity: left < 0 ? 'high' : left < 30 ? 'medium' : 'none', detail: left < 0 ? `expired ${-left} days ago` : `${left} days remaining` }));
    }
    const ns = asArr(r.nameservers);
    if (ns.length) out.push(finding('ip2whois', 'Nameservers', ns.join(', ')));
    for (const st of asArr(r.status)) if (!/^client/i.test(st)) out.push(finding('ip2whois', 'Status', st, { kind: /pending|hold|redemption/i.test(st) ? 'flag' : 'fact', severity: /redemption|pendingdelete/i.test(st) ? 'high' : /hold/i.test(st) ? 'medium' : 'info' }));
    return out;
  },
};
