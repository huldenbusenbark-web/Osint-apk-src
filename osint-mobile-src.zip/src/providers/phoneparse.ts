import { PhoneNumberUtil, PhoneNumberType } from 'google-libphonenumber';
import { finding } from '../core/normalize';
import type { Finding, Provider } from '../core/types';

/**
 * Phone handling is local parsing only — country, validity, line type.
 * "Which person owns this number" services are not wired in here: they are the
 * part of OSINT that turns into harassing someone, and a fraud-screening tool
 * does not need them. Add a vendor endpoint yourself via Custom source if your
 * employer's policy covers it.
 */
const util = PhoneNumberUtil.getInstance();
const TYPES: Record<number, string> = PhoneNumberType;

export const phoneparse: Provider = {
  id: 'phoneparse',
  name: 'Number structure (offline)',
  entities: ['phone'],
  requiresKey: false,
  blurb: 'libphonenumber parsing on-device: E.164, region, validity, line type. No network call.',
  async run({ entity }): Promise<Finding[]> {
    const out: Finding[] = [];
    const raw = entity.normalized;
    let parsed: ReturnType<typeof util.parse> | undefined;
    try {
      parsed = util.parse(raw.startsWith('+') ? raw : `+${raw}`, 'US');
    } catch {
      return [finding('phoneparse', 'Parse', 'not a valid international number', { kind: 'flag', severity: 'low', detail: 'libphonenumber rejected it — a mistyped or fabricated number is itself a fraud signal' })];
    }
    const e164 = util.format(parsed, 0);
    const region = util.getRegionCodeForNumber(parsed) ?? 'unknown';
    const valid = util.isValidNumber(parsed);
    const typeKey = Object.keys(TYPES).find((k) => (util.getNumberType(parsed!) as unknown as number) === Number(k));
    const typeName = typeKey ? TYPES[Number(typeKey)] : 'unknown';
    out.push(finding('phoneparse', 'E.164', e164, { detail: `region ${region}` }));
    out.push(finding('phoneparse', 'Valid', valid ? 'yes' : 'no (possible only)', { kind: 'flag', severity: valid ? 'none' : 'low', detail: valid ? undefined : 'fits the numbering plan but is not assigned' }));
    out.push(finding('phoneparse', 'Line type', typeName, { kind: /PREMIUM_RATE|VOIP|PERSONAL_NUMBER|UAN|WAP/i.test(typeName) ? 'flag' : 'fact', severity: /PREMIUM_RATE/i.test(typeName) ? 'high' : /VOIP|PERSONAL_NUMBER|UAN/i.test(typeName) ? 'medium' : 'none', detail: /VOIP/i.test(typeName) ? 'VoIP blocks are cheap and rotate; weak as an identity anchor' : undefined }));
    out.push(finding('phoneparse', 'National', util.format(parsed, 2), { severity: 'none' }));
    return out;
  },
};
