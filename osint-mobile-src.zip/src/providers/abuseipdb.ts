import { finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import type { Finding, Provider } from '../core/types';

interface Check {
  data?: {
    ipAddress: string; isWhitelisted: boolean; isPublicNetwork?: boolean;
    abuseContact?: string; confidenceScore: number; region?: string; country?: string;
    countryCode?: string; isp?: string; domain?: string; usageType?: string;
    blacklistedCountry?: boolean; examples?: { category?: string; reportedAt?: string }[];
    hostnames?: string[]; numReports?: number;
  };
  meta?: { quotaRemaining?: number };
  errors?: { code: number; message: string }[];
}
interface DomainReports { data?: { reportedAt?: string; categories?: string[]; comments?: { user?: { name?: string } }[] }[] }

export const abuseipdb: Provider = {
  id: 'abuseipdb',
  name: 'AbuseIPDB',
  entities: ['ip', 'domain'],
  requiresKey: true,
  blurb: 'Crowd-sourced abuse reports. IP → confidence + categories; domain → reports filed against it.',
  signupUrl: 'https://www.abuseipdb.com/account/api',
  extraConfig: [{ name: 'abuseipdbVersion', label: 'API Version header (optional)', placeholder: '20240910' }],
  async run({ entity, key, secret, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    const headers = { Key: key ?? '', Accept: 'application/json', ...(secret('abuseipdbVersion') ? { Version: secret('abuseipdbVersion')! } : {}) };

    if (entity.kind === 'ip') {
      const r = await getJson<Check>(`https://api.abuseipdb.com/api/v2/check?ipAddress=${encodeURIComponent(entity.normalized)}&maxAgeInDays=90&verbose=1`, { signal, headers });
      if (r.errors?.length) throw new Error(r.errors.map((e) => `${e.code}: ${e.message}`).join('; '));
      const d = r.data;
      if (!d) return out;
      const sev = d.confidenceScore >= 75 ? 'critical' : d.confidenceScore >= 50 ? 'high' : d.confidenceScore >= 25 ? 'medium' : d.isWhitelisted ? 'none' : 'low';
      out.push(finding('abuseipdb', 'Confidence', `${d.confidenceScore}%`, { kind: d.confidenceScore >= 25 ? 'flag' : 'fact', severity: sev, detail: `${d.numReports ?? 0} reports in 90 days · ${d.usageType ?? 'unknown usage'}` }));
      if (d.isWhitelisted) out.push(finding('abuseipdb', 'Whitelisted', 'yes', { severity: 'none', detail: 'AbuseIPDB considers this a false-positive-prone address' }));
      if (d.examples?.length) out.push(finding('abuseipdb', 'Reported for', d.examples.map((e) => e.category).filter((c): c is string => !!c).slice(0, 6).join(', ') || 'unspecified', { kind: 'flag', severity: sev }));
      if (d.isp || d.domain) out.push(finding('abuseipdb', 'ISP', [d.isp, d.domain].filter(Boolean).join(' · ')));
      if (d.hostnames?.length) out.push(finding('abuseipdb', 'Reverse hostnames', d.hostnames.slice(0, 8).join(', ')));
      if (d.abuseContact) out.push(finding('abuseipdb', 'Abuse contact', d.abuseContact, { detail: 'who to email about this address' }));
      if (r.meta?.quotaRemaining !== undefined) out.push(finding('abuseipdb', 'Quota left', String(r.meta.quotaRemaining), { severity: 'none' }));
      return out;
    }

    const d = entity.rootDomain ?? entity.normalized;
    const dr = await getJson<DomainReports>(`https://api.abuseipdb.com/api/v2/domains/${encodeURIComponent(d)}/reports?maxAgeInDays=90&direction=incoming`, { signal, headers });
    const rows = dr.data ?? [];
    out.push(finding('abuseipdb', 'Domain reports', String(rows.length), { kind: rows.length ? 'flag' : 'fact', severity: rows.length >= 10 ? 'high' : rows.length ? 'medium' : 'none', detail: rows.length ? `on ${d}, last 90 days` : `nothing reported against ${d}` }));
    for (const row of rows.slice(0, 8)) {
      out.push(finding('abuseipdb', `Report ${row.reportedAt?.slice(0, 10) ?? ''}`, (row.categories ?? []).join(', ') || row.comments?.map((c) => c.user?.name).filter(Boolean).join(', ') || '—', { severity: 'low' }));
    }
    return out;
  },
};
