import { fmtDate, finding } from '../core/normalize';
import { postForm } from '../core/net/http';
import type { Finding, Provider } from '../core/types';

interface UrlRow {
  query_status?: string;
  url?: string;
  url_status?: string;
  online_status?: string;
  url_added_datetime?: string;
  urlhaus_link?: string;
  urlhaus_reference?: string;
  threats?: string;
  bfb?: string;
  botnet?: string;
  host?: string;
  port?: string;
  StatusCode?: string;
  "Content-Sha256"?: string;
  Downloads?: { "Content-Sha256"?: string; "Delivery-Method"?: string; "File-Name"?: string }[];
  "Tags"?: string[];
}

/**
 * abuse.ch moved URLhaus behind a free account key in 2025:
 * header `Auth: api=<user-or-key>`. Unauthenticated calls now return 401,
 * which is why this provider reports `nokey` instead of failing opaquely.
 */
export const urlhaus: Provider = {
  id: 'urlhaus',
  name: 'URLhaus (abuse.ch)',
  entities: ['url', 'domain', 'ip'],
  requiresKey: true,
  blurb: 'Malware-distribution URLs by host and by URL. Key is free — register at bazaar.abuse.ch.',
  signupUrl: 'https://urlhaus.abuse.ch/api/',
  async run({ entity, key, secret, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    const headers = { Auth: secret('urlhausUser') ? `api=${secret('urlhausUser')}` : `api=${key ?? ''}` };
    const form: Record<string, string> = entity.kind === 'url' ? { url: entity.normalized } : { host: entity.kind === 'ip' ? entity.normalized : entity.rootDomain ?? entity.normalized };
    const path = entity.kind === 'url' ? 'url' : 'host';
    const r = await postForm<{ query_status?: string; data?: UrlRow[] } | UrlRow>(`https://urlhaus-api.abuse.ch/v1/${path}/`, form, { signal, headers });

    const rows: UrlRow[] = Array.isArray((r as { data?: UrlRow[] }).data) ? ((r as { data?: UrlRow[] }).data as UrlRow[]) : (r as UrlRow).query_status === 'ok' ? [r as UrlRow] : [];
    if ((r as UrlRow).query_status === 'no_results' || !rows.length) {
      out.push(finding('urlhaus', 'URLhaus listing', 'not listed', { severity: 'none', detail: 'absence of a URLhaus entry is a weak negative signal, not clearance' }));
      return out;
    }
    for (const row of rows.slice(0, 12)) {
      const online = row.online_status === 'online';
      out.push(
        finding('urlhaus', online ? 'Live malware URL' : 'Historical URL', row.url ?? row.host ?? '?', {
          kind: 'flag',
          severity: online ? 'critical' : 'medium',
          detail: [row.url_status, row.threats ? `threats: ${row.threats}` : undefined, row.botnet ? `botnet: ${row.botnet}` : undefined, row.StatusCode ? `HTTP ${row.StatusCode}` : undefined, row.url_added_datetime ? `added ${fmtDate(row.url_added_datetime)}` : undefined]
            .filter(Boolean)
            .join(' · '),
          link: row.urlhaus_reference || row.urlhaus_link,
          tags: row.Tags,
        }),
      );
      for (const d of (row.Downloads ?? []).slice(0, 4)) {
        out.push(finding('urlhaus', 'Payload', `${d['File-Name'] ?? 'unknown'} → ${d['Content-Sha256']?.slice(0, 16)}…`, { kind: 'flag', severity: 'high', detail: d['Delivery-Method'] }));
      }
      if (row.bfb && row.bfb !== 'no') out.push(finding('urlhaus', 'URLhaus Blacklist Feed', row.bfb, { kind: 'flag', severity: 'high', detail: 'listed in the blocklist feed you can push to a proxy' }));
    }
    return out;
  },
};
