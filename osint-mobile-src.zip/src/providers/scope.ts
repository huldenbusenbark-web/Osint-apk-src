import { parseScope, inScope } from '../core/entity/detect';
import { loadSettings } from '../core/settings';
import { finding } from '../core/normalize';
import { getJson } from '../core/net/http';
import type { Finding, Provider } from '../core/types';

/**
 * crt.sh is the conventional source but it 502s under load constantly, and a
 * silently empty subdomain list is the worst possible failure mode for a recon
 * tool: it reads as "no certificates exist". So fall back, and say which one answered.
 */
async function certificateNames(root: string, signal: AbortSignal): Promise<{ names: string[]; source: string; error?: string }> {
  const clean = (rows: { common_name?: string; dns_names?: string[] }[]): string[] => [
    ...new Set(
      rows
        .flatMap((r) => (r.dns_names?.length ? r.dns_names : [r.common_name ?? '']))
        .flatMap((c) => String(c).split(/\n|,\s*/))
        .map((x) => x.trim().toLowerCase().replace(/^\*\./, ''))
        .filter((x) => x && !x.startsWith('%')),
    ),
  ];
  try {
    const rows = await getJson<{ common_name?: string }[]>(`https://crt.sh/?q=%25.${encodeURIComponent(root)}&output=json`, { signal, timeoutMs: 12_000 });
    const names = clean(Array.isArray(rows) ? rows : []);
    if (names.length) return { names, source: 'crt.sh' };
  } catch (err) {
    const message = (err as Error).message;
    try {
      const rows = await getJson<{ dns_names?: string[] }[]>(
        `https://api.certspotter.com/v1/issuances?domain=${encodeURIComponent(root)}&include_subdomains=true&expand=dns_names`,
        { signal, timeoutMs: 12_000 },
      );
      const names = clean(Array.isArray(rows) ? rows : []);
      return { names, source: 'CertSpotter (crt.sh failed)', error: `crt.sh: ${message}` };
    } catch {
      return { names: [], source: 'crt.sh + CertSpotter both unreachable', error: message };
    }
  }
  return { names: [], source: 'crt.sh' };
}

/**
 * Not a data source — the guard rail. In a bug-bounty programme the expensive
 * mistake is not a missed finding, it is touching an out-of-scope asset that
 * happens to share a name with an in-scope one (a third-party SaaS tenant, an
 * acquired brand, a staging box on a sibling domain).
 */
export const scope: Provider = {
  id: 'scope',
  name: 'Scope check',
  entities: ['domain', 'ip', 'cidr', 'url', 'email', 'asn'],
  requiresKey: false,
  blurb: 'Matches the target against your saved scope and queries crt.sh / CT logs for extra names.',
  async run({ entity, config, signal }): Promise<Finding[]> {
    const out: Finding[] = [];
    const s = parseScope(config.demo ? '' : await loadSettings().then((x) => x.scope));
    const within = inScope(entity, s);
    const configured = s.domains.length + s.cidrs.length + s.ips.length + s.wildcards.length > 0;
    if (!configured) {
      out.push(finding('scope', 'Scope', 'not configured', { severity: 'low', detail: 'Add your programme assets in Settings → Scope so out-of-scope lookups get flagged (and can be blocked).' }));
    } else {
      out.push(
        finding('scope', within ? 'In scope' : 'OUT OF SCOPE', entity.normalized, {
          kind: 'flag',
          severity: within ? 'none' : 'critical',
          detail: within ? 'matches an entry in your saved scope' : 'no entry in your saved scope matches this target. Passive lookups still ran; anything active against it needs written authorisation.',
        }),
      );
    }
    if (entity.kind === 'cidr' && entity.cidr) {
      const size = Number(entity.cidr.size);
      out.push(finding('scope', 'Range size', `${size.toLocaleString()} addresses`, { kind: size > 1024 ? 'flag' : 'fact', severity: size > 4096 ? 'high' : size > 1024 ? 'medium' : 'low', detail: `sampling ${entity.cidr.sample.length}${entity.cidr.truncated ? ' (truncated — raise the cap in Settings deliberately)' : ''}. Never scan a range you do not own or have permission to test.` }));
    }
    if (entity.kind === 'domain') {
      const root = entity.rootDomain ?? entity.normalized;
      const ct = await certificateNames(root, signal);
      out.push(
        finding('scope', 'Certificate names (CT)', String(ct.names.length), {
          severity: ct.names.length ? 'info' : 'low',
          detail: ct.error ? `${ct.source} — ${ct.error}` : `${ct.source}: ${ct.names.slice(0, 25).join(', ') || 'no certificates found'}`,
        }),
      );
      const thirdParty = ct.names.filter((n) => !n.endsWith(root));
      if (thirdParty.length) {
        out.push(finding('scope', 'Cross-domain certs', thirdParty.slice(0, 8).join(', '), { kind: 'flag', severity: 'medium', detail: 'certificates covering names outside this apex: shared hosting, an acquired brand, or someone else’s tenant. All of them are usually out of scope.' }));
      }
    }
    return out;
  },
};
