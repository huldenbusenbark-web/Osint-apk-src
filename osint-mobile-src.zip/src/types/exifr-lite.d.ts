/** The UMD build ships no types; this is the surface the provider actually uses. */
declare module 'exifr/dist/lite.umd.js' {
  export interface ExifrLike {
    parse(input: ArrayBuffer | Uint8Array, options?: Record<string, unknown>): Promise<Record<string, unknown> | undefined>;
  }
  const mod: { default?: { default?: ExifrLike } & ExifrLike } & ExifrLike;
  export default mod;
}
