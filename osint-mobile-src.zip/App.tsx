import React, { useEffect, useState } from 'react';
import { Platform, Pressable, StatusBar, StyleSheet, Text, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import * as Linking from 'expo-linking';
import { installStores } from './src/platform/stores';
import { pickImages } from './src/platform/pick';
import { useApp, type Tab } from './src/ui/store';
import { ScanScreen } from './src/ui/screens/ScanScreen';
import { HistoryScreen } from './src/ui/screens/HistoryScreen';
import { SettingsScreen } from './src/ui/screens/SettingsScreen';
import { c } from './src/ui/theme';

installStores();

const TABS: { id: Tab; label: string }[] = [
  { id: 'scan', label: 'Scan' },
  { id: 'history', label: 'History' },
  { id: 'settings', label: 'Sources' },
];

export default function App() {
  const [ok, setOk] = useState(false);
  const { tab, setInput, run, setNotice, attachments, addAttachments } = useApp();

  useEffect(() => {
    useApp.getState().boot().then(() => setOk(true));
  }, []);

  // Share-sheet + deep link entry: "Share → OSINT Mobile" from a browser,
  // Slack or an SMS lands the text straight in the input.
  useEffect(() => {
    if (!ok) return;
    const consume = (url: string | null) => {
      if (!url) return;
      const text = decodeURIComponent(url.includes('text=') ? new URL(url).searchParams.get('text') ?? '' : url.replace(/^[a-z]+:\/\//i, ''));
      if (!text) return;
      setInput(text.trim());
      setNotice(`Captured from ${url.startsWith('https://osint') ? 'a sent link' : 'the share sheet'}.`);
      void run();
    };
    void Linking.getInitialURL().then(consume);
    const sub = Linking.addEventListener('url', (e) => consume(e.url));
    return () => sub.remove();
  }, [ok, setInput, run, setNotice]);

  const attach = async () => {
    try {
      const picked = await pickImages();
      if (picked.length) addAttachments(picked);
    } catch (err) {
      setNotice((err as Error).message);
    }
  };

  if (!ok) {
    return (
      <SafeAreaView style={styles.root}>
        <Text style={{ color: c.dim, padding: 20 }}>Loading sources…</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.root} edges={['top', 'bottom']}>
        <StatusBar barStyle="light-content" backgroundColor={c.bg} />
        <View style={styles.header}>
          <Text style={styles.title}>OSINT console</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            {attachments.length ? <Text style={styles.sub}>+{attachments.length} file{attachments.length === 1 ? '' : 's'}</Text> : null}
            <Text style={styles.sub}>passive lookups only</Text>
          </View>
        </View>

        <View style={{ flex: 1 }}>
          {tab === 'scan' ? <ScanScreen pickImage={() => void attach()} /> : null}
          {tab === 'history' ? <HistoryScreen /> : null}
          {tab === 'settings' ? <SettingsScreen /> : null}
        </View>

        <View style={styles.tabs}>
          {TABS.map((t) => (
            <Pressable key={t.id} onPress={() => useApp.setState({ tab: t.id })} style={[styles.tab, tab === t.id && styles.tabOn]}>
              <Text style={[styles.tabText, tab === t.id && { color: c.accent }]}>{t.label}</Text>
            </Pressable>
          ))}
        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: c.bg },
  header: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', paddingHorizontal: 14, paddingTop: Platform.OS === 'android' ? 6 : 2, paddingBottom: 8 },
  title: { color: c.text, fontSize: 17, fontWeight: '800', letterSpacing: 0.2 },
  sub: { color: c.faint, fontSize: 11 },
  tabs: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: c.line, backgroundColor: c.panel },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 11 },
  tabOn: { backgroundColor: c.panel2 },
  tabText: { color: c.dim, fontSize: 12.5, fontWeight: '600' },
});
