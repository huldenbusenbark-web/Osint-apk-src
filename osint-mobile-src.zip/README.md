# OSINT Mobile

React Native (Expo SDK 57 / RN 0.86 / TypeScript, strict) app for **passive** OSINT
lookups: type a domain, IP, CIDR, URL, email, phone number or file hash and it fans out
to every source that can answer for that type, normalises the answers into one finding
shape, and gives you a severity verdict plus a Markdown/CSV export for your notes.

Built for the bug-bounty / threat-intel workflow: *what is registered, what is exposed,
what is listed, and is this even mine to look at.*

```
npm install
npm run web          # browser preview, zero keys needed in demo mode
npm run android      # or: npx expo start, then open the QR in Expo Go
npm run check        # typecheck + 9 unit + 6 render tests
OSINT_LIVE=1 npm run test:live   # hits the real APIs (see "What is verified")
```

## What it does

| Entity | Sources |
|---|---|
| `domain` | scope + CT logs, RDAP, DNS/DMARC/SPF/wildcard, VirusTotal, OTX, AbuseIPDB, URLhaus, StalkPhish, PhishReport, Shodan, LeakIX, IP2WHOIS, DNSDumpster, FraudLabs, custom |
| `ip` | scope, RDAP, reverse DNS, ipwho.is/ipapi.is geo+ASN, VT, OTX, AbuseIPDB, EmailRep, Shodan, LeakIX, custom |
| `cidr` | scope (size warning + capped sampling), LeakIX over the sample, custom |
| `url` | VT (by `base64url(sha256(url))`), OTX, URLhaus, StalkPhish, PhishReport, EmailRep-for-host, custom |
| `email` | EmailRep, FraudLabs email-intelligence, StalkPhish, DMARC/SPF of the sending domain, custom |
| `phone` | on-device libphonenumber parse (E.164, region, validity, line type), FraudLabs phone-intelligence |
| `hash` | VirusTotal file report (verdict, type, names, sandbox verdicts), local md5/sha1/sha256 |
| image/file | EXIF/XMP/IPTC via `exifr` — GPS coordinates surface as **critical** |

There is no "active" scanning in this app. Nothing connects to the target asset: every
answer comes from a third-party index or public resolver.

## Architecture

```
src/core/          platform-agnostic, zero react-native imports
  entity/detect.ts   free text -> typed EntityDescriptor; scope parsing/matching
  entity/ipv4.ts     CIDR maths (bounded sampling, never full expansion)
  net/http.ts        per-host spacing queue, retry/backoff on 429+5xx, timeout,
                     key-redacted debug log, optional relay for the web build
  registry.ts        the provider list; scanner filters by EntityKind
  scanner.ts         concurrency, per-provider timeout, cancel, verdict maths
  normalize.ts       the one Finding shape + severity ranking
  store.ts           persistence seam (injected: AsyncStorage / localStorage)
  keys.ts            secret registry -> SecureStore only
src/providers/     one module per source, each `(ctx) => Promise<Finding[]>`
src/platform/     the only place react-native/expo modules are imported
src/ui/           zustand store, screens, kit components, theme
tools/proxy.mjs    web-only credential relay (see CORS note)
scripts/*.test.mts node:test suites that import the shipping modules directly
```

Two rules keep this testable and are enforced by the tests:

1. **`src/core` and `src/providers` never import `react-native`.** That is what lets the
   exact code that runs on the phone be exercised in Node against live endpoints.
2. **`registry invariants`** — every provider declares which entity kinds it answers, ids
   are unique, and `requiresKey` must agree with `SECRET_FIELDS` (a provider claiming a
   key it has no field for would silently return `nokey` forever).

Adding a source is one file plus one line in `registry.ts`:

```ts
export const mysource: Provider = {
  id: 'custom', name: 'My source', entities: ['domain'], requiresKey: true,
  blurb: '…', signupUrl: 'https://…',
  async run({ entity, key, signal }) {
    const r = await getJson<MyResp>(`https://api.example/v1/${entity.normalized}`, { signal, headers: { Key: key ?? '' } });
    return [finding('custom', 'Widget count', String(r.count), { kind: r.count > 5 ? 'flag' : 'fact', severity: r.count > 5 ? 'medium' : 'none' })];
  },
};
```

Anything you do not want to write code for goes in **Settings → Custom sources** — a JSON
array of `{name, urlTemplate, headers, entities, keySecret, resultPath}` with
`{entity} {rootDomain} {ip} {domain} {secret}` substitution, flattened into findings.

## Keys

Paste them in the app at runtime; they are written to `expo-secure-store` (Android
keystore-backed) and never to AsyncStorage, never to a bundle, and never to a log line —
`redactHeaders()` truncates any `key|token|authorization|auth` header to 3 chars. Nothing
is compiled in, so a leaked repo is not a leaked key, and you can share the source.

I have not seen your keys and do not need them. Do not paste them into this chat.

## CORS, and why the phone does not care

`rdap.org`, `dns.google`, `crt.sh`, `ipwho.is` and `ipapi.is` answer cross-origin; almost
nothing else does (VirusTotal, AbuseIPDB, Shodan, OTX, abuse.ch send no
`Access-Control-Allow-Origin`). React Native has no CORS layer, so **on device every call
is direct and this is a non-issue**. For the web build, run the relay:

```
npm run proxy                                             # 127.0.0.1:8799
# Settings → HTTP proxy base → http://127.0.0.1:8799
```

`tools/proxy.mjs` binds loopback, logs nothing, caps body size, refuses non-http(s)
schemes and any private/link-local target (there is a test for that), and only exists so
you can develop the UI in a browser. Do not ship it on a public host without adding
`--allow-hosts`.

## Building the APK

Expo Go is enough for day-to-day use. For a real install:

```
npx expo prebuild -p android            # generates android/ (autolinked modules)
cd android && ./gradlew assembleRelease # needs JDK 17 + Android SDK
# or, no local toolchain:
eas build -p android --profile preview  # EAS cloud build
```

`scheme: osint` + the `VIEW` intent filter mean `osint://…` links open straight into a
scan (see `App.tsx`), which is what makes "send a suspicious URL to the phone, tap, done"
work. A true share-sheet target (`ACTION_SEND` with `EXTRA_TEXT`) needs a small native
module or config plugin to read the intent extras — deliberately not faked here; the
filter that does work is the deep link.

## What is verified

Run locally: `npm run check` (typecheck both configs, 11 unit tests, 6 rendered-UI tests)
and `OSINT_LIVE=1 npm run test:live`.

Live against the real APIs from this machine, passing: **RDAP** (Verisign), **DNS over
HTTPS** incl. DMARC/SPF/wildcard logic, **ipwho.is**, **crt.sh → CertSpotter fallback**,
**metadata/EXIF** (real JPEG with GPS; SHA-256 cross-checked against `node:crypto`), the
**401 rejection path** for VirusTotal, and the **nokey skip path** for five keyed
providers. The web relay proxy was also exercised end-to-end including its SSRF guards.

Not verifiable here, so treat as *written-but-untested*: Shodan, LeakIX, IP2WHOIS,
DNSDumpster, StalkPhish, EmailRep, FraudLabs, URLhaus and PhishReport against a real key.
Their request/response shapes are built from each vendor's current docs (abuse.ch `Auth:
api=…`, DNSDumpster `X-API-Key` on `api.dnsdumpster.com/domain/{d}`, StalkPhish
`Authorization: Token …` on `/api/v1/search/url|ipv4`), and each one surfaces a clear
error + hint instead of a blank card if a field moved.

Two notes from probing while building: **abuse.ch now requires an account key** for URLhaus
(401 without it), and **EmailRep's anonymous API is disabled** — both are wired as
keyed providers for that reason. PhishTank's public feed was dropped (404s; it moved behind
registration); if you want it, it fits the Custom source shape.

## Building the APK (GitHub Actions, no local toolchain)

`.github/workflows/android.yml` builds a standalone, installable APK on a GitHub runner.
This is the recommended path from a phone: the runner has JDK 17 and the Android SDK, and
nothing about it requires you to compile anything locally.

**Pushing from the phone.** Two rules: push the *source*, and never push `node_modules`
(300+ MB, gitignored — if a git app offers "add all untracked", decline) or `android/`,
which `expo prebuild` regenerates on the runner. The whole tracked tree is 70 files and
1.2 MB; `osint-mobile-src.zip` in the chat workspace is exactly that, and it already
excludes the junk.

Do **not** paste the commands below as one block. `gh auth login` stops and waits for a
one-time code, so any lines pasted after it are typed into that prompt and lost. Paste one
chunk, let it finish, paste the next.

*Chunk 1 — tools, and permission to reach your Downloads folder.* Node/npm are not needed
here at all; the runner does every install.

```bash
pkg update
pkg install -y git gh unzip
termux-setup-storage    # tap "Allow" on the Android dialog
```

*Chunk 2 — unpack the source.* Chrome puts downloads in `Download`; adjust the path if
yours went elsewhere.

```bash
mkdir -p ~/osint-mobile && cd ~/osint-mobile
unzip -o ~/storage/shared/Download/osint-mobile-src.zip
```

*Chunk 3 — authenticate.* This one is interactive: it prints `First copy your one-time
code: XXXX-XXXX`, opens (or asks you to open) github.com/login/device, and does not return
until you approve. If Termux has no keyring it may mention storage — add
`--insecure-storage` to that line and it will store the token in `~/.config/gh/hosts.yml`.

```bash
gh auth login -h github.com -p https -w
gh auth setup-git       # so git can reuse the gh token for the push
```

*Chunk 4 — commit and push.* Git refuses to commit without an identity, which is why the
first two lines are there; use the email on your GitHub account so the commit is attributed.

```bash
cd ~/osint-mobile
git config --global user.name "Your Name"
git config --global user.email you@example.com
git init -b main
git add -A
git commit -m "OSINT console"
git log --oneline -1    # sanity check: 70 files, no node_modules
gh repo create osint-mobile --private --source=. --push
```

`git add -A` is safe because `.gitignore` is in the zip — verify it with `git status -s |
wc -l` before committing if you want to see the count rather than trust it.

**No Termux?** GitHub's mobile web UI takes it: *New repository → uploading files*. Two
caveats. Browsers silently skip dotfiles when you pick a folder, so `.github/` and
`.gitignore` will not come along — after uploading, use *Add file → Create new file* and
type the path `.github/workflows/android.yml` to add the workflow. And that path matters
exactly: `.github`, at the repository root, `.yml` extension, or Actions never sees it.

Then **Actions → Android APK → Run workflow** (choose `release`). Expect roughly 6–10
minutes for a cold build — not the 2–4 minutes most write-ups quote; the first run also
downloads Gradle and every Android dependency. The APK is under *Artifacts → osint-apk*.

Why release and not debug: `assembleDebug` produces an APK that looks for Metro at
`10.0.2.2:8081` and sits on "Loading..." forever with no computer attached. `assembleRelease`
embeds the JS bundle and Hermes bytecode, so it runs on its own. The RN template signs
release with the checked-in debug keystore, which is fine for sideloading your own build
and not something you would publish to Play.

If you would rather not run Gradle at all, `eas build -p android --profile preview` does
the same job on Expo's infrastructure.

### Verified here, and what was not

Ran locally, green: `expo prebuild -p android` (generates 2 Kotlin files, **0 TypeScript
files** in the native project), `expo export --platform android` (produces a 2.5 MB
`index.hbc`), `npm run check` (11 unit + 6 rendered-UI tests), and `OSINT_LIVE=1`
provider tests (9). Not run: `./gradlew assembleRelease` — this sandbox has JDK 11 and no
Android SDK, which is exactly the gap the runner fills. So the workflow's *inputs* are
proven and its final packaging step is not.

Two real bugs were caught by running those steps and would otherwise have failed your first
CI run:

* `app.json` pointed `adaptiveIcon.foregroundImage` at `assets/adaptive-icon.png`, which
  the SDK 57 template does not ship — `expo prebuild` aborted with
  `ENOENT ... ./assets/adaptive-icon.png`. Now uses `android-icon-foreground/background/monochrome.png`.
* `exifr`'s main build contains a Node-only `await import('fs')`, which Metro lowers to a
  raw `import()` expression that the Hermes byte compiler rejects (`Invalid expression
  encountered`) — inside `expo export:embed`, i.e. every release build. The provider now
  uses `exifr/dist/lite.umd.js` (GPS + IFD0 identifying tags, verified against
  `fixtures/exif-sample.jpg`) and reports *"Parser coverage: EXIF + GPS only"* so the
  missing XMP/IPTC range is visible instead of looking like a clean photo.

## Deliberate limits

* Phone recon is **structure only** (validity, region, line type, carrier class). No
  "who owns this number" lookup is wired in, because a fraud-screening tool does not need
  to become a people-locating one.
* CIDR input is **sampled**, capped by `Settings → CIDR sample size` (default 32 of N).
  A /8 is 16.7M addresses; the app reports the size instead of silently hammering it.
* No credential testing, no login forms, no brute force, no account enumeration.
* Findings are deduplicated and history is device-local; there is no server in this
  project at all.

See [SECURITY.md](./SECURITY.md) for the authorisation rules this app assumes.
