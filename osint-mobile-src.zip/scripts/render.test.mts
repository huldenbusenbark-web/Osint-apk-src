import test from 'node:test';
import assert from 'node:assert/strict';
import { register } from 'node:module';
import { JSDOM } from 'jsdom';
import { fileURLToPath } from 'node:url';

const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', { url: 'http://localhost/' });
const g = globalThis as any;
// react-native-web touches a pile of DOM constructors at module scope, so copy
// the whole window surface rather than guessing which ones it wants.
for (const key of Object.getOwnPropertyNames(dom.window)) {
  if (key in g) continue;
  try {
    g[key] = (dom.window as any)[key];
  } catch {
    /* read-only or throwing getters are fine to skip */
  }
}
g.window = dom.window;
g.document = dom.window.document;
g.navigator = dom.window.navigator;
g.localStorage = dom.window.localStorage;
g.requestAnimationFrame = (cb: (t: number) => void) => setTimeout(() => cb(Date.now()), 0);
g.cancelAnimationFrame = (id: number) => clearTimeout(id);
g.matchMedia = g.matchMedia ?? (() => ({ matches: false, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} }));

register(new URL('./rnw-alias-hooks.mjs', import.meta.url));

const React = (await import('react')).default;
const { act } = await import('react');
const { createRoot } = await import('react-dom/client');
(g as any).IS_REACT_ACT_ENVIRONMENT = true;
const { configureStores, MemoryStore } = await import('../src/core/store.ts');
configureStores({ plain: new MemoryStore(), secret: new MemoryStore() });
const { useApp } = await import('../src/ui/store.ts');
const { ScanScreen } = await import('../src/ui/screens/ScanScreen.tsx');
const { HistoryScreen } = await import('../src/ui/screens/HistoryScreen.tsx');
const { SettingsScreen } = await import('../src/ui/screens/SettingsScreen.tsx');
const { PROVIDERS } = await import('../src/core/registry.ts');
const { DEMO_FINDINGS } = await import('../src/core/demo.ts');
const { scan } = await import('../src/core/scanner.ts');
const { DEFAULTS } = await import('../src/core/settings.ts');
const { detect } = await import('../src/core/entity/detect.ts');

/**
 * Mount for real (client root in jsdom) rather than renderToStaticMarkup:
 * zustand v5 hands React `getInitialState` as the server snapshot, so an SSR
 * render would ignore every setState the test performs and prove nothing.
 */
const h = (el: any): string => {
  const host = g.document.createElement('div');
  g.document.body.appendChild(host);
  const root = createRoot(host);
  act(() => root.render(el));
  const html = host.innerHTML;
  act(() => root.unmount());
  host.remove();
  return html;
};

test('every screen mounts', () => {
  for (const [name, el] of [
    ['Scan', React.createElement(ScanScreen, { pickImage: () => undefined })],
    ['History', React.createElement(HistoryScreen, null)],
    ['Settings', React.createElement(SettingsScreen, null)],
  ] as [string, any][]) {
    const html = h(el);
    assert.ok(html.length > 500, `${name} rendered nothing`);
    assert.ok(!/undefined|NaN|\[object Object\]/.test(html.replace(/aria[^>]*/g, '')), `${name} leaked an undefined/NaN into the markup`);
  }
});

test('scan screen shows the entity preview and the run affordance', () => {
  useApp.setState({ input: '203.0.113.0/24', attachments: [], result: null, live: [], running: false, notice: null, settings: { ...DEFAULTS, demo: true }, targets: [], filter: { sev: null, provider: null } });
  const html = h(React.createElement(ScanScreen, { pickImage: () => undefined }));
  assert.match(html, /cidr/, 'entity kind chip');
  assert.match(html, /203\.0\.113\.0\/24/, 'normalised target');
  assert.match(html, /256 addrs, sampling 32/, 'CIDR size warning is surfaced before any request is made');
  assert.match(html, /Run \d+ sources/, 'the button states what it will query');
});

test('out-of-scope verdict is rendered prominently, and the export path is reachable', async () => {
  const result = await scan({ entity: detect('example.com'), config: { ...DEFAULTS, demo: true, providers: PROVIDERS.map((p) => p.id) }, attachments: [] });
  useApp.setState({ input: 'example.com', result, live: result.results, settings: { ...DEFAULTS, demo: true }, filter: { sev: null, provider: null }, attachments: [] });
  const html = h(React.createElement(ScanScreen, { pickImage: () => undefined }));
  assert.match(html, /OUT OF SCOPE/, 'the flag from the scope provider must be visible');
  assert.match(html, /critical/, 'verdict severity');
  assert.match(html, /do not send traffic to it/i, 'the UI must explain the consequence, not just colour it red');
  assert.match(html, /Copy MD/, 'export button');
  assert.ok(Object.keys(DEMO_FINDINGS).length >= 15);
  const rows = (html.match(/border-left/g) ?? []).length;
  assert.ok(rows >= 12, `expected grouped finding rows, saw ${rows}`);
});

test('settings lists each source with its key state and signup link', () => {
  useApp.setState({ settings: { ...DEFAULTS, scope: 'example.com\n203.0.113.0/28' }, secretStatus: { shodanKey: true }, targets: [], history: [] });
  const html = h(React.createElement(SettingsScreen, null));
  assert.match(html, /AbuseIPDB/);
  assert.match(html, /VirusTotal v3/);
  assert.match(html, /get a key/i, 'a signup link per keyed source');
  assert.match(html, /Refuse to query providers for out-of-scope targets/);
  assert.match(html, /Authorised scope \(2 entries\)/, 'the label must count what parseScope actually read: one domain + one CIDR');
});

test('history renders the watch list and its empty state', () => {
  useApp.setState({ history: [], targets: [], tab: 'history' } as never);
  const empty = h(React.createElement(HistoryScreen, null));
  assert.match(empty, /Watch list \(0\)/);
  assert.match(empty, /your API quota, not traffic to the asset/, 'the cost warning belongs to the empty state, where you decide to start using it');

  useApp.setState({
    targets: [{ value: 'example.com', kind: 'domain', addedAt: Date.now(), worst: 'high', note: '1 flag' }],
  } as never);
  const full = h(React.createElement(HistoryScreen, null));
  assert.match(full, /Watch list \(1\)/);
  assert.match(full, /example\.com/);
  assert.match(full, /domain · added .* · 1 flag/);
  assert.match(full, /never scanned/, 'an un-saved-but-never-scanned distinction must be visible');
  assert.match(full, /Scan now/);
});

test('a saved scan row reports source coverage and failures', async () => {
  const result = await scan({ entity: detect('203.0.113.9'), config: { ...DEFAULTS, demo: true, providers: PROVIDERS.map((p) => p.id) } });
  useApp.setState({ history: [result], targets: [], tab: 'history' } as never);
  const html = h(React.createElement(HistoryScreen, null));
  assert.match(html, />ip</, 'entity kind chip');
  assert.match(html, /203\.0\.113\.9/);
  assert.match(html, /\/19 sources/, 'coverage must be stated as answered\/total, not just a count of findings');
});
