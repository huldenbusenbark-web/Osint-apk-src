import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { detect } from '../src/core/entity/detect.ts';
import { configureHttp } from '../src/core/net/http.ts';
import { getJson } from '../src/core/net/http.ts';
import { sha256Hex } from '../src/core/crypto.ts';
import { rdap } from '../src/providers/rdap.ts';
import { dns } from '../src/providers/dns.ts';
import { ipgeo } from '../src/providers/ipgeo.ts';
import { metadata } from '../src/providers/metadata.ts';
import { scope } from '../src/providers/scope.ts';
import { virustotal } from '../src/providers/virustotal.ts';
import { PROVIDERS } from '../src/core/registry.ts';
import { scan } from '../src/core/scanner.ts';
import { keys, SECRET_FIELDS } from '../src/core/keys.ts';
import { DEFAULTS } from '../src/core/settings.ts';
import { MemoryStore, configureStores } from '../src/core/store.ts';

configureStores({ plain: new MemoryStore(), secret: new MemoryStore() });
const LIVE = process.env.OSINT_LIVE === '1' ? false : 'set OSINT_LIVE=1 to hit the real APIs';
const here = dirname(fileURLToPath(import.meta.url));
const ctxFor = (input: string, extra: Record<string, unknown> = {}) => {
  const entity = detect(input);
  return { entity, config: { ...DEFAULTS, providers: PROVIDERS.map((p) => p.id) }, signal: new AbortController().signal, key: undefined as string | undefined, secret: () => undefined as string | undefined, log: () => undefined, ...extra };
};

test('rdap: live registration data for example.com', { skip: LIVE }, async () => {
  const f = await rdap.run(ctxFor('example.com') as never);
  const labels = f.map((x) => x.label);
  assert.ok(labels.includes('Registrar'), `expected a Registrar finding, got ${labels.join('/')}`);
  assert.ok(labels.some((l) => /Registered|Expires/.test(l)), 'events should be present');
  assert.ok(f.some((x) => x.label === 'Nameservers'), 'IANA serves nameservers for this TLD');
});

test('rdap: an unregistered domain surfaces as a flag, not an error', { skip: LIVE }, async () => {
  const f = await rdap.run(ctxFor('zz-kwythbqptvzkxjmq.invalid') as never);
  assert.ok(Array.isArray(f), 'either findings or a thrown http error are acceptable, not undefined');
});

test('dns: live DoH answer plus DMARC/SPF verdict', { skip: LIVE }, async () => {
  const f = await dns.run(ctxFor('example.com') as never);
  assert.ok(f.some((x) => x.label === 'A' && /\d+\.\d+\.\d+\.\d+/.test(x.value)), 'A record must be parsed');
  assert.ok(f.some((x) => x.label === 'DMARC'), 'DMARC presence is the point of this provider');
  const spf = f.find((x) => x.label === 'SPF');
  assert.ok(spf, 'SPF must be reported');
  assert.ok(spf!.kind === 'flag', 'SPF is a judgement, so it must be flagged not just listed');
});

test('ipgeo: live, keyless geolocation', { skip: LIVE }, async () => {
  const f = await ipgeo.run(ctxFor('8.8.8.8') as never);
  assert.ok(f.some((x) => x.label === 'Location' && x.value !== 'unknown'), JSON.stringify(f.slice(0, 3)));
  assert.ok(f.some((x) => x.label === 'ASN' && x.value.startsWith('AS')), 'Google DNS is AS15169');
});

test('metadata: reads real EXIF GPS out of a JPEG on disk', { skip: LIVE }, async () => {
  const bytes = readFileSync(join(here, '..', 'fixtures', 'exif-sample.jpg'));
  const buf = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
  const f = await metadata.run(ctxFor('example.com', { attachments: [{ kind: 'image', uri: 'file://sample.jpg', name: 'exif-sample.jpg', bytes: buf }] }) as never);
  const gps = f.find((x) => x.label === 'GPS');
  assert.ok(gps, `no GPS finding; labels: ${f.map((x) => x.label).join('/')}`);
  assert.match(gps!.value, /47\.606/, 'latitude from the fixture');
  assert.equal(gps!.severity, 'critical', 'embedded coordinates in a shared photo are the highest-impact thing this app can find');
  const sha = f.find((x) => x.label === 'SHA-256')!;
  assert.equal(sha.value, createHash('sha256').update(bytes).digest('hex'), 'digest must match node crypto');
  assert.equal(await sha256Hex(new Uint8Array(bytes)), sha.value);
  assert.ok(f.some((x) => x.label === 'Type' && x.value === 'JPEG'));
});

test('provider failure is reported with an actionable hint, not swallowed', { skip: LIVE }, async () => {
  await keys.set('virustotalKey', 'obviously-not-a-real-key');
  const result = await scan({ entity: detect('example.com'), config: { ...DEFAULTS, providers: ['virustotal'] } });
  const r = result.results.find((x) => x.provider === 'virustotal')!;
  assert.ok(r.status === 'error' || r.findings.length > 0, `unexpected ${r.status}`);
  if (r.status === 'error') {
    assert.match(r.error!.message, /401|403/, 'VT rejects a bad key with 401/403');
    assert.match(r.error!.hint!, /rejected your key/i, 'the UI must tell the user what to do about it');
    assert.ok(!JSON.stringify(result).includes('obviously-not-a-real-key'), 'a rejected key must not appear anywhere in the result tree');
  }
  await keys.set('virustotalKey', '');
});

test('keyed providers report nokey rather than failing when unset', { skip: LIVE }, async () => {
  const want = ['shodan', 'leakix', 'abuseipdb', 'otx', 'dnsdumpster'] as const;
  const result = await scan({ entity: detect('example.com'), config: { ...DEFAULTS, providers: [...want] } });
  for (const r of result.results.filter((x) => (want as readonly string[]).includes(x.provider))) {
    assert.equal(r.status, 'nokey', `${r.provider} should be skipped for want of a key`);
    assert.match(r.skippedReason!, /API key/);
  }
  assert.ok(SECRET_FIELDS.shodan?.key);
});

test('scope provider queries certificate transparency', { skip: LIVE }, async () => {
  const f = await scope.run({ ...(ctxFor('example.com') as never), config: { ...DEFAULTS, demo: false } });
  assert.ok(f.some((x) => /Scope/.test(x.label)), 'scope verdict always present');
  assert.ok(f.some((x) => x.label.startsWith('Certificate names')), 'crt.sh should answer');
});

test('the web relay proxy round-trips a real API call', { skip: LIVE }, async () => {
  const port = 8799;
  const child = spawn(process.execPath, [join(here, '..', 'tools', 'proxy.mjs'), '--port', String(port)], { stdio: 'ignore' });
  const cleanup = () => child.kill('SIGKILL');
  try {
    await new Promise((r) => setTimeout(r, 500));
    const health = await fetch(`http://127.0.0.1:${port}/health`).then((r) => r.json());
    assert.equal(health.ok, true);

    configureHttp({ proxyBase: `http://127.0.0.1:${port}` });
    const viaProxy = await getJson<{ ldhName?: string }>('https://rdap.org/domain/example.com');
    assert.equal(String(viaProxy.ldhName).toLowerCase(), 'example.com', 'proxied call must return the same payload');

    const ssrf = await fetch(`http://127.0.0.1:${port}/fetch`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ url: 'http://127.0.0.1:6379/' }) }).then((r) => r.json());
    assert.match(ssrf.error, /private address/, 'the relay must refuse to be pointed at localhost/internal services');
    const scheme = await fetch(`http://127.0.0.1:${port}/fetch`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ url: 'file:///etc/passwd' }) }).then((r) => r.json());
    assert.match(scheme.error, /only http\(s\)/);
  } finally {
    configureHttp({ proxyBase: '' });
    cleanup();
  }
});
