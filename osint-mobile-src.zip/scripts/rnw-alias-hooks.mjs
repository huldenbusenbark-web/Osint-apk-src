export { resolve } from './rnw-alias.mjs';
