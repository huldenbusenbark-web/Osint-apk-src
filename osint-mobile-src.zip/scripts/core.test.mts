import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { detect, classify, rootDomain, inScope, parseScope, hashAlgorithm } from '../src/core/entity/detect.ts';
import { parseCidr, ipInCidr, isIpv4, isIpv6 } from '../src/core/entity/ipv4.ts';
import { sha256Hex, sha256Base64Url, toBase64Url } from '../src/core/crypto.ts';

import { finding } from '../src/core/normalize.ts';
import { providersFor, PROVIDERS, byId } from '../src/core/registry.ts';
import { dedupe, scan, summarise } from '../src/core/scanner.ts';
import { MemoryStore, configureStores } from '../src/core/store.ts';
import { keys, SECRET_FIELDS } from '../src/core/keys.ts';
import { DEFAULTS } from '../src/core/settings.ts';
import { toMarkdown, toCsv } from '../src/core/history.ts';

configureStores({ plain: new MemoryStore(), secret: new MemoryStore() });

test('entity classification is unambiguous for every accepted input', () => {
  const cases: [string, string][] = [
    ['example.com', 'domain'],
    ['sub.example.co.uk', 'domain'],
    ['203.0.113.7', 'ip'],
    ['198.51.100.0/24', 'cidr'],
    ['http://examp.lo/a?b=1', 'url'],
    ['examp.lo/a?b=1', 'url'],
    ['someone@corp.example.com', 'email'],
    ['+14255550123', 'phone'],
    ['(425) 555-0123', 'phone'],
    ['d41d8cd98f00b204e9800998ecf8427e', 'hash'],
    ['AS15169', 'asn'],
    ['15169', 'asn'],
    ['2001:db8::1', 'ip'],
    ['tel:+44 20 7946 0000', 'phone'],
  ];
  for (const [input, kind] of cases) assert.equal(classify(input.replace(/^tel:/, ''), kind), kind, `classify(${input})`);
  assert.equal(detect('(425) 555-0123').kind, 'phone');
  assert.equal(detect('203.0.113.7').kind, 'ip', 'an IP must win over the phone heuristic');
});

test('not every number is a phone number, and not every hex string is a hash', () => {
  assert.notEqual(classify('12345'), 'phone', 'a 5-digit fragment must not become a phone lookup');
  assert.equal(hashAlgorithm('1234567890abcdef'), undefined, 'wrong-length hex is not a hash');
  assert.equal(hashAlgorithm('d41d8cd98f00b204e9800998ecf8427e'), 'md5');
  assert.equal(hashAlgorithm('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'), 'sha256');
});

test('registrable domain keeps public-suffix second levels', () => {
  assert.equal(rootDomain('shop.example.co.uk'), 'example.co.uk');
  assert.equal(rootDomain('a.b.c.example.com'), 'example.com');
  assert.equal(rootDomain('example.com'), 'example.com');
  assert.equal(detect('https://Mail.Example.COM:8443/inbox?x=1').url?.host, 'mail.example.com');
});

test('CIDR maths', () => {
  assert.ok(isIpv4('0.0.0.0') && !isIpv4('256.1.1.1'));
  assert.ok(isIpv6('2001:db8::1') && !isIpv6('2001:db8:::1'));
  const c = parseCidr('198.51.100.0/24', 8);
  assert.equal(c.network, '198.51.100.0');
  assert.equal(c.last, '198.51.100.255');
  assert.equal(c.size, '256');
  assert.equal(c.sample.length, 8);
  assert.equal(c.sample[0], '198.51.100.0');
  assert.equal(c.sample.at(-1), '198.51.100.255', 'the broadcast address is always sampled');
  assert.equal(c.truncated, true);
  assert.equal(ipInCidr('198.51.100.77', '198.51.100.0/24'), true);
  assert.equal(ipInCidr('198.51.101.77', '198.51.100.0/24'), false);
  assert.equal(parseCidr('10.0.0.0/8', 4).size, '16777216', 'a /8 is reported, never expanded');
});

test('digests match node crypto', async () => {
  for (const s of ['', 'a', 'example.com', 'https://x.y/z?q=1', 'the quick brown fox jumps over the lazy dog']) {
    assert.equal(await sha256Hex(s), createHash('sha256').update(s).digest('hex'), `sha256(${JSON.stringify(s)})`);
  }
  const id = await sha256Base64Url('http://example.com/');
  assert.equal(id, createHash('sha256').update('http://example.com/').digest('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''));
  assert.ok(!id.includes('='), 'VT wants unpadded base64url');
  assert.equal(toBase64Url(new Uint8Array([0xff, 0xfe, 0xfd])), '__79', 'no padding, url alphabet');
});

test('scope guard: matching is on the registrable domain, and empty scope means no gate', () => {
  const s = parseScope('example.com\n203.0.113.0/28\n*.staging.example.org');
  assert.deepEqual(s.cidrs, ['203.0.113.0/28'], 'a /28 must stay a CIDR, not degrade to one host');
  assert.equal(inScope(detect('api.example.com'), s), true);
  assert.equal(inScope(detect('example.com.evil.test/'), s), false, 'suffix tricks must not satisfy scope');
  assert.equal(inScope(detect('203.0.113.4'), s), true, 'CIDR scope entries must survive parsing');
  assert.equal(inScope(detect('203.0.114.4'), s), false);
  assert.equal(inScope(detect('a.staging.example.org'), s), true);
  assert.equal(inScope(detect('anything-at-all.com'), parseScope('')), true);
});

test('registry invariants', () => {
  const phone = providersFor('phone').map((p) => p.id);
  assert.ok(phone.includes('phoneparse'), 'a phone number must always get an offline answer');
  assert.ok(!phone.includes('shodan'), 'Shodan cannot answer for a phone number and must not be offered');
  assert.equal(new Set(PROVIDERS.map((p) => p.id)).size, PROVIDERS.length, 'provider ids must be unique');
  for (const p of PROVIDERS) {
    assert.equal(byId.get(p.id), p, `${p.id} must be resolvable from byId`);
    // A provider that claims to need a key but has no secret field would
    // silently return `nokey` forever, so the registry has to agree with keys.ts.
    if (p.requiresKey) assert.ok(SECRET_FIELDS[p.id]?.key, `${p.id} requires a key but declares no secret field`);
    else assert.equal(SECRET_FIELDS[p.id]?.key, undefined, `${p.id} is keyless but declares a secret field`);
    assert.ok(p.blurb.length > 12 && p.name.length > 2, `${p.id} needs a real name and blurb`);
  }
});

test('demo mode runs the whole orchestrator with no network', async () => {
  const result = await scan({
    entity: detect('example.com'),
    config: { ...DEFAULTS, demo: true, providers: PROVIDERS.map((p) => p.id), concurrency: 4 },
  });
  assert.ok(result.results.length >= 12, 'most providers should have answered');
  assert.ok(result.results.every((r) => r.status === 'ok' || r.status === 'skipped' || r.status === 'nokey'));
  assert.ok(result.verdict.severity === 'critical', 'the demo fixture includes an out-of-scope flag');
  assert.ok(result.results.some((r) => r.provider === 'rdap' && r.findings.length > 3));
  const md = toMarkdown(result);
  assert.match(md, /# OSINT lookups — example.com/);
  assert.match(md, /OUT OF SCOPE/);
  assert.match(md, /Passive lookups only/);
  assert.match(toCsv(result), /^provider,label,value,severity,detail,link$/m);
  // The point of the export is that it is pasteable into a ticket, so it must
  // not carry the configured credential even when a provider echoes it back.
  const SECRET = 'vt-live-secret-9f3a';
  await keys.set('virustotalKey', SECRET);
  const withKey = await scan({ entity: detect('example.com'), config: { ...DEFAULTS, demo: true, providers: ['virustotal', 'dns', 'rdap'] } });
  const exported = toMarkdown(withKey) + toCsv(withKey);
  assert.ok(!exported.includes(SECRET), 'exports leaked a key');
  assert.ok(!exported.includes('•••'), 'exports must not even carry the redaction placeholder');
  await keys.set('virustotalKey', '');
});

test('enforceScope actually refuses the network work, not just the banner', async () => {
  const calls: string[] = [];
  const spy = (await import('../src/core/net/http.ts')).configureHttp;
  void spy;
  const cfg = (over: Record<string, unknown>) => ({ ...DEFAULTS, demo: false, providers: PROVIDERS.map((p) => p.id), ...over });

  // In scope: providers are attempted (they will fail offline / for keys, but they
  // must be *attempted*, i.e. not reported as refused).
  const inside = await scan({ entity: detect('example.com'), config: cfg({ scope: 'example.com', enforceScope: true }) as never });
  const insideNonScope = inside.results.filter((r) => r.provider !== 'scope');
  assert.ok(insideNonScope.length > 0);
  assert.ok(insideNonScope.every((r) => r.status !== 'skipped' || r.skippedReason === 'disabled'), 'an in-scope target must not be refused');

  // Out of scope with enforcement on: nothing but the scope check is reported as run.
  const outside = await scan({ entity: detect('victim-not-mine.test'), config: cfg({ scope: 'example.com', enforceScope: true }) as never });
  const attempted = outside.results.filter((r) => r.status === 'ok' || r.status === 'error' || r.status === 'nokey' || r.status === 'timeout');
  assert.deepEqual(attempted.map((r) => r.provider), ['scope'], `only the scope check may run, saw ${attempted.map((r) => r.provider).join(',')}`);
  const refused = outside.results.filter((r) => r.skippedReason?.startsWith('refused:'));
  assert.ok(refused.length >= 5, 'every other provider must be reported as refused, visibly');
  assert.match(refused[0]!.skippedReason!, /outside your saved scope/);
  assert.equal(calls.length, 0);

  // Enforcement off: the app still warns, but passive lookups proceed.
  const loose = await scan({ entity: detect('victim-not-mine.test'), config: cfg({ scope: 'example.com', enforceScope: false }) as never });
  assert.ok(loose.results.filter((r) => r.status === 'nokey').length > 0, 'with enforcement off, keyed providers are attempted and skip on keys');

  // No scope configured at all -> enforcement cannot be meaningful, must not lock everything out.
  const noScope = await scan({ entity: detect('example.com'), config: cfg({ scope: '', enforceScope: true }) as never });
  assert.ok(noScope.results.filter((r) => r.skippedReason?.startsWith('refused:')).length === 0, 'an empty scope must not refuse everything');
});

test('resolveExifr survives every UMD interop shape and fails loudly when none match', async () => {
  const { resolveExifr } = await import('../src/providers/metadata.ts');
  const parse = async () => ({ latitude: 1 });
  assert.ok(resolveExifr({ parse }), 'plain module');
  assert.ok(resolveExifr({ default: { parse } }), 'esModuleInterop default');
  assert.ok(resolveExifr({ default: { default: { parse } } }), 'double-wrapped namespace');
  assert.equal(resolveExifr({ default: { notTheParser: 1 } }), undefined, 'a wrong shape must resolve to nothing, not to a stub');
  assert.equal(resolveExifr(undefined), undefined);
});

test('verdict maths ignores plain facts and counts only flags', () => {
  const flat = [
    finding('dns', 'A', '1.2.3.4', { severity: 'info' }),
    finding('urlhaus', 'Live malware URL', 'http://bad', { kind: 'flag', severity: 'critical' }),
  ];
  const v = summarise(flat, [{ provider: 'dns', status: 'ok', ms: 1, findings: [] }, { provider: 'otx', status: 'nokey', ms: 0, findings: [], skippedReason: 'no key' }]);
  assert.equal(v.severity, 'critical');
  assert.equal(v.flags, 1);
  assert.match(v.summary, /1 source skipped for want of a key/);
  assert.equal(dedupe([...flat, ...flat]).length, 2, 're-scanning must not duplicate findings');
});
