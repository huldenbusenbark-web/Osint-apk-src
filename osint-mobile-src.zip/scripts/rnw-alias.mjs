// Lets Node resolve `react-native` to `react-native-web` so the real screen
// components can be rendered/verified outside a device. Test-only: Metro keeps
// resolving react-native normally, so nothing in the shipped app changes.
export async function resolve(specifier, context, next) {
  if (specifier === 'react-native') return next('react-native-web', context);
  return next(specifier, context);
}
