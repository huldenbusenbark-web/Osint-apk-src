/**
 * Test-only alias so `react-native` resolves to `react-native-web` in Node and
 * the real screen components can be rendered headlessly.
 * ESM customization hooks do not cover CJS require() on Node 20, and
 * react-native-web itself is CJS, so both layers are patched.
 */
import Module from 'node:module';
import { register } from 'node:module';

const alias = (request) => (request === 'react-native' ? 'react-native-web' : request);

const origResolveFilename = Module._resolveFilename;
Module._resolveFilename = function (request, parent, ...rest) {
  return origResolveFilename.call(this, alias(request), parent, ...rest);
};
const origLoad = Module._load;
Module._load = function (request, parent, isMain) {
  return origLoad.call(this, alias(request), parent, isMain);
};

register(new URL('./rnw-alias-hooks.mjs', import.meta.url));
