#!/usr/bin/env node
/**
 * Credential-relay for the WEB build only.
 *
 * Why it exists: browsers apply CORS, and almost none of these APIs send
 * Access-Control-Allow-Origin (rdap.org, dns.google and crt.sh being the
 * useful exceptions). React Native on the phone has no CORS, so the app never
 * needs this. Run it when you want to develop the UI in a browser:
 *
 *   node tools/proxy.mjs            # listens on 127.0.0.1:8799
 *   Settings → HTTP proxy base → http://127.0.0.1:8799
 *
 * Security notes, because this forwards your API keys:
 *  - binds to loopback by default; --host 0.0.0.0 only if you know why
 *  - no request logging, no disk writes, body size capped
 *  - refuses non-http(s) targets and anything with credentials in the URL
 */
import { createServer } from 'node:http';

const args = process.argv.slice(2);
const get = (flag, dflt) => {
  const i = args.indexOf(flag);
  return i === -1 ? dflt : args[i + 1];
};
const HOST = get('--host', '127.0.0.1');
const PORT = Number(get('--port', '8799'));
const MAX_BODY = 512 * 1024;
const ALLOWED = new Set((get('--allow-hosts', '') || '').split(',').filter(Boolean));

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const server = createServer((req, res) => {
  if (req.method === 'OPTIONS') {
    for (const [k, v] of Object.entries(cors)) res.setHeader(k, v);
    res.writeHead(204).end();
    return;
  }
  if (req.url === '/health') {
    res.writeHead(200, { 'content-type': 'application/json', ...cors }).end(JSON.stringify({ ok: true, host: HOST, port: PORT }));
    return;
  }
  if (req.url !== '/fetch' || req.method !== 'POST') {
    res.writeHead(404, { ...cors, 'content-type': 'text/plain' }).end('POST /fetch {url, method, headers, body}');
    return;
  }
  let raw = '';
  let overflow = false;
  req.on('data', (c) => {
    raw += c;
    if (raw.length > MAX_BODY) {
      overflow = true;
      req.destroy();
    }
  });
  req.on('end', async () => {
    if (overflow) return;
    const reply = (code, obj) => res.writeHead(code, { ...cors, 'content-type': 'application/json' }).end(JSON.stringify(obj));
    let msg;
    try {
      msg = JSON.parse(raw || '{}');
    } catch {
      return reply(400, { error: 'body is not JSON' });
    }
    let target;
    try {
      target = new URL(String(msg.url));
    } catch {
      return reply(400, { error: 'url is not absolute' });
    }
    if (target.protocol !== 'https:' && target.protocol !== 'http:') return reply(400, { error: 'only http(s)' });
    if (target.username || target.password) return reply(400, { error: 'credentials in the URL are refused; send them as headers' });
    if (target.hostname === 'localhost' || /^(127\.|10\.|192\.168\.|169\.254\.|::1|\[?f[cd])/.test(target.hostname)) {
      return reply(400, { error: 'refusing to proxy to a private address' });
    }
    if (ALLOWED.size && !ALLOWED.has(target.host)) return reply(400, { error: `${target.host} is not in --allow-hosts` });

    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), Number(msg.timeoutMs ?? 15000));
    try {
      const upstream = await fetch(target, {
        method: msg.method === 'POST' ? 'POST' : 'GET',
        headers: msg.headers && typeof msg.headers === 'object' ? msg.headers : undefined,
        body: msg.method === 'POST' && msg.body ? String(msg.body) : undefined,
        signal: ctrl.signal,
      });
      const body = await upstream.text();
      const headers = {};
      upstream.headers.forEach((v, k) => {
        if (!/^(set-cookie|content-security-policy|cf-ray|x-frame-options)$/i.test(k)) headers[k] = v;
      });
      reply(200, { status: upstream.status, headers, body: body.slice(0, 4 * 1024 * 1024) });
    } catch (err) {
      reply(502, { error: `${err?.name ?? 'Error'}: ${err?.message ?? 'upstream failed'}` });
    } finally {
      clearTimeout(timer);
    }
  });
});

server.listen(PORT, HOST, () => {
  console.log(`osint proxy → http://${HOST}:${PORT}/fetch  (no logging, keys pass through in memory only)`);
  if (HOST !== '127.0.0.1' && HOST !== 'localhost') console.log('!! listening on a non-loopback interface — anyone on this network can use your keys');
});
process.on('SIGTERM', () => server.close(() => process.exit(0)));
